import React from "react";
import {createRoot} from "react-dom/client";
import Reader from "../components/reader";
import {initialFeed} from "../lib/initial-feed";
import "../app/globals.css";

createRoot(document.getElementById("root")!).render(<Reader initial={initialFeed}/>);
