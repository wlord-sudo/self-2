import type {Journal} from "./types";
export function defaultJournalIds(journals:Journal[]){return journals.filter(j=>j.defaultOn!==false).map(j=>j.id);}
export function reconcileJournals(selected:string[],known:string[],previousDefaults:string[],catalog:Journal[]){
  const available=new Set(catalog.map(j=>j.id));const result=new Set(selected.filter(id=>available.has(id)));
  const old=new Set(known),oldDefaults=new Set(previousDefaults);
  for(const journal of catalog)if(journal.defaultOn!==false&&(!old.has(journal.id)||!oldDefaults.has(journal.id)))result.add(journal.id);
  return [...result];
}
