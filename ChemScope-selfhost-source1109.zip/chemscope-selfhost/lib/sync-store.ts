import {createHash,randomUUID} from "node:crypto";
import {mkdir,readFile,rename,unlink,writeFile} from "node:fs/promises";
import {join,resolve} from "node:path";
import {normalizeSyncName,settingKeys,type SyncOperation,type SyncSettings,type SyncSnapshot} from "./sync-protocol";
import type {Article} from "./types";

type Entry={value:unknown;timestamp:number;deviceId:string};
type Profile={schemaVersion:1;username:string;revision:number;updatedAt:string;favorites:Record<string,Entry>;reads:Record<string,Entry>;settings:Record<string,Entry>};
export class SyncError extends Error{constructor(message:string,public status=400){super(message);}}
const own=(obj:object,key:string)=>Object.hasOwn(obj,key);
const plain=(value:unknown):value is Record<string,unknown>=>!!value&&typeof value==="object"&&!Array.isArray(value);
function text(value:unknown,max:number){return typeof value==="string"&&value.length<=max;}
function safeKey(value:unknown):value is string{return typeof value==="string"&&value.length>0&&value.length<=240&&!/[\u0000-\u001f\u007f]/.test(value)&&!["__proto__","prototype","constructor"].includes(value);}
function url(value:unknown){if(!text(value,4000))return false;try{return ["https:","http:"].includes(new URL(value as string).protocol);}catch{return false;}}
function article(input:unknown,key:string):Article{
  if(!plain(input)||input.id!==key||!text(input.title,3000)||!input.title||!url(input.link)||!text(input.abstract,60000)||!text(input.authors,10000)||!text(input.journalId,240)||!text(input.journalName,500)||!text(input.journalAbbr,200)||!text(input.doi,1000)||!text(input.publishedAt,80)||!Number.isFinite(Date.parse(input.publishedAt as string))||typeof input.oa!=="boolean")throw new SyncError("收藏文献格式无效");
  const result:Record<string,unknown>={};
  for(const name of ["id","title","authors","publishedAt","abstract","link","doi","journalId","journalName","journalAbbr","oa"])result[name]=input[name];
  result.imageUrl=input.imageUrl===null||url(input.imageUrl)?input.imageUrl:null;
  for(const name of ["titleZh","abstractZh","translationSource","abstractSource","abstractStatus","abstractCheckedAt","sourceType","section"]){if(text(input[name],name==="abstractZh"?60000:3000))result[name]=input[name];}
  if(typeof input.dateEstimated==="boolean")result.dateEstimated=input.dateEstimated;
  if(Buffer.byteLength(JSON.stringify(result))>160000)throw new SyncError("单篇收藏内容过长",413);
  return result as Article;
}
function setting(key:string,value:unknown):unknown{
  if(key==="mode"&&(value==="bilingual"||value==="english"))return value;
  if(key==="autoTranslate"&&typeof value==="boolean")return value;
  if(key==="sort"&&["newest","oldest","journal"].includes(value as string))return value;
  if(key==="journalPreferences"&&plain(value)){
    const result:Record<string,string[]>={};
    for(const name of ["enabled","knownJournalIds","defaultJournalIds"]){const ids=value[name];if(!Array.isArray(ids)||ids.length>1000||!ids.every(safeKey))throw new SyncError("期刊选择格式无效");result[name]=[...new Set(ids)];}
    return result;
  }
  throw new SyncError("阅读设置格式无效");
}
function operation(input:unknown,now:number):SyncOperation{
  if(!plain(input)||!safeKey(input.id)||!safeKey(input.key)||!text(input.deviceId,100)||!input.deviceId||typeof input.timestamp!=="number"||!Number.isSafeInteger(input.timestamp)||input.timestamp<0||!["favorite","read","setting"].includes(input.kind as string)||(input.ifAbsent!==undefined&&typeof input.ifAbsent!=="boolean"))throw new SyncError("同步操作格式无效");
  let value:unknown;
  if(input.kind==="favorite")value=input.value===null?null:article(input.value,input.key);
  else if(input.kind==="read"){if(typeof input.value!=="boolean")throw new SyncError("阅读记录格式无效");value=input.value;}
  else value=setting(input.key,input.value);
  return {id:input.id,kind:input.kind as SyncOperation["kind"],key:input.key,value,timestamp:Math.min(input.timestamp,now+30000),deviceId:input.deviceId as string,ifAbsent:input.ifAbsent===true};
}

export class SyncStore{
  private queues=new Map<string,Promise<unknown>>();
  constructor(private directory=resolve(process.env.SYNC_DIR||join(process.env.CACHE_DIR||".cache","sync")),private now=()=>Date.now()){}
  private async serial<T>(name:string,fn:()=>Promise<T>):Promise<T>{
    const previous=this.queues.get(name)||Promise.resolve();
    const task=previous.catch(()=>{}).then(fn);this.queues.set(name,task);
    try{return await task;}finally{if(this.queues.get(name)===task)this.queues.delete(name);}
  }
  private file(name:string){return join(this.directory,createHash("sha256").update(name).digest("hex")+".json");}
  private async load(name:string,create=false):Promise<Profile>{
    try{
      const raw=await readFile(this.file(name),"utf8");const profile=JSON.parse(raw) as Profile;
      if(profile.schemaVersion!==1||profile.username!==name||!plain(profile.favorites)||!plain(profile.reads)||!plain(profile.settings))throw new Error();
      return profile;
    }catch(error){
      if((error as NodeJS.ErrnoException).code!=="ENOENT")throw new SyncError("同步数据暂时无法读取，请保留本机数据并联系管理员",503);
      if(!create)throw new SyncError("同步空间不存在，请重新连接",404);
      const profile:Profile={schemaVersion:1,username:name,revision:0,updatedAt:new Date(this.now()).toISOString(),favorites:{},reads:{},settings:{}};
      await this.save(profile);return profile;
    }
  }
  private async save(profile:Profile){
    const body=JSON.stringify(profile);if(Buffer.byteLength(body)>32*1024*1024)throw new SyncError("此同步空间已达到容量上限",413);
    await mkdir(this.directory,{recursive:true,mode:0o700});const file=this.file(profile.username),temp=file+"."+randomUUID()+".tmp";
    try{await writeFile(temp,body,{mode:0o600});await rename(temp,file);}finally{await unlink(temp).catch(()=>{});}
  }
  private snapshot(profile:Profile):SyncSnapshot{
    const favorites:Record<string,Article>={},reads:string[]=[],settings:Partial<SyncSettings>={};let maxTimestamp=0;
    for(const [key,entry] of Object.entries(profile.favorites)){if(entry.value)favorites[key]=entry.value as Article;maxTimestamp=Math.max(maxTimestamp,entry.timestamp);}
    for(const [key,entry] of Object.entries(profile.reads)){if(entry.value)reads.push(key);maxTimestamp=Math.max(maxTimestamp,entry.timestamp);}
    for(const [key,entry] of Object.entries(profile.settings)){if(settingKeys.includes(key as keyof SyncSettings))Object.assign(settings,{[key]:entry.value});maxTimestamp=Math.max(maxTimestamp,entry.timestamp);}
    return {username:profile.username,revision:profile.revision,updatedAt:profile.updatedAt,serverTime:this.now(),maxTimestamp,favorites,reads,settings};
  }
  async connect(input:unknown){const name=normalizeSyncName(input);return this.serial(name,async()=>this.snapshot(await this.load(name,true)));}
  async get(input:unknown){const name=normalizeSyncName(input);return this.serial(name,async()=>this.snapshot(await this.load(name)));}
  async apply(input:unknown,changes:unknown){
    const name=normalizeSyncName(input),now=this.now();
    if(!Array.isArray(changes)||!changes.length||changes.length>100)throw new SyncError("每次需提交 1–100 项同步操作");
    const ops=changes.map(change=>operation(change,now));
    return this.serial(name,async()=>{
      const profile=await this.load(name);let changed=false;
      for(const op of ops){
        const map=op.kind==="favorite"?profile.favorites:op.kind==="read"?profile.reads:profile.settings;
        const current=own(map,op.key)?map[op.key]:undefined;
        if(op.ifAbsent&&current)continue;
        if(current&&(op.timestamp<current.timestamp||(op.timestamp===current.timestamp&&op.deviceId<=current.deviceId)))continue;
        if(!current&&Object.keys(map).length>=20000)throw new SyncError("此同步空间的记录数量已达到上限",413);
        map[op.key]={value:op.value,timestamp:op.timestamp,deviceId:op.deviceId};changed=true;
      }
      if(changed){profile.revision++;profile.updatedAt=new Date(now).toISOString();await this.save(profile);}
      return {acknowledged:ops.map(op=>op.id),revision:profile.revision,serverTime:this.now()};
    });
  }
}
