// Public journal text is translated directly from the reader's browser so that
// every visitor has their own provider quota rather than sharing an edge IP.
export async function translateInBrowser(text:string):Promise<string>{
  const parts:string[]=[];let part="";
  for(const word of text.split(/(?<=\s)/)){
    if(new TextEncoder().encode(part+word).length>430&&part){parts.push(part);part="";}
    if(new TextEncoder().encode(word).length>430){
      for(const char of word){if(new TextEncoder().encode(part+char).length>430){parts.push(part);part="";}part+=char;}
    }else part+=word;
  }
  if(part.trim())parts.push(part);
  const result:string[]=[];
  for(const chunk of parts){
    const url=new URL("https://api.mymemory.translated.net/get");url.searchParams.set("q",chunk.trim());url.searchParams.set("langpair","en|zh-CN");
    const response=await fetch(url.toString(),{signal:AbortSignal.timeout(15000),credentials:"omit",referrerPolicy:"no-referrer"});
    if(!response.ok)throw new Error("翻译服务暂时不可用");
    const data=await response.json() as {responseStatus:number;quotaFinished?:boolean;responseData?:{translatedText?:string}};
    const value=data.responseData?.translatedText;
    if(Number(data.responseStatus)!==200||data.quotaFinished||!value||/MYMEMORY WARNING|USED ALL AVAILABLE FREE TRANSLATIONS/i.test(value))throw new Error("免费翻译额度暂时用尽");
    result.push(value.replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(Number(n))).replace(/&quot;/g,'"').replace(/&amp;/g,"&").replace(/&apos;|&#39;/g,"'"));
  }
  return result.join("");
}
