import initial from "./initial-data.json";
import journals from "./journals.json";
import {translations} from "./translations";
import type {Article,Feed,Journal} from "./types";
import {doiFromArticleLink} from "./article-utils";
import {upstreamImage} from "./upstream-image";
export function enrich(article:Article):Article{return {...article,...(translations[article.id]||{})};}
export const initialFeed:Feed={articles:initial.articles.map(a=>enrich({...a,doi:a.doi||doiFromArticleLink(a.link),imageUrl:upstreamImage(a.imageUrl),abstractSource:"upstream",abstractStatus:a.abstract?"available":"missing"} as Article)),journals:journals as Journal[],updatedAt:initial.updatedAt,total:initial.articles.length,source:"snapshot",catalogSynced:false};
