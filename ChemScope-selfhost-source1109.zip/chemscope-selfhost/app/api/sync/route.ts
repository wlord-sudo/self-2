import {SyncError,SyncStore} from "../../../lib/sync-store";
import {normalizeSyncName,SYNC_HEADER} from "../../../lib/sync-protocol";

const store=new SyncStore();
const headers={"Cache-Control":"private, no-store","Vary":SYNC_HEADER};
function name(request:Request){try{return normalizeSyncName(decodeURIComponent(request.headers.get(SYNC_HEADER)||""));}catch{throw new SyncError("同步名无效，请重新连接");}}
function sameOrigin(request:Request){
  // Custom headers plus JSON prevent cross-site form writes. No CORS access is granted.
  if(request.headers.get("sec-fetch-site")==="cross-site")throw new SyncError("不允许跨站访问同步空间",403);
}
async function respond(task:()=>Promise<Response>):Promise<Response>{try{return await task();}catch(error){const status=error instanceof SyncError?error.status:error instanceof SyntaxError?400:503;return Response.json({error:status===503?"同步服务暂不可用，本机更改已保留":error instanceof Error?error.message:"同步请求无效"},{status,headers});}}
export const connectSyncResponse=(request:Request)=>respond(async()=>{
  sameOrigin(request);if(!request.headers.get("content-type")?.includes("application/json"))throw new SyncError("请求需为 JSON",415);
  const body=await request.json();let username:string;try{username=normalizeSyncName(body?.username);}catch(error){throw new SyncError(error instanceof Error?error.message:"同步名无效");}const snapshot=await store.connect(username);
  return Response.json(snapshot,{headers});
});
export const getSyncResponse=(request:Request)=>respond(async()=>{
  sameOrigin(request);const snapshot=await store.get(name(request));const etag=`"sync-${snapshot.revision}"`;
  if(request.headers.get("if-none-match")===etag)return new Response(null,{status:304,headers:{...headers,ETag:etag}});
  return Response.json(snapshot,{headers:{...headers,ETag:etag}});
});
export const postSyncResponse=(request:Request)=>respond(async()=>{
  sameOrigin(request);if(!request.headers.get("content-type")?.includes("application/json"))throw new SyncError("请求需为 JSON",415);
  const body=await request.json();return Response.json(await store.apply(name(request),body?.operations),{headers});
});
