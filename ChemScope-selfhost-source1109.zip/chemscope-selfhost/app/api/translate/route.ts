const memory=new Map<string,string>();
const inFlight=new Map<string,Promise<string>>();
function chunks(text:string):string[]{
  const result:string[]=[];let part="";
  for(const sentence of text.split(/(?<=[.!?])\s+/)){
    if(new TextEncoder().encode(part+" "+sentence).length<450){part+=(part?" ":"")+sentence;continue;}
    if(part)result.push(part);part="";
    for(const char of sentence){if(new TextEncoder().encode(part+char).length>440){result.push(part);part="";}part+=char;}
  }
  if(part)result.push(part);return result;
}
async function googleTranslate(text:string):Promise<string>{
  const parts:string[]=[];
  for(let i=0;i<text.length;i+=3500){
    const url=new URL("https://translate.googleapis.com/translate_a/single");
    for(const [key,value] of Object.entries({client:"gtx",sl:"en",tl:"zh-CN",dt:"t",q:text.slice(i,i+3500)}))url.searchParams.set(key,value);
    const response=await fetch(url.toString(),{signal:AbortSignal.timeout(18000)});
    if(!response.ok)throw new Error(`Google HTTP ${response.status}: ${(await response.text()).slice(0,180)}`);
    const data=await response.json() as unknown;
    if(!Array.isArray(data)||!Array.isArray(data[0]))throw new Error("Invalid translation response");
    const value=(data[0] as unknown[]).map(row=>Array.isArray(row)&&typeof row[0]==="string"?row[0]:"").join("");
    if(!value)throw new Error("Empty translation response");parts.push(value);
  }
  return parts.join("");
}
async function myMemoryTranslate(text:string):Promise<string>{
  const translated:string[]=[];
  for(const chunk of chunks(text)){
    const url=new URL("https://api.mymemory.translated.net/get");url.searchParams.set("q",chunk);url.searchParams.set("langpair","en|zh-CN");
    const response=await fetch(url.toString(),{signal:AbortSignal.timeout(15000)});
    if(!response.ok)throw new Error(`MyMemory HTTP ${response.status}: ${(await response.text()).slice(0,180)}`);
    const data=await response.json() as {responseStatus:number;quotaFinished?:boolean;responseData?:{translatedText?:string}};
    const value=data.responseData?.translatedText;
    if(Number(data.responseStatus)!==200||data.quotaFinished||!value||/MYMEMORY WARNING|USED ALL AVAILABLE FREE TRANSLATIONS/i.test(value))throw new Error("免费翻译额度暂时用尽，请稍后再试；英文原文仍可阅读。");
    translated.push(value);
  }
  return translated.join("");
}
async function translate(text:string):Promise<string>{
  if(!text.trim())return "";
  if(memory.has(text))return memory.get(text)!;
  if(inFlight.has(text))return inFlight.get(text)!;
  const job=(async()=>{
    let value:string;
    try{value=await googleTranslate(text);}catch(primary){try{value=await myMemoryTranslate(text);}catch(secondary){throw new Error("在线翻译暂时无法连接，请稍后重试",{cause:{primary:String(primary),secondary:String(secondary)}});}}
    if(memory.size>500)memory.delete(memory.keys().next().value!);memory.set(text,value);
    return value;
  })();inFlight.set(text,job);try{return await job;}finally{inFlight.delete(text);}
}
export async function POST(request:Request){
  try{
    if(Number(request.headers.get("content-length")||0)>24000)return Response.json({error:"文本过长"},{status:413});
    const body=await request.json() as {text?:unknown};
    if(typeof body.text!=="string"||body.text.length>12000||!body.text.trim())return Response.json({error:"请输入有效的英文文本"},{status:400});
    return Response.json({text:await translate(body.text),provider:"public-translation"});
  }catch(error){
    console.error("Translation unavailable",error);
    const message=error instanceof Error&&/^(免费翻译|翻译服务)/.test(error.message)?error.message:"在线翻译暂时无法连接，请稍后重试；你仍可阅读英文原文。";
    return Response.json({error:message},{status:503});
  }
}
