import {useState} from "react";
import {Cloud,CloudOff,RefreshCw,CheckCircle2,LogOut} from "lucide-react";
import type {useReaderSync} from "./use-reader-sync";

export function SyncSettings({sync}:{sync:ReturnType<typeof useReaderSync>}){
  const {state}=sync;const [name,setName]=useState("");const [merge,setMerge]=useState(true);const [error,setError]=useState("");
  const active=!!state.username,busy=state.phase==="connecting"||state.phase==="syncing";
  const connect=async()=>{setError("");try{await sync.connect(name,merge);}catch(e){setError(e instanceof Error?e.message:"连接失败，请重试");}};
  return <section className="personal-sync-card" aria-label="跨设备同步">
    <div className="personal-sync-heading"><Cloud size={20}/><div><h3>跨设备同步</h3><p>收藏、已读、期刊选择和阅读偏好，随你一起切换设备。</p></div></div>
    {active?<>
      <div className="sync-identity"><span>同步名</span><strong>{state.username}</strong><button type="button" onClick={()=>sync.disconnect()}><LogOut size={13}/>断开</button></div>
      <div className={`personal-sync-state ${state.phase==="offline"?"offline":""}`} role="status">
        {busy?<RefreshCw size={14} className="spin"/>:state.phase==="offline"?<CloudOff size={14}/>:<CheckCircle2 size={14}/>}
        <span>{busy?"正在同步…":state.phase==="offline"?"连接中断，更改已留在本机":"已同步"}{state.pending>0?` · ${state.pending} 项待上传`:state.lastSynced?` · ${new Date(state.lastSynced).toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit",hour12:false})}`:""}</span>
        <button type="button" disabled={busy} onClick={()=>void sync.sync()}>{state.phase==="offline"?"重试":"立即同步"}</button>
      </div>
      {state.error&&<p className="personal-sync-error">{state.error}</p>}
      <p className="personal-sync-help">在其他设备打开同一个网站，输入以上同步名即可。断开后，本机已有收藏会保留。</p>
    </>:<>
      <form className="sync-name-form" onSubmit={e=>{e.preventDefault();void connect();}}><label htmlFor="sync-name">同步名</label><div><input id="sync-name" name="sync-name" autoComplete="off" autoCapitalize="none" spellCheck={false} maxLength={64} placeholder="例如：你的名字加一串随机字符" value={name} onChange={e=>setName(e.target.value)}/><button type="submit" className="primary-button" disabled={!name.trim()}>连接同步 <Cloud size={14}/></button></div></form>
      <label className="sync-merge-option"><input type="checkbox" checked={merge} onChange={e=>setMerge(e.target.checked)}/>合并本机已有的收藏与已读记录</label>
      {error&&<p className="personal-sync-error" role="alert">{error}</p>}
      <p className="personal-sync-help">首次输入会自动创建空间；已有空间优先沿用服务器设置。中文可用，英文字母不区分大小写。</p>
    </>}
    <p className="sync-access-note">同步名就是访问凭据，知道名称的人也能访问或修改该空间。请用不容易猜到的名称。</p>
  </section>;
}
