import {getFeed,initialFeed} from "@/lib/feed";
export async function GET(request?:Request){
  try{return Response.json(await getFeed(request?new URL(request.url).searchParams.get("refresh")==="1":false),{headers:{"Cache-Control":"no-store"}});}
  catch(error){console.error("Upstream feed unavailable",error);return Response.json({...initialFeed,source:"snapshot",message:"来源站暂不可用，正在显示最近保存的文献。"},{headers:{"Cache-Control":"no-store"}});}
}
