import {SyncError,SyncStore} from "../../../lib/sync-store";
import {normalizeSyncName,SYNC_HEADER} from "../../../lib/sync-protocol";
import {clientKey,limiter,limits,type RequestContext} from "../../../lib/rate-limit";

const store=new SyncStore();
const headers={"Cache-Control":"private, no-store","Vary":SYNC_HEADER};
function name(request:Request){try{return normalizeSyncName(decodeURIComponent(request.headers.get(SYNC_HEADER)||""));}catch{throw new SyncError("同步名无效，请重新连接");}}
function sameOrigin(request:Request){
  // A JSON body plus the custom header force a CORS preflight, which is never granted.
  if(request.headers.get("sec-fetch-site")==="cross-site")throw new SyncError("不允许跨站访问同步空间",403);
}
// Compare the MIME essence: "text/plain; application/json" is CORS-safelisted and must not pass.
function requireJson(request:Request){
  const essence=(request.headers.get("content-type")||"").split(";")[0].trim().toLowerCase();
  if(essence!=="application/json")throw new SyncError("请求需为 JSON",415);
}
function throttle(context:RequestContext){
  const ip=clientKey(context);
  const wait=limiter.hit(`sync:${ip}`,limits.syncPerMinute(),60000)||limiter.blocked(`sync-miss:${ip}`,limits.syncMissesPerTenMinutes());
  if(wait)throw new SyncError("同步请求过于频繁，请稍后再试",429,wait);
}
async function respond(context:RequestContext,task:()=>Promise<Response>):Promise<Response>{
  try{return await task();}
  catch(error){
    const status=error instanceof SyncError?error.status:error instanceof SyntaxError?400:503;
    // Repeated lookups of names that do not exist look like guessing; slow them down.
    if(status===404)limiter.hit(`sync-miss:${clientKey(context)}`,limits.syncMissesPerTenMinutes(),600000);
    const extra:Record<string,string>=status===429&&error instanceof SyncError?{"Retry-After":String(Math.max(1,Math.ceil(error.retryAfter/1000)))}:{};
    return Response.json({error:status===503?"同步服务暂不可用，本机更改已保留":error instanceof Error?error.message:"同步请求无效"},{status,headers:{...headers,...extra}});
  }
}
export const connectSyncResponse=(request:Request,context:RequestContext={})=>respond(context,async()=>{
  sameOrigin(request);throttle(context);requireJson(request);
  const body=await request.json();let username:string;try{username=normalizeSyncName(body?.username);}catch(error){throw new SyncError(error instanceof Error?error.message:"同步名无效");}
  const snapshot=await store.connect(username,{allowCreate:()=>limiter.hit(`sync-create:${clientKey(context)}`,limits.syncCreatesPerHour(),3600000)===0});
  return Response.json(snapshot,{headers});
});
export const getSyncResponse=(request:Request,context:RequestContext={})=>respond(context,async()=>{
  sameOrigin(request);throttle(context);const snapshot=await store.get(name(request));const etag=`"sync-${snapshot.revision}"`;
  if(request.headers.get("if-none-match")===etag)return new Response(null,{status:304,headers:{...headers,ETag:etag}});
  return Response.json(snapshot,{headers:{...headers,ETag:etag}});
});
export const postSyncResponse=(request:Request,context:RequestContext={})=>respond(context,async()=>{
  sameOrigin(request);throttle(context);requireJson(request);
  const body=await request.json();return Response.json(await store.apply(name(request),body?.operations),{headers});
});
