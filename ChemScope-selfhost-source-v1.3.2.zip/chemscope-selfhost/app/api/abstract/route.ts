import {getArticleAbstract} from "@/lib/feed";
export async function GET(request:Request){
  const id=new URL(request.url).searchParams.get("id");if(!id||id.length>1000)return Response.json({error:"缺少有效文献 ID"},{status:400});
  const article=await getArticleAbstract(id);if(!article)return Response.json({error:"文献不在当前缓存中"},{status:404});
  return Response.json({article},{headers:{"Cache-Control":"no-store"}});
}
