import {sourceHealth} from "@/lib/feed";
export async function GET(){return Response.json(await sourceHealth(),{headers:{"Cache-Control":"no-store"}});}
