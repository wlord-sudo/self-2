import {decodeEntities} from "../../../lib/html-entities";
import {clientKey,limiter,limits,tooManyRequests,type RequestContext} from "../../../lib/rate-limit";

const memory=new Map<string,string>();
const inFlight=new Map<string,Promise<string>>();
const QUOTA_MESSAGE="免费翻译额度暂时用尽，请稍后再试；英文原文仍可阅读。";
const encoder=new TextEncoder();
/** Splits at sentence ends (or, for very long sentences, characters) so no request exceeds maxBytes. */
export function chunks(text:string,maxBytes=450):string[]{
  const result:string[]=[];let part="";
  for(const sentence of text.split(/(?<=[.!?])\s+/)){
    if(encoder.encode(part+" "+sentence).length<maxBytes){part+=(part?" ":"")+sentence;continue;}
    if(part)result.push(part);part="";
    for(const char of sentence){if(encoder.encode(part+char).length>maxBytes-10){result.push(part);part="";}part+=char;}
  }
  if(part)result.push(part);return result;
}
async function googleTranslate(text:string):Promise<string>{
  const parts:string[]=[];
  // Sentence-sized pieces instead of fixed 3500-character slices, which could cut a word in half.
  for(const chunk of chunks(text,3000)){
    const url=new URL("https://translate.googleapis.com/translate_a/single");
    for(const [key,value] of Object.entries({client:"gtx",sl:"en",tl:"zh-CN",dt:"t",q:chunk}))url.searchParams.set(key,value);
    const response=await fetch(url.toString(),{signal:AbortSignal.timeout(18000)});
    if(!response.ok)throw new Error(`Google HTTP ${response.status}: ${(await response.text()).slice(0,180)}`);
    const data=await response.json() as unknown;
    if(!Array.isArray(data)||!Array.isArray(data[0]))throw new Error("Invalid translation response");
    const value=(data[0] as unknown[]).map(row=>Array.isArray(row)&&typeof row[0]==="string"?row[0]:"").join("");
    if(!value)throw new Error("Empty translation response");parts.push(value);
  }
  return parts.join("");
}
async function myMemoryTranslate(text:string):Promise<string>{
  const translated:string[]=[];
  for(const chunk of chunks(text)){
    const url=new URL("https://api.mymemory.translated.net/get");url.searchParams.set("q",chunk);url.searchParams.set("langpair","en|zh-CN");
    const response=await fetch(url.toString(),{signal:AbortSignal.timeout(15000)});
    if(!response.ok)throw new Error(`MyMemory HTTP ${response.status}: ${(await response.text()).slice(0,180)}`);
    const data=await response.json() as {responseStatus:number;quotaFinished?:boolean;responseData?:{translatedText?:string}};
    const value=data.responseData?.translatedText;
    if(Number(data.responseStatus)!==200||data.quotaFinished||!value||/MYMEMORY WARNING|USED ALL AVAILABLE FREE TRANSLATIONS/i.test(value))throw new Error(QUOTA_MESSAGE);
    translated.push(decodeEntities(value));
  }
  return translated.join("");
}
async function translate(text:string):Promise<string>{
  if(!text.trim())return "";
  if(memory.has(text))return memory.get(text)!;
  if(inFlight.has(text))return inFlight.get(text)!;
  const job=(async()=>{
    let value:string;
    try{value=await googleTranslate(text);}catch(primary){try{value=await myMemoryTranslate(text);}catch(secondary){
      // Surface the quota message when that is the reason, instead of a generic connection error.
      const message=secondary instanceof Error&&secondary.message===QUOTA_MESSAGE?QUOTA_MESSAGE:"翻译服务暂时无法连接，请稍后重试；你仍可阅读英文原文。";
      throw new Error(message,{cause:{primary:String(primary),secondary:String(secondary)}});
    }}
    if(memory.size>500)memory.delete(memory.keys().next().value!);memory.set(text,value);
    return value;
  })();inFlight.set(text,job);try{return await job;}finally{inFlight.delete(text);}
}
export async function POST(request:Request,context:RequestContext={}){
  try{
    if(request.headers.get("sec-fetch-site")==="cross-site")return Response.json({error:"不允许跨站调用翻译接口"},{status:403});
    if(Number(request.headers.get("content-length")||0)>24000)return Response.json({error:"文本过长"},{status:413});
    const body=await request.json() as {text?:unknown};
    if(typeof body.text!=="string"||body.text.length>12000||!body.text.trim())return Response.json({error:"请输入有效的英文文本"},{status:400});
    // Cached answers are free; only requests that reach a public provider count toward the limit,
    // so one visitor cannot get this server's IP blocked by Google or MyMemory.
    if(!memory.has(body.text)){
      const wait=limiter.hit(`translate:${clientKey(context)}`,limits.translatePerMinute(),60000);
      if(wait)return tooManyRequests(wait,"翻译请求过于频繁，请稍后再试；英文原文仍可阅读。");
    }
    return Response.json({text:await translate(body.text),provider:"public-translation"});
  }catch(error){
    console.error("Translation unavailable",error);
    const message=error instanceof Error&&/^(免费翻译|翻译服务)/.test(error.message)?error.message:"在线翻译暂时无法连接，请稍后重试；你仍可阅读英文原文。";
    return Response.json({error:message},{status:503});
  }
}
