import React from "react";
import {createRoot} from "react-dom/client";
import Reader from "../components/reader";
import {ErrorBoundary} from "../components/error-boundary";
import {initialCatalogFeed} from "../lib/initial-catalog";
import "../app/globals.css";

createRoot(document.getElementById("root")!).render(<ErrorBoundary><Reader initial={initialCatalogFeed}/></ErrorBoundary>);
