import {defineConfig} from "vite";
import react from "@vitejs/plugin-react";
import {fileURLToPath,URL} from "node:url";

export default defineConfig({
  plugins:[react()],
  resolve:{alias:{"@":fileURLToPath(new URL(".",import.meta.url))}},
  build:{outDir:"dist/client",emptyOutDir:true},
  server:{proxy:{"/api":"http://127.0.0.1:3000","/healthz":"http://127.0.0.1:3000"}}
});
