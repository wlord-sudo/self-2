import {createServer} from "node:http";
import {createReadStream} from "node:fs";
import {readFile,stat} from "node:fs/promises";
import {createHash} from "node:crypto";
import {dirname,extname,resolve,sep} from "node:path";
import {fileURLToPath} from "node:url";
import {promisify} from "node:util";
import {gzip as gzipCallback} from "node:zlib";
import {getFeedResponse,getTranslationResponse,getAbstractResponse,getStatusResponse,warmFeed,connectSyncResponse,getSyncResponse,postSyncResponse} from "./dist/server/api.mjs";

const root=resolve(dirname(fileURLToPath(import.meta.url)),"dist/client");
const port=Number(process.env.PORT||3000);
const host=process.env.HOST||"0.0.0.0";
// Set TRUST_PROXY=1 only when exactly one reverse proxy (for example Nginx) sits in front and
// appends the visitor address to X-Forwarded-For; otherwise the header could be forged.
const trustProxy=/^(1|true|yes)$/i.test(process.env.TRUST_PROXY||"");
const mime={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".svg":"image/svg+xml",".png":"image/png",".jpg":"image/jpeg",".ico":"image/x-icon",".json":"application/json; charset=utf-8",".woff2":"font/woff2"};
const gzip=promisify(gzipCallback);
const acceptsGzip=req=>/\bgzip\b/.test(req.headers["accept-encoding"]||"");

function clientIp(req){
  let ip="";
  if(trustProxy){
    const forwarded=String(req.headers["x-forwarded-for"]||"").split(",").map(value=>value.trim()).filter(Boolean);
    ip=forwarded.at(-1)||String(req.headers["x-real-ip"]||"");
  }
  ip=(ip||req.socket.remoteAddress||"unknown").replace(/^::ffff:/,"");
  // Group IPv6 visitors by /64 so rotating addresses inside one network share a limit.
  return ip.includes(":")?ip.split(":").slice(0,4).join(":"):ip;
}
function addVary(res,value){
  const parts=String(res.getHeader("Vary")||"").split(",").map(part=>part.trim()).filter(Boolean);
  if(!parts.some(part=>part.toLowerCase()===value.toLowerCase()))parts.push(value);
  res.setHeader("Vary",parts.join(", "));
}
// The feed is several MB; compress off the event loop and reuse the result while it is unchanged.
let lastCompressed={key:"",body:null};
async function compressed(body){
  if(body.length<65536)return gzip(body);
  const key=createHash("sha1").update(body).digest("hex");
  if(lastCompressed.key===key)return lastCompressed.body;
  const result=await gzip(body);lastCompressed={key,body:result};return result;
}
const staticCache=new Map();
async function compressedFile(file,info){
  const key=`${file}:${info.mtimeMs}:${info.size}`;let body=staticCache.get(key);
  if(!body){body=await gzip(await readFile(file));if(staticCache.size>=64)staticCache.delete(staticCache.keys().next().value);staticCache.set(key,body);}
  return body;
}

async function sendResponse(req,res,response){
  res.statusCode=response.status;
  response.headers.forEach((value,key)=>res.setHeader(key,value));
  let body=Buffer.from(await response.arrayBuffer());
  if(body.length>1024&&acceptsGzip(req)){
    body=await compressed(body);res.setHeader("Content-Encoding","gzip");addVary(res,"Accept-Encoding");
  }
  res.setHeader("Content-Length",body.length);
  res.end(req.method==="HEAD"?undefined:body);
}

async function readBody(req,maximum=24000){
  const chunks=[];let length=0;
  for await(const chunk of req){length+=chunk.length;if(length>maximum){const error=new Error("请求内容过长");error.status=413;throw error;}chunks.push(chunk);}
  return Buffer.concat(chunks);
}

const server=createServer(async(req,res)=>{
  res.setHeader("X-Content-Type-Options","nosniff");
  res.setHeader("Referrer-Policy","strict-origin-when-cross-origin");
  try{
    const url=new URL(req.url||"/","http://localhost");
    const context={ip:clientIp(req)};
    if(url.pathname==="/healthz")return sendResponse(req,res,Response.json({status:"ok",application:"ChemScope"}));
    if(url.pathname==="/api/feed"){
      if(req.method!=="GET")return sendResponse(req,res,new Response(null,{status:405,headers:{Allow:"GET"}}));
      return sendResponse(req,res,await getFeedResponse(new Request(url.href)));
    }
    if(url.pathname==="/api/abstract"){
      if(req.method!=="GET")return sendResponse(req,res,new Response(null,{status:405,headers:{Allow:"GET"}}));
      return sendResponse(req,res,await getAbstractResponse(new Request(url.href)));
    }
    if(url.pathname==="/api/status"){
      if(req.method!=="GET")return sendResponse(req,res,new Response(null,{status:405,headers:{Allow:"GET"}}));
      return sendResponse(req,res,await getStatusResponse());
    }
    if(url.pathname==="/api/sync"||url.pathname==="/api/sync/connect"){
      const connecting=url.pathname.endsWith("/connect");
      if(connecting?req.method!=="POST":!["GET","POST"].includes(req.method))return sendResponse(req,res,new Response(null,{status:405,headers:{Allow:connecting?"POST":"GET, POST"}}));
      const body=req.method==="POST"?await readBody(req,connecting?4096:1200000):undefined;
      const request=new Request(url.href,{method:req.method,headers:req.headers,body});
      const handler=connecting?connectSyncResponse:req.method==="GET"?getSyncResponse:postSyncResponse;
      return sendResponse(req,res,await handler(request,context));
    }
    if(url.pathname==="/api/translate"){
      if(req.method!=="POST")return sendResponse(req,res,new Response(null,{status:405,headers:{Allow:"POST"}}));
      const body=await readBody(req);
      try{JSON.parse(body.toString());}catch{return sendResponse(req,res,Response.json({error:"请求必须为有效 JSON"},{status:400}));}
      const headers={"Content-Type":"application/json","Content-Length":String(body.length)};
      if(typeof req.headers["sec-fetch-site"]==="string")headers["Sec-Fetch-Site"]=req.headers["sec-fetch-site"];
      const request=new Request("http://localhost/api/translate",{method:"POST",headers,body});
      return sendResponse(req,res,await getTranslationResponse(request,context));
    }
    if(url.pathname.startsWith("/api/"))return sendResponse(req,res,Response.json({error:"接口不存在"},{status:404}));
    if(req.method!=="GET"&&req.method!=="HEAD")return sendResponse(req,res,new Response(null,{status:405,headers:{Allow:"GET, HEAD"}}));
    let pathname;try{pathname=decodeURIComponent(url.pathname);}catch{return sendResponse(req,res,new Response("Bad request",{status:400}));}
    if(pathname.includes("\0"))return sendResponse(req,res,new Response("Bad request",{status:400}));
    const file=resolve(root,"."+(pathname==="/"?"/index.html":pathname));
    if(file!==root&&!file.startsWith(root+sep))return sendResponse(req,res,new Response("Forbidden",{status:403}));
    let info;try{info=await stat(file);}catch{return sendResponse(req,res,new Response("Not found",{status:404}));}
    if(!info.isFile())return sendResponse(req,res,new Response("Not found",{status:404}));
    res.setHeader("Content-Type",mime[extname(file)]||"application/octet-stream");
    res.setHeader("Cache-Control",pathname.startsWith("/assets/")?"public, max-age=31536000, immutable":"no-cache");
    if(req.method==="HEAD"){res.setHeader("Content-Length",info.size);return res.end();}
    if(info.size>1024&&info.size<=8*1024*1024&&acceptsGzip(req)&&/\.(html|js|css|json|svg)$/.test(file)){
      const body=await compressedFile(file,info);
      res.setHeader("Content-Encoding","gzip");addVary(res,"Accept-Encoding");res.setHeader("Content-Length",body.length);return res.end(body);
    }
    const stream=createReadStream(file);stream.on("error",()=>res.destroy());
    res.setHeader("Content-Length",info.size);stream.pipe(res);
  }catch(error){
    console.error(error instanceof Error?error.message:"Request failed");
    const tooLarge=error?.status===413;
    if(!res.headersSent)await sendResponse(req,res,Response.json({error:tooLarge?"请求内容过长":"服务暂时不可用"},{status:tooLarge?413:500}));
    else res.destroy();
  }
});

server.requestTimeout=65000;
server.headersTimeout=15000;
server.listen(port,host,()=>{console.log(`ChemScope is running at http://${host}:${port}`);void warmFeed().catch(()=>{});});
for(const signal of ["SIGINT","SIGTERM"])process.on(signal,()=>{server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),10000).unref();});
