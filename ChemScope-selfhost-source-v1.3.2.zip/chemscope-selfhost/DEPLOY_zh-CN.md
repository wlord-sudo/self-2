# 中文部署说明

## 1. 上传与解压

将 `ChemScope-selfhost-source.zip` 上传到服务器，解压后进入 `chemscope-selfhost` 目录。后续命令均在这个目录内执行。

```bash
unzip ChemScope-selfhost-source.zip
cd chemscope-selfhost
```

## 2. Docker Compose 部署

服务器安装 Docker 和 Compose 插件后执行：

```bash
docker compose up -d --build
docker compose ps
```

访问 `http://服务器IP:3000`。

默认 `compose.yml` 选择 `Dockerfile.prebuilt`，使用压缩包内已构建好的 `dist/`，不需要下载 npm 依赖。构建时仍需要能够获取 `node:24-alpine` 基础镜像。

如需改用 8080 端口，在项目目录新建 `.env`：

```dotenv
PORT=8080
```

然后执行：

```bash
docker compose up -d --build
```

此时访问 `http://服务器IP:8080`。容器内部仍使用 3000 端口。

常用命令：

```bash
docker compose logs -f
docker compose restart
docker compose down
```

修改源码后，在 `compose.yml` 中把 `dockerfile: Dockerfile.prebuilt` 改为 `dockerfile: Dockerfile`，再执行 `docker compose up -d --build`，即可在镜像构建阶段重新安装依赖并编译。之后每次改源码都应重新构建，单纯 restart 不会重新编译。

## 3. 不使用 Docker

检查 Node.js 版本：

```bash
node --version
```

最低要求 22.13，建议使用 24 系列。包内有构建产物，可以直接启动：

```bash
node server.mjs
```

自定义监听地址和端口：

```bash
HOST=127.0.0.1 PORT=8080 node server.mjs
```

只有 `npm start` 和 `npm run dev:api` 会自动加载项目目录的 `.env`。直接执行 `node server.mjs` 时使用 shell 环境变量；也可以运行 `node --env-file-if-exists=.env server.mjs`。

### systemd 后台运行

将整个项目放到 `/opt/chemscope`，用 `command -v node` 确认 Node 路径，将下面的 `/usr/bin/node` 替换为实际路径。创建 `/etc/systemd/system/chemscope.service`：

```ini
[Unit]
Description=ChemScope bilingual chemistry reader
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/chemscope
ExecStart=/usr/bin/node /opt/chemscope/server.mjs
Environment=NODE_ENV=production
Environment=HOST=0.0.0.0
Environment=PORT=3000
Environment=CACHE_DIR=/var/lib/chemscope
StateDirectory=chemscope
Restart=on-failure
RestartSec=5
DynamicUser=yes
NoNewPrivileges=yes

[Install]
WantedBy=multi-user.target
```

应用目录和文件需要对服务用户可读，然后执行：

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now chemscope
sudo systemctl status chemscope
```

查看日志：

```bash
sudo journalctl -u chemscope -f
```

## 4. 使用域名和反向代理

将域名解析到服务器，使用现有 Nginx 或其他反向代理转发到 3000 端口即可。例如，Nginx 的站点配置可以使用：

```nginx
server {
    listen 80;
    server_name papers.example.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

将 `papers.example.com` 换成自己的域名；HTTPS 可以由已有面板或反向代理管理。DOI 复制功能在 HTTPS 或 localhost 环境下兼容性更好。

使用反向代理时建议同时做两件事：

1. 在 `.env` 中设置 `TRUST_PROXY=1`，让频率限制按真实访问者区分；否则所有访问者都显示为代理地址，共用同一份限额。只有在**恰好一层**反向代理、且代理按上面的配置追加 `X-Forwarded-For` 时才开启，否则该请求头可以被伪造。
2. 让 3000 端口只对本机开放，避免绕过 HTTPS 直接访问：Docker 部署把 `compose.yml` 中的端口改为 `"127.0.0.1:${PORT:-3000}:3000"`；Node.js 直接运行时设置 `HOST=127.0.0.1`。

## 5. 修改页面与开发

```bash
npm ci
npm run build
```

前端开发与 API 分别在两个终端启动：

```bash
npm run dev:api
```

```bash
npm run dev
```

Vite 默认使用 5173 端口，并将 `/api` 请求代理至本机 3000 端口。页面文件修改后自动刷新；修改后端 TS 文件后需要再次 `npm run build` 并重启 API 服务。

常用修改位置：

- 网站标题：`index.html`；页面品牌文字：`components/reader.tsx`。
- 配色与尺寸：`app/globals.css`；Logo：`public/favicon.svg`。
- 原站 API 同步和缓存：`lib/feed.ts`；离线目录与文献快照：`lib/journals.json`、`lib/initial-data.json`。
- 默认期刊与用户偏好：`lib/journal-selection.ts`；来源站数据规范化：`lib/upstream-normalize.ts`。
- 翻译逻辑：`lib/translate-client.ts` 和 `app/api/translate/route.ts`。

## 6. 常见情况

**页面能打开，但显示“最近保存的文献”**：应用正在使用随包快照。检查服务器是否能够访问 https://api.baranlab.org/ 的公开 API。来源站暂不可用时保留本地缓存；本版不再直接抓取出版社 RSS。

**标题或摘要无法翻译**：浏览器或服务器连接不到翻译服务，或免费额度已用尽。已有译文和英文原文仍可阅读，稍后可重试。

**外网打不开，本机健康检查正常**：检查你实际使用的监听地址、Docker 端口映射，以及服务器的防火墙或安全组是否允许所选端口。

**改了源码但页面没变**：先重新构建，再重新启动。默认 Docker 配置读取预构建的 `dist/`，修改源码后应改用 `Dockerfile` 从源码构建。

健康检查：

```bash
curl http://127.0.0.1:3000/healthz
```

正常返回含 `"status":"ok"` 的 JSON。


## 7. 原站同步设置

- `FEED_CACHE_MINUTES=5`：原站目录与文献的缓存间隔，单位分钟，最小 1 分钟。
- `CACHE_DIR=.cache`：Node.js 直接运行时的缓存目录。Docker Compose 使用 `/app/.cache` 并挂载持久卷。
- `FEED_FORCE_MIN_SECONDS=60`：访客点击“刷新文献”触发原站全量同步的最小间隔，单位秒。

### 访问保护（v1.3.2 新增）

以下变量可写入 `.env`（Docker Compose 已透传前三项），未设置时使用默认值；频率限制设为 `0` 表示关闭该项。

| 变量 | 默认 | 作用 |
| --- | --- | --- |
| `TRUST_PROXY` | `0` | 设为 `1` 时按 `X-Forwarded-For` 最后一跳识别访问者 IP，仅限单层反向代理 |
| `SYNC_MAX_SPACES` | `1000` | 服务器同步空间总数上限，`0` 为不限 |
| `SYNC_MIN_NAME_LENGTH` | `8` | 新建同步空间的最短名称，已有空间不受影响 |
| `SYNC_RATE_PER_MINUTE` | `120` | 每个 IP 每分钟同步请求数 |
| `SYNC_CREATE_PER_HOUR` | `10` | 每个 IP 每小时新建同步空间数 |
| `SYNC_MISSES_PER_10_MINUTES` | `30` | 每个 IP 每 10 分钟查询不存在的同步名次数，超过后暂停同步请求 |
| `TRANSLATE_RATE_PER_MINUTE` | `60` | 每个 IP 每分钟未缓存的服务端翻译请求数 |

后四项在 Docker Compose 中需要自行加到 `compose.yml` 的 `environment` 下。课题组多人共用、又没有设置 `TRUST_PROXY` 时，可适当调高 `SYNC_RATE_PER_MINUTE`。

Node.js 的 `npm start` 会加载 `.env`；Docker Compose 中的值在 `compose.yml` 的 environment 下修改。旧 RSS / Nature 补抓参数在本版本中不再使用。

运行时会自动请求原站 `/api/journals`，同步全部可选期刊与默认勾选项，再以完整期刊 ID 列表请求 `/api/feed?journals=...&limit=0`。不需要手动维护 RSS 地址。当前离线目录包含本次验证时的 43 种期刊，默认选择 23 种；以后以原站实际返回为准。

本地缓存保存为 `api-feed-v3.json`。Docker Compose 保留原来的 `rss-cache` 卷名，升级时继续使用原目录即可。摘要与图片以原站提供的内容为准，不再从出版社文章页补抓。

回归测试：

```bash
npm test
```

进度接口为 `/api/status`，完整列表为 `/api/feed`。首次列表响应不等待后台原站同步结束。

## 8. 从已部署版本升级至 v1.3

将新版压缩包解压覆盖到原来的 `chemscope-selfhost` 项目目录；保留自己的 `.env`、端口设置和 Compose 项目名。同步数据会继续使用原来的 `rss-cache` 持久卷。

```bash
cd /你的路径/chemscope-selfhost
docker compose up -d --build
docker compose ps
```

本包已更新 `dist/`，使用默认 `Dockerfile.prebuilt` 即可。不要仅执行 restart；不要添加 `-v` 删除数据卷。

Node.js 或 systemd 部署：覆盖源码与 `dist/` 后，重启原服务，例如 `sudo systemctl restart chemscope`。继续使用原有 `CACHE_DIR`；systemd 示例对应 `/var/lib/chemscope/sync`。

升级后，在网页阅读设置中输入同步名；手机和电脑使用同一网址、同一同步名。可勾选合并原浏览器的收藏。若已有同步数据，服务器设置优先；名称不区分英文大小写。

### 同步数据和备份

- 默认目录：`CACHE_DIR/sync`；Docker 为 `/app/.cache/sync`。
- 可选环境变量：`SYNC_DIR`，指定其他可写持久目录。不要将其放入会在重建镜像时清空的位置。
- 每个同步空间是一个 JSON 文件，文件名为名称的 SHA-256 摘要；文件正文包含文献和设置，不对外提供文件下载或空间列表。
- 备份时包含整个 `sync` 子目录；恢复时同时保留文件权限，使运行 Node.js 的用户可读写。空间文件包含删除记录，不能只复制界面里当前收藏的条目。
- 一套部署运行一个 Node.js 服务进程。不同空间独立写入，同一空间串行合并并以原子替换保存；多实例共用目录需要另行接入支持事务的数据库。
- 如反向代理配置了缓存，请勿缓存 `/api/sync` 及 `/api/sync/connect`；API 已设置 `Cache-Control: private, no-store`。

同步入口使用 `POST /api/sync/connect` 创建或读取空间，`GET /api/sync` 拉取数据，`POST /api/sync` 提交增量。名称通过编码的 `X-ChemScope-Sync` 请求头传递，不加入 URL。没有独立数据库或第三方同步服务费用。

**看到“连接中断”**：先检查服务器是否运行新版 `dist/server/api.mjs` 和 `server.mjs`，以及数据目录权限；恢复网络后点击“重试”。已存在的本机更改会保留，不要清除浏览器站点数据。

**手机没有出现电脑上的收藏**：确认网址和同步名相同，在两台设备的阅读设置里点击“立即同步”。页面停留前台时通常在 15 秒内收到其他设备的更改。

## 9. v1.3.1 同步修复

如果 v1.3 的同步界面显示 `Failed to execute 'fetch' on 'Window': Illegal invocation`，这是旧版前端调用浏览器 fetch 的方式不正确，请更新到 v1.3.1。

将修复包覆盖到原项目目录，保留自定义端口、`.env` 与持久卷，再运行：

```bash
docker compose up -d --build
```

本包已重新构建 `dist/`，默认 `Dockerfile.prebuilt` 可以直接使用。部署完成后刷新原来的网页；浏览器若还显示旧页面，执行强制刷新。无需修改同步名。

保留浏览器的站点数据和原服务器的数据卷。原浏览器的待上传队列会在修复后的页面恢复连接时继续提交，不需要清空缓存或重新创建空间。这里的“强制刷新”指重新加载网页资源，不是删除站点存储。

## 10. 升级到 v1.3.2

覆盖方式与 v1.3.1 相同：保留 `.env`、端口设置和持久卷，在项目目录执行 `docker compose up -d --build`；Node.js 或 systemd 部署覆盖文件后重启服务。同步数据格式不变，无需迁移。

- 如果之前同步一直显示“收藏文献格式无效”或待上传数量不减，升级后刷新页面即可：浏览器中卡住的待上传记录会自动修复并上传。不要清除浏览器站点数据。
- 新建同步空间需要至少 8 个字符的名称；已经在用的短名称继续有效。
- 使用 Nginx 等反向代理的部署，请按第 4 节设置 `TRUST_PROXY=1`。
- 页面脚本不再包含文献快照，首次打开会先显示“正在加载最新文献…”，随后从服务器读取列表。
