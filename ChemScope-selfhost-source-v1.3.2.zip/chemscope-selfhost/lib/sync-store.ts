import {createHash,randomUUID} from "node:crypto";
import {mkdir,readdir,readFile,rename,unlink,writeFile} from "node:fs/promises";
import {join,resolve} from "node:path";
import {normalizeSyncName,settingKeys,type SyncApplyResult,type SyncOperation,type SyncRejection,type SyncSettings,type SyncSnapshot} from "./sync-protocol";
import {UNKNOWN_DATE} from "./article-shape";
import type {Article} from "./types";

type Entry={value:unknown;timestamp:number;deviceId:string};
type Profile={schemaVersion:1;username:string;revision:number;updatedAt:string;favorites:Record<string,Entry>;reads:Record<string,Entry>;settings:Record<string,Entry>};
export class SyncError extends Error{constructor(message:string,public status=400,public retryAfter=0){super(message);}}
export type SyncStoreOptions={
  now?:()=>number;
  /** New spaces only; existing spaces with shorter names keep working. */
  minNewNameLength?:number;
  /** 0 disables the limit. */
  maxSpaces?:number;
  /** Per-space cap for read records and favorite entries (deletion markers included). */
  maxRecords?:number;
  maxBytes?:number;
};
export type ConnectOptions={allowCreate?:()=>boolean};

const own=(obj:object,key:string)=>Object.hasOwn(obj,key);
const plain=(value:unknown):value is Record<string,unknown>=>!!value&&typeof value==="object"&&!Array.isArray(value);
const envNumber=(name:string,fallback:number)=>{const value=Number(process.env[name]);return process.env[name]!==undefined&&Number.isFinite(value)&&value>=0?value:fallback;};
function text(value:unknown,max:number){return typeof value==="string"&&value.length<=max;}
function safeKey(value:unknown):value is string{return typeof value==="string"&&value.length>0&&value.length<=240&&!/[\u0000-\u001f\u007f]/.test(value)&&!["__proto__","prototype","constructor"].includes(value);}
function url(value:unknown){if(!text(value,4000))return false;try{return ["https:","http:"].includes(new URL(value as string).protocol);}catch{return false;}}
function invalid():never{throw new SyncError("收藏文献格式无效");}
function article(input:unknown,key:string):Article{
  if(!plain(input)||input.id!==key||!text(input.title,3000)||!(input.title as string).trim()||!url(input.link))invalid();
  const result:Record<string,unknown>={id:input.id,title:input.title,link:input.link};
  // Older clients and the bundled snapshot send null for some optional fields; store them as empty values.
  for(const [name,max] of [["authors",10000],["abstract",60000],["journalId",240],["journalName",500],["journalAbbr",200],["doi",1000]] as const){
    const value=input[name];if(value===undefined||value===null)result[name]="";else if(text(value,max))result[name]=value;else invalid();
  }
  result.publishedAt=text(input.publishedAt,80)&&Number.isFinite(Date.parse(input.publishedAt as string))?input.publishedAt:UNKNOWN_DATE;
  result.oa=input.oa===true;
  result.imageUrl=url(input.imageUrl)?input.imageUrl:null;
  for(const name of ["titleZh","abstractZh","translationSource","abstractSource","abstractStatus","abstractCheckedAt","sourceType","section"]){if(text(input[name],name==="abstractZh"?60000:3000))result[name]=input[name];}
  if(typeof input.dateEstimated==="boolean")result.dateEstimated=input.dateEstimated;
  if(Buffer.byteLength(JSON.stringify(result))>160000)throw new SyncError("单篇收藏内容过长",413);
  return result as Article;
}
function setting(key:string,value:unknown):unknown{
  if(key==="mode"&&(value==="bilingual"||value==="english"))return value;
  if(key==="autoTranslate"&&typeof value==="boolean")return value;
  if(key==="sort"&&["newest","oldest","journal"].includes(value as string))return value;
  if(key==="journalPreferences"&&plain(value)){
    const result:Record<string,string[]>={};
    for(const name of ["enabled","knownJournalIds","defaultJournalIds"]){const ids=value[name];if(!Array.isArray(ids)||ids.length>1000||!ids.every(safeKey))throw new SyncError("期刊选择格式无效");result[name]=[...new Set(ids)];}
    return result;
  }
  throw new SyncError("阅读设置格式无效");
}
function operation(input:unknown,now:number):SyncOperation{
  if(!plain(input)||!safeKey(input.id)||!safeKey(input.key)||!text(input.deviceId,100)||!input.deviceId||typeof input.timestamp!=="number"||!Number.isSafeInteger(input.timestamp)||input.timestamp<0||!["favorite","read","setting"].includes(input.kind as string)||(input.ifAbsent!==undefined&&typeof input.ifAbsent!=="boolean"))throw new SyncError("同步操作格式无效");
  let value:unknown;
  if(input.kind==="favorite")value=input.value===null?null:article(input.value,input.key);
  else if(input.kind==="read"){if(typeof input.value!=="boolean")throw new SyncError("阅读记录格式无效");value=input.value;}
  else value=setting(input.key,input.value);
  return {id:input.id,kind:input.kind as SyncOperation["kind"],key:input.key,value,timestamp:Math.min(input.timestamp,now+30000),deviceId:input.deviceId as string,ifAbsent:input.ifAbsent===true};
}
function oldestFirst(map:Record<string,Entry>,keys:string[]){return keys.sort((a,b)=>map[a].timestamp-map[b].timestamp);}

export class SyncStore{
  private queues=new Map<string,Promise<unknown>>();
  private now:()=>number;private minNewNameLength:number;private maxSpaces:number;private maxRecords:number;private maxBytes:number;
  constructor(private directory=resolve(process.env.SYNC_DIR||join(process.env.CACHE_DIR||".cache","sync")),options:SyncStoreOptions|(()=>number)={}){
    const value=typeof options==="function"?{now:options}:options;
    this.now=value.now||(()=>Date.now());
    this.minNewNameLength=value.minNewNameLength??envNumber("SYNC_MIN_NAME_LENGTH",8);
    this.maxSpaces=value.maxSpaces??envNumber("SYNC_MAX_SPACES",1000);
    this.maxRecords=value.maxRecords??20000;
    this.maxBytes=value.maxBytes??32*1024*1024;
  }
  private async serial<T>(name:string,fn:()=>Promise<T>):Promise<T>{
    const previous=this.queues.get(name)||Promise.resolve();
    const task=previous.catch(()=>{}).then(fn);this.queues.set(name,task);
    try{return await task;}finally{if(this.queues.get(name)===task)this.queues.delete(name);}
  }
  private file(name:string){return join(this.directory,createHash("sha256").update(name).digest("hex")+".json");}
  private async load(name:string,create=false,options:ConnectOptions={}):Promise<Profile>{
    try{
      const raw=await readFile(this.file(name),"utf8");const profile=JSON.parse(raw) as Profile;
      if(profile.schemaVersion!==1||profile.username!==name||!plain(profile.favorites)||!plain(profile.reads)||!plain(profile.settings))throw new Error();
      return profile;
    }catch(error){
      if((error as NodeJS.ErrnoException).code!=="ENOENT")throw new SyncError("同步数据暂时无法读取，请保留本机数据并联系管理员",503);
      if(!create)throw new SyncError("同步空间不存在，请重新连接",404);
      await this.mayCreate(name,options);
      const profile:Profile={schemaVersion:1,username:name,revision:0,updatedAt:new Date(this.now()).toISOString(),favorites:{},reads:{},settings:{}};
      await this.save(profile);return profile;
    }
  }
  private async mayCreate(name:string,options:ConnectOptions){
    if([...name].length<this.minNewNameLength)throw new SyncError(`新建同步空间的同步名至少需要 ${this.minNewNameLength} 个字符；可使用“随机生成”`);
    if(options.allowCreate&&!options.allowCreate())throw new SyncError("新建同步空间过于频繁，请稍后再试",429,600000);
    if(this.maxSpaces>0){
      const files=await readdir(this.directory).catch(()=>[] as string[]);
      if(files.filter(file=>/^[a-f0-9]{64}\.json$/.test(file)).length>=this.maxSpaces)throw new SyncError("此服务器的同步空间数量已达上限，请联系管理员",507);
    }
  }
  private async save(profile:Profile,body=JSON.stringify(profile)){
    if(Buffer.byteLength(body)>this.maxBytes)throw new SyncError("此同步空间已达到容量上限",413);
    await mkdir(this.directory,{recursive:true,mode:0o700});const file=this.file(profile.username),temp=file+"."+randomUUID()+".tmp";
    try{await writeFile(temp,body,{mode:0o600});await rename(temp,file);}finally{await unlink(temp).catch(()=>{});}
  }
  private snapshot(profile:Profile):SyncSnapshot{
    const favorites:Record<string,Article>={},reads:string[]=[],settings:Partial<SyncSettings>={};let maxTimestamp=0;
    for(const [key,entry] of Object.entries(profile.favorites)){if(entry.value)favorites[key]=entry.value as Article;maxTimestamp=Math.max(maxTimestamp,entry.timestamp);}
    for(const [key,entry] of Object.entries(profile.reads)){if(entry.value)reads.push(key);maxTimestamp=Math.max(maxTimestamp,entry.timestamp);}
    for(const [key,entry] of Object.entries(profile.settings)){if(settingKeys.includes(key as keyof SyncSettings))Object.assign(settings,{[key]:entry.value});maxTimestamp=Math.max(maxTimestamp,entry.timestamp);}
    return {username:profile.username,revision:profile.revision,updatedAt:profile.updatedAt,serverTime:this.now(),maxTimestamp,favorites,reads,settings};
  }
  /** Keeps a space usable forever: the oldest read records and deletion markers make room for new ones. */
  private prune(profile:Profile){
    const reads=Object.keys(profile.reads);
    if(reads.length>this.maxRecords)for(const key of oldestFirst(profile.reads,reads).slice(0,reads.length-this.maxRecords))delete profile.reads[key];
    const favorites=Object.keys(profile.favorites);
    if(favorites.length>this.maxRecords){
      const markers=oldestFirst(profile.favorites,favorites.filter(key=>!profile.favorites[key].value));
      for(const key of markers.slice(0,favorites.length-this.maxRecords))delete profile.favorites[key];
    }
  }
  async connect(input:unknown,options:ConnectOptions={}){const name=normalizeSyncName(input);return this.serial(name,async()=>this.snapshot(await this.load(name,true,options)));}
  async get(input:unknown){const name=normalizeSyncName(input);return this.serial(name,async()=>this.snapshot(await this.load(name)));}
  /**
   * Validates and applies each operation on its own. An invalid or over-limit operation is
   * reported in `rejected` instead of failing the whole batch, so one bad record can no
   * longer block every later change from a device.
   */
  async apply(input:unknown,changes:unknown):Promise<SyncApplyResult>{
    const name=normalizeSyncName(input),now=this.now();
    if(!Array.isArray(changes)||!changes.length||changes.length>100)throw new SyncError("每次需提交 1–100 项同步操作");
    const ops:SyncOperation[]=[],rejected:SyncRejection[]=[];
    for(const change of changes){
      try{ops.push(operation(change,now));}
      catch(error){if(plain(change)&&safeKey(change.id))rejected.push({id:change.id,error:error instanceof SyncError?error.message:"同步操作格式无效"});}
    }
    return this.serial(name,async()=>{
      const profile=await this.load(name);
      let live=Object.values(profile.favorites).filter(entry=>entry.value).length;
      const applied:{op:SyncOperation;map:Record<string,Entry>;previous?:Entry}[]=[];
      for(const op of ops){
        const map=op.kind==="favorite"?profile.favorites:op.kind==="read"?profile.reads:profile.settings;
        const current=own(map,op.key)?map[op.key]:undefined;
        if(op.ifAbsent&&current)continue;
        if(current&&(op.timestamp<current.timestamp||(op.timestamp===current.timestamp&&op.deviceId<=current.deviceId)))continue;
        if(op.kind==="favorite"){
          const adds=!!op.value&&!current?.value,removes=!op.value&&!!current?.value;
          if(adds&&live>=this.maxRecords){rejected.push({id:op.id,error:"收藏数量已达上限，请先取消部分收藏"});continue;}
          live+=adds?1:removes?-1:0;
        }
        applied.push({op,map,previous:current});
        map[op.key]={value:op.value,timestamp:op.timestamp,deviceId:op.deviceId};
      }
      const refusedIds=new Set<string>();
      if(applied.length){
        this.prune(profile);profile.revision++;profile.updatedAt=new Date(now).toISOString();
        let body=JSON.stringify(profile);
        // Full space: first turn back the favorites this batch added, then anything else that is
        // not a removal. Removals always go through so the owner can free space again.
        for(const growing of [(op:SyncOperation)=>op.kind==="favorite"&&!!op.value,(op:SyncOperation)=>!(op.kind==="favorite"&&!op.value)]){
          if(Buffer.byteLength(body)<=this.maxBytes)break;
          for(const item of [...applied].reverse()){
            if(!growing(item.op)||refusedIds.has(item.op.id))continue;
            if(item.previous)item.map[item.op.key]=item.previous;else delete item.map[item.op.key];
            refusedIds.add(item.op.id);rejected.push({id:item.op.id,error:"同步空间已达到容量上限，请先取消部分收藏"});
          }
          body=JSON.stringify(profile);
        }
        await this.save(profile,body);
      }
      const refused=new Set(rejected.map(item=>item.id));
      return {acknowledged:[...ops.map(op=>op.id).filter(id=>!refused.has(id)),...refused],rejected,revision:profile.revision,serverTime:this.now()};
    });
  }
}
