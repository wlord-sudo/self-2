import initial from "./initial-data.json";
import journals from "./journals.json";
import {translations} from "./translations";
import type {Article,Feed,Journal} from "./types";
import {coerceArticle} from "./article-shape";
import {upstreamImage} from "./upstream-image";
export function enrich(article:Article):Article{return {...article,...(translations[article.id]||{})};}
// Server-side fallback only; the browser starts from lib/initial-catalog.ts and loads /api/feed.
const articles:Article[]=[];
for(const raw of initial.articles as unknown[]){
  const article=coerceArticle(raw&&typeof raw==="object"?{...raw,imageUrl:upstreamImage((raw as {imageUrl?:unknown}).imageUrl)}:raw);
  if(article)articles.push(enrich({...article,abstractSource:"upstream",abstractStatus:article.abstract?"available":"missing"}));
}
export const initialFeed:Feed={articles,journals:journals as Journal[],updatedAt:initial.updatedAt,total:articles.length,source:"snapshot",catalogSynced:false};
