import {knownTime} from "./article-shape";

const day=new Intl.DateTimeFormat("zh-CN",{month:"2-digit",day:"2-digit",timeZone:"Asia/Shanghai"});
const dayTime=new Intl.DateTimeFormat("zh-CN",{month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit",hour12:false,timeZone:"Asia/Shanghai"});

// Intl throws RangeError for Invalid Date, which used to blank the whole page.
export function formatDay(value:unknown,fallback="日期未知"):string{const time=knownTime(value);return time===null?fallback:day.format(time);}
export function formatDayTime(value:unknown,fallback="—"):string{const time=knownTime(value);return time===null?fallback:dayTime.format(time);}
