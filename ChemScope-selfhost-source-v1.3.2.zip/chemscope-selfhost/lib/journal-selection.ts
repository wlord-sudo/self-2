import type {Journal} from "./types";
export function defaultJournalIds(journals:Journal[]){return journals.filter(j=>j.defaultOn!==false).map(j=>j.id);}
/** Same journals regardless of order; lets React keep the old array (and the list position). */
export function sameSelection(a:string[],b:string[]){if(a===b)return true;const left=new Set(a),right=new Set(b);if(left.size!==right.size)return false;for(const id of left)if(!right.has(id))return false;return true;}
export function reconcileJournals(selected:string[],known:string[],previousDefaults:string[],catalog:Journal[]){
  const available=new Set(catalog.map(j=>j.id));const result=new Set(selected.filter(id=>available.has(id)));
  const old=new Set(known),oldDefaults=new Set(previousDefaults);
  for(const journal of catalog)if(journal.defaultOn!==false&&(!old.has(journal.id)||!oldDefaults.has(journal.id)))result.add(journal.id);
  return [...result];
}
