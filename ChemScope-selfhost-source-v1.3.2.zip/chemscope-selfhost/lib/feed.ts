import {readFile,writeFile,mkdir,rename} from "node:fs/promises";
import {resolve,dirname} from "node:path";
import {initialFeed,enrich} from "./initial-feed";
import {normalizeCatalog,normalizeArticle,UPSTREAM} from "./upstream-normalize";
import {fetchJson,UpstreamError} from "./upstream-http";
import {normalizedArticleLink} from "./article-utils";
import {coerceArticle,knownTime} from "./article-shape";
import type {Article,Feed,SourceState,Journal} from "./types";
export {initialFeed} from "./initial-feed";

const minutes=Number(process.env.FEED_CACHE_MINUTES||process.env.RSS_CACHE_MINUTES||5);
const ttl=Number.isFinite(minutes)&&minutes>=1?minutes*60000:300000;
const file=resolve(process.env.CACHE_DIR||".cache","api-feed-v3.json");
const legacy=resolve(process.env.CACHE_DIR||".cache","rss-feed-v2.json");
// "Refresh" from any visitor forces a full upstream download; keep a minimum gap so it cannot be used to hammer the source site.
function forceGap(){const value=Number(process.env.FEED_FORCE_MIN_SECONDS??60);return Number.isFinite(value)&&value>=0?value*1000:60000;}
const MAX_RETRY_DELAY=30*60000;
let state:Feed={...initialFeed,sources:{},abstractJobsPending:0};
let initialized:Promise<void>|null=null,refreshing:Promise<void>|null=null;
let lastRefresh=0,lastAttempt=0,retryAt=0,revision=0;let saveTimer:ReturnType<typeof setTimeout>|undefined;
let saveChain=Promise.resolve();
function identity(a:Article){return a.doi?"doi:"+a.doi.toLowerCase():"url:"+normalizedArticleLink(a.link);}
async function initialize(){
  if(!initialized)initialized=(async()=>{
    try{const contents=await readFile(file,"utf8");if(contents.length>32000000)throw new Error();const value=JSON.parse(contents);
      if(value.schemaVersion!==3||!Array.isArray(value.feed?.articles)||!value.feed.articles.length)throw new Error();
      state={...value.feed,journals:normalizeCatalog(value.feed.journals),catalogSynced:true,refreshing:false,abstractJobsPending:0};lastRefresh=Number(value.lastRefresh)||0;
    }catch{
      try{const value=JSON.parse(await readFile(legacy,"utf8"));if(value.schemaVersion===2&&Array.isArray(value.feed?.articles)&&value.feed.articles.length)state={...initialFeed,articles:value.feed.articles,source:"cache",sources:{}};}catch{/* Use the bundled snapshot on the first launch. */}
    }
    // Cache files from older versions may hold records with missing or null fields.
    state.articles=state.articles.map(coerceArticle).filter((a):a is Article=>!!a);
    if(knownTime(state.updatedAt)===null)state.updatedAt=initialFeed.updatedAt;
  })();return initialized;
}
function persist(){
  if(saveTimer)clearTimeout(saveTimer);
  saveTimer=setTimeout(()=>{const json=JSON.stringify({schemaVersion:3,lastRefresh,feed:{...state,refreshing:false,abstractJobsPending:0}});
    saveChain=saveChain.then(async()=>{await mkdir(dirname(file),{recursive:true});await writeFile(file+".tmp",json);await rename(file+".tmp",file);}).catch(error=>console.warn("Feed cache write skipped:",String(error)));
  },200);saveTimer.unref?.();
}
function sourcesFor(catalog:Journal[],articles:Article[],raw:Record<string,any>):Record<string,SourceState>{
  const counts=new Map<string,number>();for(const article of articles)counts.set(article.journalId,(counts.get(article.journalId)||0)+1);
  return Object.fromEntries(catalog.map(j=>{const item=raw?.[j.id]||{};const count=counts.get(j.id)||0;
    return [j.id,{status:item.status==="cached"?"cached":item.status==="error"?(count?"cached":"error"):item.status==="live"||count?"live":"error",count,updatedAt:item.fetchedAt||undefined,message:typeof item.error==="string"?item.error:undefined}];
  }));
}
async function refreshUpstream(){
  let catalog=state.journals,catalogSynced=!!state.catalogSynced;
  try{catalog=normalizeCatalog(await fetchJson(`${UPSTREAM}/api/journals`,15000,2000000));catalogSynced=true;}catch(error){if(!catalog.length)throw error;console.warn("Using cached upstream journal catalog");}
  if(JSON.stringify(catalog)!==JSON.stringify(state.journals)||catalogSynced!==state.catalogSynced){state.journals=catalog;state.catalogSynced=catalogSynced;revision++;}
  const articles:Article[]=[];const seen=new Set<string>();let offset=0;let upstreamSources:Record<string,any>={};let updatedAt=state.updatedAt;
  for(let page=0;page<30;page++){
    const url=new URL("/api/feed",UPSTREAM);url.searchParams.set("journals",catalog.map(j=>j.id).join(","));url.searchParams.set("limit","0");if(offset)url.searchParams.set("offset",String(offset));
    const data=await fetchJson(url.href);if(!Array.isArray(data.articles))throw new Error("来源站文献数据格式异常");
    for(const raw of data.articles){const article=normalizeArticle(raw);if(article&&!seen.has(article.id)){seen.add(article.id);articles.push(article);}}
    upstreamSources={...upstreamSources,...data.sources};if(knownTime(data.updatedAt)!==null)updatedAt=data.updatedAt;
    if(!data.hasMore)break;
    const next=Number(data.nextOffset);if(!Number.isFinite(next)||next<=offset||page===29)throw new Error("来源站分页未完整返回");offset=next;
  }
  if(!articles.length)throw new Error("来源站暂未返回文献");
  const previousById=new Map(state.articles.map(a=>[a.id,a]));const previousByPaper=new Map(state.articles.map(a=>[identity(a),a]));
  // Two upstream records with one DOI must not both inherit the same earlier id (duplicate React keys).
  const used=new Set<string>();
  const normalized=articles.map(article=>{const candidate=previousById.get(article.id)||previousByPaper.get(identity(article));const previous=candidate&&!used.has(candidate.id)?candidate:undefined;const value=previous?{...article,id:previous.id}:enrich(article);used.add(value.id);
    if(previous?.abstract===value.abstract&&previous.abstractZh)value.abstractZh=previous.abstractZh;if(previous?.title===value.title&&previous.titleZh)value.titleZh=previous.titleZh;
    return value;
  });
  state={...state,articles:normalized,journals:catalog,sources:sourcesFor(catalog,normalized,upstreamSources),updatedAt,total:normalized.length,source:"upstream",message:undefined,abstractJobsPending:0};
  lastRefresh=Date.now();retryAt=0;revision++;persist();
}
export async function getFeed(force=false):Promise<Feed>{
  await initialize();
  const now=Date.now(),forced=force&&now-lastAttempt>=forceGap();
  if(!refreshing&&now>=retryAt&&(forced||now-lastRefresh>ttl)){
    lastAttempt=now;
    refreshing=refreshUpstream().catch(error=>{const failedAt=Date.now();retryAt=Math.min(Math.max(failedAt+60000,error instanceof UpstreamError?error.retryAfter:0),failedAt+MAX_RETRY_DELAY);state={...state,source:state.source==="snapshot"?"snapshot":"cache",message:"来源站暂不可用，正在显示最近缓存。"};revision++;persist();console.warn("Upstream refresh unavailable",String(error));}).finally(()=>{refreshing=null;});
  }
  return {...state,refreshing:!!refreshing,total:state.articles.length,revision};
}
export async function getArticleAbstract(id:string){await initialize();return state.articles.find(a=>a.id===id);}
export async function waitForRefresh(){await initialize();if(refreshing)await refreshing;}
export async function sourceHealth(){await initialize();return {revision,refreshing:!!refreshing,sources:state.sources,abstractJobsPending:0};}
