export function doiFromArticleLink(link:string):string{
  try{const url=new URL(link);
    if(url.hostname==="www.nature.com"||url.hostname==="nature.com"){const match=url.pathname.match(/^\/articles\/([a-zA-Z0-9-]+)\/?$/);if(match)return "10.1038/"+match[1].toLowerCase();}
    const match=url.pathname.match(/(10\.\d{4,9}\/[^/?#\s]+(?:\/v\d+)?)/i);return match?decodeURIComponent(match[1]).toLowerCase():"";
  }catch{return "";}
}
export function normalizedArticleLink(link:string){try{const url=new URL(link);url.search="";url.hash="";return (url.origin+url.pathname).replace(/\/$/,"");}catch{return link;}}
