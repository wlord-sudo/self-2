export const UPSTREAM="https://api.baranlab.org";
export function upstreamImage(value:unknown):string|null{
  if(typeof value!=="string"||!value.trim())return null;
  try{const url=new URL(value,UPSTREAM);if(!/^https?:$/.test(url.protocol))return null;if(url.origin===UPSTREAM)return url.href;const proxy=new URL("/api/img",UPSTREAM);proxy.searchParams.set("url",url.href);return proxy.href;}catch{return null;}
}
