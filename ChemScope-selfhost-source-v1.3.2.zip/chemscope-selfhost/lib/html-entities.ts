const named:Record<string,string>={amp:"&",lt:"<",gt:">",quot:"\"",apos:"'",nbsp:" "};

/** Decodes the entities translation services return, in a single pass so "&amp;lt;" stays "&lt;". */
export function decodeEntities(value:string):string{
  return value.replace(/&(#\d{1,7}|#x[0-9a-f]{1,6}|[a-z]{2,6});/gi,(match,body:string)=>{
    if(body[0]==="#"){
      const code=body[1]==="x"||body[1]==="X"?parseInt(body.slice(2),16):parseInt(body.slice(1),10);
      return Number.isInteger(code)&&code>0&&code<=0x10ffff?String.fromCodePoint(code):match;
    }
    return named[body.toLowerCase()]??match;
  });
}
