import type {Article} from "./types";
import {doiFromArticleLink} from "./article-utils";

// Kept free of server-only dependencies: the browser bundle imports this module too.
export const UNKNOWN_DATE=new Date(0).toISOString();

/** Milliseconds for a usable date, or null for missing, unparseable and 1970 placeholder values. */
export function knownTime(value:unknown):number|null{
  if(typeof value!=="string"||!value)return null;
  const time=Date.parse(value);
  return Number.isFinite(time)&&time>0?time:null;
}

export function safeDateString(value:unknown):string{
  return typeof value==="string"&&value.length<=80&&Number.isFinite(Date.parse(value))?value:UNKNOWN_DATE;
}

const text=(value:unknown)=>typeof value==="string"?value:"";

/**
 * Brings an article from any source (bundled snapshot, upstream API, cache files or
 * browser storage written by older versions) to one consistent shape. Null `oa` or
 * `publishedAt` values in the snapshot previously made the sync server reject a favorite.
 * Returns null only when the record cannot be shown or opened at all.
 */
export function coerceArticle(input:unknown):Article|null{
  if(!input||typeof input!=="object"||Array.isArray(input))return null;
  const a=input as Record<string,unknown>;
  if(typeof a.id!=="string"||!a.id||typeof a.title!=="string"||!a.title.trim()||typeof a.link!=="string"||!/^https?:\/\//i.test(a.link))return null;
  const result:Article={
    ...(a as Partial<Article>),
    id:a.id,title:a.title,link:a.link,
    authors:text(a.authors),abstract:text(a.abstract),
    publishedAt:safeDateString(a.publishedAt),
    imageUrl:typeof a.imageUrl==="string"&&a.imageUrl?a.imageUrl:null,
    doi:text(a.doi)||doiFromArticleLink(a.link),
    journalId:text(a.journalId),journalName:text(a.journalName),journalAbbr:text(a.journalAbbr),
    oa:a.oa===true
  };
  if(a.dateEstimated!==undefined&&typeof a.dateEstimated!=="boolean")delete result.dateEstimated;
  return result;
}
