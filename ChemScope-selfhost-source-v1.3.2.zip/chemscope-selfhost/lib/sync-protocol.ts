import type {Article} from "./types";

export type JournalPreferences={enabled:string[];knownJournalIds:string[];defaultJournalIds:string[]};
export type SyncSettings={mode:"bilingual"|"english";autoTranslate:boolean;sort:"newest"|"oldest"|"journal";journalPreferences:JournalPreferences};
export type SyncData={favorites:Record<string,Article>;reads:string[];settings:Partial<SyncSettings>};
export type SyncSnapshot=SyncData&{username:string;revision:number;updatedAt:string;serverTime:number;maxTimestamp:number};
export type SyncOperation={id:string;kind:"favorite"|"read"|"setting";key:string;value:unknown;timestamp:number;deviceId:string;ifAbsent?:boolean};
export type SyncRejection={id:string;error:string};
// `acknowledged` also lists rejected ids, so clients from v1.3.1 drop them instead of retrying forever.
export type SyncApplyResult={acknowledged:string[];rejected:SyncRejection[];revision:number;serverTime:number};
export const SYNC_HEADER="X-ChemScope-Sync";
export const syncRecordKey=(op:Pick<SyncOperation,"kind"|"key">)=>`${op.kind}:${op.key}`;
export const settingKeys=["mode","autoTranslate","sort","journalPreferences"] as const;

export function normalizeSyncName(input:unknown):string{
  if(typeof input!=="string")throw new Error("请输入同步名");
  const value=input.normalize("NFKC").trim().toLowerCase();
  if(!/^[\p{L}\p{N}_.-]{1,64}$/u.test(value))throw new Error("同步名需为 1–64 个中文、字母、数字或 _ . -");
  return value;
}

export function overlayOperations(data:SyncData,operations:SyncOperation[]):SyncData{
  const favorites={...data.favorites},reads=new Set(data.reads),settings={...data.settings};
  for(const op of operations){
    if(op.ifAbsent)continue;
    if(op.kind==="favorite"){if(op.value)favorites[op.key]=op.value as Article;else delete favorites[op.key];}
    else if(op.kind==="read"){if(op.value)reads.add(op.key);else reads.delete(op.key);}
    else if(settingKeys.includes(op.key as keyof SyncSettings))Object.assign(settings,{[op.key]:op.value});
  }
  return {favorites,reads:[...reads],settings};
}
