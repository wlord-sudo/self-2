export type Article = {
  id: string; title: string; authors: string; publishedAt: string;
  abstract: string; imageUrl: string | null; link: string; doi: string;
  journalId: string; journalName: string; journalAbbr: string; oa: boolean;
  titleZh?: string; abstractZh?: string; translationSource?: string;
  abstractSource?: "upstream"|"snapshot";
  abstractStatus?: "available"|"summary"|"missing"|"unavailable";
  abstractCheckedAt?: string;
  dateEstimated?:boolean;sourceType?:string;section?:string|null;
};
export type Journal = {id: string; name: string; abbr: string; publisher: string; color: string; discipline: string;url?:string;nature?:boolean;defaultOn?:boolean;group?:string;sourceType?:string;isNew?:boolean;impact?:string|null;code?:string};
export type SourceState={status:"live"|"cached"|"error"|"refreshing";count:number;updatedAt?:string;message?:string;etag?:string;lastModified?:string;retryAfter?:number;failures?:number};
export type Feed = {articles: Article[]; journals: Journal[]; updatedAt: string; total: number; source?: string;refreshing?:boolean;sources?:Record<string,SourceState>;abstractJobsPending?:number;revision?:number;message?:string;catalogSynced?:boolean};
