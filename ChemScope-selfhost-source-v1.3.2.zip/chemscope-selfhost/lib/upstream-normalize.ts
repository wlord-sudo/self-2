import {parseHTML} from "linkedom";
import type {Article,Journal} from "./types";
import {doiFromArticleLink} from "./article-utils";
import {safeDateString} from "./article-shape";
export {UPSTREAM,upstreamImage} from "./upstream-image";
import {upstreamImage} from "./upstream-image";
function plain(value:unknown):string{
  if(typeof value!=="string")return "";
  const {document}=parseHTML(`<html><body>${value}</body></html>`);
  for(const node of document.querySelectorAll("script,style,noscript"))node.remove();
  for(const node of document.querySelectorAll("p,br"))node.appendChild(document.createTextNode("\n"));
  return (document.body.textContent||"").replace(/\u00a0/g," ").replace(/[ \t]+/g," ").replace(/\n\s*\n/g,"\n").trim();
}
export function normalizeCatalog(value:unknown):Journal[]{
  const entries=Array.isArray(value)?value:(value as any)?.journals;if(!Array.isArray(entries))throw new Error("来源站未返回期刊目录");
  const seen=new Set<string>();const result:Journal[]=[];
  for(const j of entries){if(!j||typeof j.id!=="string"||!j.id||seen.has(j.id)||typeof j.name!=="string"||typeof j.abbr!=="string")continue;seen.add(j.id);
    result.push({...j,publisher:typeof j.publisher==="string"?j.publisher:"",color:/^#[0-9a-f]{6}$/i.test(j.color||"")?j.color:"#28534b",discipline:typeof j.discipline==="string"?j.discipline:"General",defaultOn:j.defaultOn===true,nature:typeof j.url==="string"&&j.url.includes("nature.com/")});
  }
  if(!result.length)throw new Error("来源站期刊目录为空");return result;
}
export function normalizeArticle(a:any):Article|null{
  if(!a||typeof a.id!=="string"||typeof a.title!=="string"||typeof a.link!=="string"||!/^https?:\/\//i.test(a.link))return null;
  const abstract=typeof a.abstract==="string"&&a.abstract.trim()?a.abstract:plain(a.abstractHtml);
  const title=a.title.trim()||plain(a.titleHtml);if(!title)return null;
  const text=(value:unknown)=>typeof value==="string"?value:"";
  return {id:a.id,title,authors:text(a.authors),publishedAt:safeDateString(a.publishedAt),dateEstimated:!!a.dateEstimated,
    abstract,imageUrl:upstreamImage(a.imageUrl),link:a.link,doi:typeof a.doi==="string"&&a.doi?a.doi:doiFromArticleLink(a.link),journalId:text(a.journalId),journalName:text(a.journalName),journalAbbr:text(a.journalAbbr),oa:a.oa===true,
    sourceType:typeof a.sourceType==="string"?a.sourceType:undefined,section:typeof a.section==="string"&&a.section?a.section:null,abstractSource:"upstream",abstractStatus:abstract?"available":"missing"};
}
