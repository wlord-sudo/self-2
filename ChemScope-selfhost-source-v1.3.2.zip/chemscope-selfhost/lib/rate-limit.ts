export type RequestContext={ip?:string};

/** Fixed-window counters per key. In-memory, which matches the single-process deployment. */
export class RateLimiter{
  private buckets=new Map<string,{count:number;reset:number}>();
  constructor(private now=()=>Date.now(),private maxKeys=50000){}
  /** Counts one request. Returns 0 when allowed, otherwise milliseconds until the window resets. */
  hit(key:string,limit:number,windowMs:number):number{
    if(!(limit>0))return 0;
    const now=this.now();let bucket=this.buckets.get(key);
    if(!bucket||bucket.reset<=now){if(this.buckets.size>=this.maxKeys)this.sweep(now);bucket={count:0,reset:now+windowMs};this.buckets.set(key,bucket);}
    if(bucket.count>=limit)return bucket.reset-now;
    bucket.count++;return 0;
  }
  /** Like hit() but without counting: is this key already over its limit? */
  blocked(key:string,limit:number):number{
    if(!(limit>0))return 0;
    const bucket=this.buckets.get(key),now=this.now();
    return bucket&&bucket.reset>now&&bucket.count>=limit?bucket.reset-now:0;
  }
  private sweep(now:number){for(const [key,bucket] of this.buckets)if(bucket.reset<=now)this.buckets.delete(key);if(this.buckets.size>=this.maxKeys)this.buckets.clear();}
}

export const limiter=new RateLimiter();
const perMinute=(name:string,fallback:number)=>{const value=Number(process.env[name]);return process.env[name]!==undefined&&Number.isFinite(value)&&value>=0?value:fallback;};
/** Read at call time so operators (and tests) can tune them; 0 disables a limit. */
export const limits={
  syncPerMinute:()=>perMinute("SYNC_RATE_PER_MINUTE",120),
  translatePerMinute:()=>perMinute("TRANSLATE_RATE_PER_MINUTE",60),
  syncCreatesPerHour:()=>perMinute("SYNC_CREATE_PER_HOUR",10),
  syncMissesPerTenMinutes:()=>perMinute("SYNC_MISSES_PER_10_MINUTES",30)
};
export function clientKey(context:RequestContext={}){return context.ip||"local";}
export function tooManyRequests(retryMs:number,message:string,headers:Record<string,string>={}){
  return Response.json({error:message},{status:429,headers:{...headers,"Retry-After":String(Math.max(1,Math.ceil(retryMs/1000))),"Cache-Control":"no-store"}});
}
