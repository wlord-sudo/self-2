export class UpstreamError extends Error{
  constructor(message:string,public status=0,public retryAfter=0){super(message);}
}
export async function fetchJson(url:string,timeout=45000,maxBytes=18000000):Promise<any>{
  const response=await fetch(url,{headers:{Accept:"application/json"},signal:AbortSignal.timeout(timeout)});
  if(!response.ok){const value=response.headers.get("retry-after")||"";const retryAfter=/^\d+$/.test(value)?Date.now()+Number(value)*1000:Date.parse(value);throw new UpstreamError(`来源站 HTTP ${response.status}`,response.status,Number.isFinite(retryAfter)?retryAfter:0);}
  if(Number(response.headers.get("content-length")||0)>maxBytes)throw new Error("来源站响应超过大小限制");
  const reader=response.body?.getReader();const chunks:Uint8Array[]=[];let length=0;
  if(reader){try{while(true){const {done,value}=await reader.read();if(done)break;length+=value.byteLength;if(length>maxBytes){await reader.cancel();throw new Error("来源站响应超过大小限制");}chunks.push(value);}}finally{reader.releaseLock();}}
  const body=new Uint8Array(length);let offset=0;for(const chunk of chunks){body.set(chunk,offset);offset+=chunk.length;}
  return JSON.parse(new TextDecoder().decode(body));
}
