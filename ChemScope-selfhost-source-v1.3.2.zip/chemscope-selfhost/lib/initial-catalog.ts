import journals from "./journals.json";
import type {Feed,Journal} from "./types";

// The browser no longer bundles the 4 MB article snapshot: the server already falls back to
// it, so the page only needs the journal catalog for its first render.
export const initialCatalogFeed:Feed={articles:[],journals:journals as Journal[],updatedAt:"",total:0,source:"loading",catalogSynced:false};
