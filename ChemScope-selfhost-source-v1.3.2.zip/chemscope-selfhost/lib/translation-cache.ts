import type {Article} from "./types";
export type CachedTranslation={titleZh?:string;abstractZh?:string;titleFingerprint?:string;abstractFingerprint?:string};
export function textFingerprint(value:string){let hash=2166136261;for(let i=0;i<value.length;i++){hash^=value.charCodeAt(i);hash=Math.imul(hash,16777619);}return `${value.length}:${(hash>>>0).toString(16)}`;}
export function withTranslation(article:Article,value?:CachedTranslation):Article{
  if(!value)return article;const result={...article};
  if(value.titleZh&&(!value.titleFingerprint||value.titleFingerprint===textFingerprint(article.title)))result.titleZh=value.titleZh;
  if(value.abstractZh&&value.abstractFingerprint===textFingerprint(article.abstract))result.abstractZh=value.abstractZh;
  return result;
}
