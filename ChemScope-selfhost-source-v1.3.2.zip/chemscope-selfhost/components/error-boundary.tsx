import {Component,type ErrorInfo,type ReactNode} from "react";

// Without a boundary any render error (for example one malformed record) blanks the whole page.
export class ErrorBoundary extends Component<{children:ReactNode},{error:Error|null}>{
  state={error:null as Error|null};
  static getDerivedStateFromError(error:Error){return {error};}
  componentDidCatch(error:Error,info:ErrorInfo){console.error("ChemScope render failed",error,info.componentStack);}
  render(){
    if(!this.state.error)return this.props.children;
    return <main className="crash-screen" role="alert">
      <h1>页面暂时无法显示</h1>
      <p>本机的收藏、已读记录和同步队列不受影响。请先重新加载；如果问题仍然出现，请把下面的信息发给网站管理员。</p>
      <code>{String(this.state.error.message||this.state.error).slice(0,300)}</code>
      <button className="primary-button" onClick={()=>location.reload()}>重新加载</button>
    </main>;
  }
}
