"use client";

import {useState,useEffect,useMemo,useRef,useCallback,useDeferredValue, type ReactNode} from "react";
import {Search,SlidersHorizontal,RefreshCw,ArrowUpRight,Bookmark,Check,ChevronDown,ChevronRight,X,Languages,BookOpen,CheckCheck,Sun,FlaskConical,Atom,Hexagon,ArrowDownWideNarrow,Expand,Copy,LoaderCircle,Library,Command,ArrowRight,Microscope,Menu,Beaker,CheckCircle2,Cloud} from "lucide-react";
import type {Article,Feed,Journal} from "@/lib/types";
import {translateInBrowser} from "@/lib/translate-client";
import {withTranslation,textFingerprint,type CachedTranslation} from "@/lib/translation-cache";
import {defaultJournalIds,reconcileJournals,sameSelection} from "@/lib/journal-selection";
import {coerceArticle,knownTime} from "@/lib/article-shape";
import {formatDay,formatDayTime} from "@/lib/format-date";
import {useReaderSync} from "./use-reader-sync";
import {SyncSettings as SyncSettingsPanel} from "./sync-settings";
import type {SyncData,SyncSettings} from "@/lib/sync-protocol";

type Mode="bilingual"|"english";
type Translated=Record<string,CachedTranslation>;
type Topic={id:string;label:string;en:string;pattern:RegExp;icon:typeof Atom};
const topics:Topic[]=[
  {id:"all",label:"全部研究",en:"All research",pattern:/.*/,icon:Library},
  {id:"photo",label:"光催化",en:"Photocatalysis",pattern:/photo(?:redox|catal|induced|sensiti)|visible.light|light.mediated|LMCT/i,icon:Sun},
  {id:"organic",label:"有机合成",en:"Organic synthesis",pattern:/synthesi|cycloaddition|alkylation|coupling|amination|functionalization|Minisci/i,icon:FlaskConical},
  {id:"ch",label:"C–H 官能团化",en:"C–H activation",pattern:/C[−–─—-]H|Minisci|hydrogen.atom.transfer/i,icon:Hexagon},
  {id:"total",label:"天然产物与全合成",en:"Total synthesis",pattern:/total synth|natural product|terpenoid|alkaloid/i,icon:Beaker},
  {id:"asymmetric",label:"不对称催化",en:"Asymmetric catalysis",pattern:/asymmetr|enantioselect|stereoselect|chiral/i,icon:Atom},
  {id:"materials",label:"材料与能源",en:"Materials & energy",pattern:/framework|batter|electrol|nanocrystal|solar|fuel cell|hydrogen evolution|COF|MOF/i,icon:Microscope}
];
const queue:Array<()=>Promise<void>>=[];let running=0;
function schedule<T>(task:()=>Promise<T>):Promise<T>{return new Promise((resolve,reject)=>{queue.push(async()=>{try{resolve(await task());}catch(e){reject(e);}});pump();});}
function pump(){while(running<2&&queue.length){running++;void queue.shift()!().finally(()=>{running--;pump();});}}
const KEYS={saved:"chemscope-saved",reads:"chemscope-reads",translations:"chemscope-translations",settings:"chemscope-settings"};
// Old entries are dropped first; favorites keep their own copy of the translation.
const MAX_TRANSLATIONS=3000;
function readStorage<T>(key:string,fallback:T):T{try{return JSON.parse(localStorage.getItem(key)||"null")??fallback;}catch{return fallback;}}
/** Returns false when the browser refused the write (usually the ~5 MB quota). */
function storeValue(key:string,value:unknown):boolean{
  let json:string;try{json=JSON.stringify(value);}catch{return false;}
  try{localStorage.setItem(key,json);return true;}catch{/* Quota exceeded or storage disabled. */}
  // The translation cache can be rebuilt; favorites, reads and settings cannot.
  if(key!==KEYS.translations){try{localStorage.removeItem(KEYS.translations);localStorage.setItem(key,json);return true;}catch{/* Still no room. */}}
  return false;
}
function keepNewest<T>(value:Record<string,T>,max:number):Record<string,T>{const keys=Object.keys(value);return keys.length<=max?value:Object.fromEntries(keys.slice(keys.length-max).map(key=>[key,value[key]]));}
function sanitizeSaved(value:unknown):Record<string,Article>{
  const result:Record<string,Article>={};
  if(value&&typeof value==="object"&&!Array.isArray(value))for(const [key,item] of Object.entries(value)){const article=coerceArticle(item);if(article&&article.id===key)result[key]=article;}
  return result;
}
function sanitizeReads(value:unknown):string[]{return Array.isArray(value)?value.filter((id):id is string=>typeof id==="string"&&!!id):[];}
function sanitizeTranslations(value:unknown):Translated{
  const result:Translated={};
  if(value&&typeof value==="object"&&!Array.isArray(value))for(const [key,item] of Object.entries(value))if(item&&typeof item==="object"&&!Array.isArray(item))result[key]=item as CachedTranslation;
  return result;
}
type StoredSettings={mode?:Mode;autoTranslate?:boolean;sort?:SyncSettings["sort"];enabled?:string[];knownJournalIds?:string[];defaultJournalIds?:string[]};
const stringList=(value:unknown)=>Array.isArray(value)?value.filter((id):id is string=>typeof id==="string"):null;
const sameList=(a:string[],b:string[])=>a.length===b.length&&a.every((value,index)=>value===b[index]);

function Modal({title,subtitle,children,onClose,wide=false}:{title:string;subtitle?:string;children:ReactNode;onClose:()=>void;wide?:boolean}){
  const ref=useRef<HTMLDivElement>(null);
  useEffect(()=>{
    const before=document.activeElement as HTMLElement|null;const old=document.body.style.overflow;document.body.style.overflow="hidden";
    ref.current?.querySelector<HTMLElement>("button,input,select")?.focus();
    const key=(e:KeyboardEvent)=>{if(e.key==="Escape")onClose();if(e.key!=="Tab")return;const nodes=ref.current?.querySelectorAll<HTMLElement>('button:not(:disabled),input:not(:disabled),select,a[href],[tabindex="0"]');if(!nodes?.length)return;const first=nodes[0],last=nodes[nodes.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}};
    document.addEventListener("keydown",key);return()=>{document.body.style.overflow=old;document.removeEventListener("keydown",key);before?.focus();};
  },[onClose]);
  return <div className="modal-backdrop" onClick={e=>{if(e.currentTarget===e.target)onClose();}}><div ref={ref} role="dialog" aria-modal="true" aria-label={title} className={`modal ${wide?"wide":""}`}><div className="modal-heading"><div><h2>{title}</h2>{subtitle&&<p>{subtitle}</p>}</div><button className="icon-button" aria-label="关闭" onClick={onClose}><X size={21}/></button></div>{children}</div></div>;
}

function PaperCard({article:a,index,journal,mode,saved,read,autoTranslate,onSave,onRead,translate,onZoom,onToast}:{article:Article;index:number;journal?:Journal;mode:Mode;saved:boolean;read:boolean;autoTranslate:boolean;onSave:()=>void;onRead:()=>void;translate:(a:Article,kind:"title"|"abstract")=>Promise<void>;onZoom:()=>void;onToast:(s:string)=>void}){
  const [expanded,setExpanded]=useState(false);const [abstractMode,setAbstractMode]=useState<"zh"|"en"|"both">("zh");
  const [busy,setBusy]=useState<"title"|"abstract"|null>(null);const [error,setError]=useState("");const [imageFailed,setImageFailed]=useState(false);const ref=useRef<HTMLElement>(null);const attempted=useRef(false);
  const doTranslate=useCallback(async(kind:"title"|"abstract",paper:Article=a)=>{setBusy(kind);setError("");try{await translate(paper,kind);}catch(e){setError(e instanceof Error?e.message:"暂时无法翻译，请稍后重试");}finally{setBusy(null);}},[a,translate]);
  useEffect(()=>{
    if(a.titleZh||mode==="english"||!autoTranslate||attempted.current)return;
    const observer=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){attempted.current=true;observer.disconnect();void doTranslate("title");}},{rootMargin:"50px"});if(ref.current)observer.observe(ref.current);return()=>observer.disconnect();
  },[a.titleZh,mode,autoTranslate,doTranslate]);
  const openAbstract=(next:"zh"|"en"|"both")=>{setExpanded(true);setAbstractMode(next);if(next!=="en"&&!a.abstractZh&&a.abstract)void doTranslate("abstract");};
  const copyDoi=async()=>{try{await navigator.clipboard.writeText(a.doi);onToast("DOI 已复制");}catch{onToast("浏览器未允许复制，可在原文页面查看 DOI");}};
  const color=journal?.color||"#24524b";
  return <article ref={ref} className={`paper-card ${read?"is-read":""}`} data-testid="paper-card">
    <div className="paper-visual"><div className="visual-top"><span>GRAPHICAL ABSTRACT</span><span className="paper-index">{String(index+1).padStart(2,"0")}</span></div>
      {a.imageUrl&&!imageFailed?<button className="graphic-button" aria-label={`查看大图：${a.title}`} onClick={onZoom}><img loading={index<2?"eager":"lazy"} src={a.imageUrl} referrerPolicy="no-referrer" alt={`${a.journalAbbr} 论文图文摘要`} onError={()=>setImageFailed(true)}/><span className="image-expand"><Expand size={14}/></span></button>:<div className="no-graphic"><Hexagon size={48} strokeWidth={1}/><span>{a.journalAbbr}</span><small>图文摘要暂不可用</small></div>}
      <div className="visual-bottom"><span style={{color}}>{a.journalAbbr}</span><span title={knownTime(a.publishedAt)===null?"来源站未提供发布日期":a.dateEstimated?"来源站标注为估计日期":"期刊发布日期"}>{a.dateEstimated&&knownTime(a.publishedAt)!==null?"≈ ":""}{formatDay(a.publishedAt)}</span></div>
    </div>
    <div className="paper-content"><div className="paper-meta"><div className="badges"><span className="journal-badge" style={{color,background:`${color}10`}}>{a.journalAbbr}</span><span className="asap-badge">{a.journalId==="chemrxiv"?"PREPRINT":"ASAP"}</span>{a.oa&&<span className="oa-badge">开放获取</span>}{read&&<span className="read-badge"><Check size={11}/> 已读</span>}</div><button aria-label={saved?"取消收藏":"收藏文献"} aria-pressed={saved} className={`save-button ${saved?"saved":""}`} onClick={onSave}><Bookmark size={19} fill={saved?"currentColor":"none"}/></button></div>
      <div className="paper-titles">{mode==="bilingual"&&(a.titleZh?<h2 className="title-zh"><a href={a.link} target="_blank" rel="noopener noreferrer" onClick={onRead}>{a.titleZh}</a></h2>:<button className="translate-title" onClick={()=>void doTranslate("title")} disabled={busy==="title"}>{busy==="title"?<LoaderCircle size={13} className="spin"/>:<Languages size={13}/>} {busy==="title"?"正在翻译标题…":"翻译中文标题"}</button>)}<h3 className={`title-en ${mode==="english"?"primary-title":""}`}><a href={a.link} target="_blank" rel="noopener noreferrer" onClick={onRead}>{a.title}</a></h3></div>
      <p className="authors" title={a.authors}>{a.authors||"作者信息请见原文"}</p>
      <div className={`abstract-area ${expanded?"expanded":""}`}>
        {expanded&&a.abstractStatus==="summary"&&<p className="abstract-provenance">来源站提供的摘要或简介。</p>}
        {expanded?<><div className="abstract-tabs"><button className={abstractMode==="zh"?"active":""} onClick={()=>openAbstract("zh")}>中文译文</button><button className={abstractMode==="en"?"active":""} onClick={()=>setAbstractMode("en")}>英文原文</button><button className={abstractMode==="both"?"active":""} onClick={()=>openAbstract("both")}>中英对照</button><button className="collapse-abstract" aria-label="收起摘要" onClick={()=>setExpanded(false)}><ChevronDown size={14}/></button></div><div className={abstractMode==="both"?"abstract-comparison":""}>
          {abstractMode!=="en"&&<div>{abstractMode==="both"&&<span className="abstract-label">中文译文</span>}{a.abstractZh?<p className="abstract-text zh">{a.abstractZh}</p>:busy==="abstract"?<p className="translation-pending"><LoaderCircle size={15} className="spin"/> 正在翻译摘要，请稍候…</p>:<p className="translation-pending">{a.abstract?"尚未生成中文译文":"期刊源未提供摘要"}{a.abstract&&<button className="text-button" onClick={()=>void doTranslate("abstract")}>翻译摘要</button>}</p>}</div>}
          {abstractMode!=="zh"&&<div>{abstractMode==="both"&&<span className="abstract-label">ABSTRACT</span>}<p className="abstract-text en">{a.abstract||"期刊源未提供摘要，请前往出版社阅读。"}</p></div>}
        </div>{abstractMode!=="en"&&a.abstractZh&&<div className="translation-credit"><Languages size={12}/> 中文辅助译文 · 术语与数据请对照原文</div>}</>:<>{mode==="bilingual"&&a.abstractZh?<p className="abstract-preview zh"><span className="inline-label">中文摘要</span>{a.abstractZh}</p>:<p className="abstract-preview en">{a.abstract||"期刊源未提供摘要，请前往出版社阅读。"}</p>}</>}
      </div>
      {error&&<p className="translation-error" role="status">{error}</p>}
      <div className="paper-actions"><div className="paper-action-left"><a className="full-text" href={a.link} target="_blank" rel="noopener noreferrer" onClick={onRead}>阅读原文 <ArrowUpRight size={14}/></a><button className="abstract-toggle" onClick={()=>expanded?setExpanded(false):openAbstract(mode==="english"?"en":"zh")}>{expanded?"收起摘要":mode==="english"?"Show abstract":a.abstractZh?"展开摘要":"翻译摘要"}{expanded?<ChevronDown size={13} className="rotate"/>:<Languages size={14}/>}</button></div><div className="paper-utilities">{a.doi&&<button className="doi-button" aria-label={`复制 DOI：${a.doi}`} title={a.doi} onClick={()=>void copyDoi()}><Copy size={12}/><span>{a.doi}</span></button>}<button className={`read-button ${read?"active":""}`} aria-label={read?"已标记为已读":"标记已读"} title={read?"已读":"标记已读"} onClick={onRead}><CheckCheck size={16}/></button></div></div>
    </div>
  </article>;
}

export default function Reader({initial}:{initial:Feed}){
  const [feed,setFeed]=useState(initial);const [query,setQuery]=useState("");const deferred=useDeferredValue(query);
  const [journalId,setJournalId]=useState("all");const [topic,setTopic]=useState("all");const [view,setView]=useState<"feed"|"saved">("feed");
  const [readFilter,setReadFilter]=useState("all");const [sort,setSort]=useState<SyncSettings["sort"]>("newest");const [limit,setLimit]=useState(12);
  const [saved,setSaved]=useState<Record<string,Article>>({});const [reads,setReads]=useState<string[]>([]);const [translated,setTranslated]=useState<Translated>({});
  const [mode,setMode]=useState<Mode>("bilingual");const [autoTranslate,setAutoTranslate]=useState(true);
  const [enabled,setEnabled]=useState<string[]>(defaultJournalIds(initial.journals));const [draft,setDraft]=useState<string[]>([]);
  const [dialog,setDialog]=useState<"journals"|"settings"|null>(null);const [journalSearch,setJournalSearch]=useState("");const [zoom,setZoom]=useState<Article|null>(null);
  const [loading,setLoading]=useState(true);const [toast,setToast]=useState("");const [mobileFilters,setMobileFilters]=useState(false);
  const [ready,setReady]=useState(false);const searchRef=useRef<HTMLInputElement>(null);const inflight=useRef(new Map<string,Promise<void>>());
  const knownCatalog=useRef({ids:initial.journals.map(j=>j.id),defaults:defaultJournalIds(initial.journals)});
  const showToast=useCallback((text:string)=>setToast(text),[]);const closeDialog=useCallback(()=>setDialog(null),[]);const closeZoom=useCallback(()=>setZoom(null),[]);
  useEffect(()=>{if(!toast)return;const timer=setTimeout(()=>setToast(""),4000);return()=>clearTimeout(timer);},[toast]);
  const storageWarned=useRef(false);
  const warnStorage=useCallback(()=>{if(storageWarned.current)return;storageWarned.current=true;setToast("浏览器存储空间不足，部分收藏或设置未能保存到本机");},[]);
  const applyStoredSettings=useCallback((value:unknown)=>{
    if(!value||typeof value!=="object"||Array.isArray(value))return;const settings=value as StoredSettings;
    if(settings.mode==="english"||settings.mode==="bilingual")setMode(settings.mode);
    if(typeof settings.autoTranslate==="boolean")setAutoTranslate(settings.autoTranslate);
    if(settings.sort&&["newest","oldest","journal"].includes(settings.sort))setSort(settings.sort);
    const ids=stringList(settings.enabled),known=stringList(settings.knownJournalIds),defaults=stringList(settings.defaultJournalIds);
    if(ids)setEnabled(current=>sameSelection(current,ids)?current:ids);
    if(known)knownCatalog.current.ids=known;
    if(defaults)knownCatalog.current.defaults=defaults;
  },[]);
  useEffect(()=>{
    const storedSaved=sanitizeSaved(readStorage<unknown>(KEYS.saved,{}));setSaved(storedSaved);
    setReads(sanitizeReads(readStorage<unknown>(KEYS.reads,[])));
    // Legacy translations without a fingerprint belong to the abstract that was shown at the time.
    const tr=sanitizeTranslations(readStorage<unknown>(KEYS.translations,{}));
    for(const [id,value] of Object.entries(tr)){const previous=storedSaved[id];if(value.abstractZh&&!value.abstractFingerprint&&previous)value.abstractFingerprint=textFingerprint(previous.abstract);}
    setTranslated(tr);
    applyStoredSettings(readStorage<unknown>(KEYS.settings,{}));
    setReady(true);
  },[applyStoredSettings]);
  useEffect(()=>{
    if(!ready||!feed.articles.length)return;
    setTranslated(prev=>{let next:Translated|null=null;for(const a of feed.articles){const value=prev[a.id];if(value?.abstractZh&&!value.abstractFingerprint){next??={...prev};next[a.id]={...value,abstractFingerprint:textFingerprint(a.abstract)};}}return next??prev;});
  },[ready,feed.articles]);
  useEffect(()=>{
    if(!ready)return;
    // Another tab of this site changed local data: adopt it so this tab never writes a stale copy back over it.
    const handler=(event:StorageEvent)=>{
      if(!event.key||event.newValue===null)return;
      let value:unknown;try{value=JSON.parse(event.newValue);}catch{return;}
      if(event.key===KEYS.saved)setSaved(sanitizeSaved(value));
      else if(event.key===KEYS.reads){const next=sanitizeReads(value);setReads(current=>sameList(current,next)?current:next);}
      else if(event.key===KEYS.translations)setTranslated(sanitizeTranslations(value));
      else if(event.key===KEYS.settings)applyStoredSettings(value);
    };
    window.addEventListener("storage",handler);return()=>window.removeEventListener("storage",handler);
  },[ready,applyStoredSettings]);
  const applySyncedData=useCallback((data:SyncData)=>{
    setSaved(data.favorites);setReads(current=>sameList(current,data.reads)?current:data.reads);
    if(data.settings.mode)setMode(data.settings.mode);
    if(typeof data.settings.autoTranslate==="boolean")setAutoTranslate(data.settings.autoTranslate);
    if(data.settings.sort)setSort(data.settings.sort);
    const preferences=data.settings.journalPreferences;
    if(preferences){
      const next=feed.catalogSynced?reconcileJournals(preferences.enabled,preferences.knownJournalIds,preferences.defaultJournalIds,feed.journals):preferences.enabled;
      knownCatalog.current=feed.catalogSynced?{ids:feed.journals.map(j=>j.id),defaults:defaultJournalIds(feed.journals)}:{ids:preferences.knownJournalIds,defaults:preferences.defaultJournalIds};
      // A new array with the same journals would reset the list to its first 12 papers after every sync.
      setEnabled(current=>sameSelection(current,next)?current:next);setJournalId(current=>current==="all"||next.includes(current)?current:"all");
    }
  },[feed.journals,feed.catalogSynced]);
  const personalSync=useReaderSync(ready,{favorites:saved,reads,settings:{mode,autoTranslate,sort,journalPreferences:{enabled,knownJournalIds:knownCatalog.current.ids,defaultJournalIds:knownCatalog.current.defaults}}},applySyncedData);
  const changeMode=(value:Mode)=>{setMode(value);personalSync.enqueue("setting","mode",value);};
  const changeAutoTranslate=(value:boolean)=>{setAutoTranslate(value);personalSync.enqueue("setting","autoTranslate",value);};
  const changeSort=(value:SyncSettings["sort"])=>{setSort(value);personalSync.enqueue("setting","sort",value);};
  const changeJournals=(value:string[])=>{setEnabled(value);personalSync.enqueue("setting","journalPreferences",{enabled:value,knownJournalIds:knownCatalog.current.ids,defaultJournalIds:knownCatalog.current.defaults});};
  const refreshTimer=useRef<ReturnType<typeof setTimeout>|null>(null);const mounted=useRef(true);const pollCount=useRef(0);const lastRevision=useRef(-1);
  const refresh=useCallback(async(manual=false,statusOnly=false):Promise<void>=>{
    if(manual)pollCount.current=0;
    if(refreshTimer.current)clearTimeout(refreshTimer.current);setLoading(true);
    // Poll quickly at first, then slowly; when the budget runs out, release the refresh button
    // instead of leaving it disabled for a slow upstream refresh.
    const poll=(active:boolean)=>{if(!active)return;if(pollCount.current<160){pollCount.current++;refreshTimer.current=setTimeout(()=>{void refresh(false,true);},pollCount.current<=40?1500:5000);}else setLoading(false);};
    try{
      if(statusOnly){const statusResponse=await fetch("/api/status",{cache:"no-store"});if(!statusResponse.ok)throw new Error();const status=await statusResponse.json() as {revision:number;refreshing:boolean;sources:Feed["sources"];abstractJobsPending:number};
        if(!mounted.current)return;
        if(status.revision===lastRevision.current){setFeed(prev=>({...prev,...status}));setLoading(status.refreshing);poll(status.refreshing||!!status.abstractJobsPending);return;}
      }
      const response=await fetch(manual?"/api/feed?refresh=1":"/api/feed",{cache:"no-store"});if(!response.ok)throw new Error();const data=await response.json() as Feed;
      if(!mounted.current)return;lastRevision.current=data.revision??0;setFeed(data);setLoading(!!data.refreshing);
      if(manual)showToast(data.refreshing?"正在同步原站期刊与文献，已先显示缓存":"已显示来源站最近可用文献");
      poll(!!data.refreshing||!!data.abstractJobsPending);
    }catch{if(manual)showToast("网络暂不可用，已保留当前文献");setFeed(prev=>prev.source==="loading"?{...prev,source:"unavailable"}:prev);setLoading(false);}
  },[showToast]);
  useEffect(()=>{mounted.current=true;void refresh();return()=>{mounted.current=false;if(refreshTimer.current)clearTimeout(refreshTimer.current);};},[refresh]);
  useEffect(()=>{if(!ready||!feed.catalogSynced)return;const previous=knownCatalog.current;setEnabled(current=>{const next=reconcileJournals(current,previous.ids,previous.defaults,feed.journals);return sameSelection(next,current)?current:next;});knownCatalog.current={ids:feed.journals.map(j=>j.id),defaults:defaultJournalIds(feed.journals)};},[ready,feed.journals,feed.catalogSynced]);
  useEffect(()=>{if(ready&&!storeValue(KEYS.settings,{mode,autoTranslate,sort,enabled,knownJournalIds:knownCatalog.current.ids,defaultJournalIds:knownCatalog.current.defaults}))warnStorage();},[ready,mode,autoTranslate,sort,enabled,feed.journals,warnStorage]);
  useEffect(()=>{if(ready&&!storeValue(KEYS.saved,saved))warnStorage();},[ready,saved,warnStorage]);
  useEffect(()=>{if(ready&&!storeValue(KEYS.reads,reads))warnStorage();},[ready,reads,warnStorage]);
  // The translation cache is the first thing to shrink when the browser quota is reached.
  useEffect(()=>{if(!ready||storeValue(KEYS.translations,translated))return;const count=Object.keys(translated).length;if(count>100)setTranslated(current=>keepNewest(current,Math.floor(count/2)));},[ready,translated]);
  useEffect(()=>{if(personalSync.state.notice)showToast(personalSync.state.notice);},[personalSync.state.notice,showToast]);
  useEffect(()=>{const handler=(e:KeyboardEvent)=>{if(e.key==="/"&&!(e.target instanceof HTMLInputElement)&&!(e.target instanceof HTMLTextAreaElement)){e.preventDefault();searchRef.current?.focus();}};document.addEventListener("keydown",handler);return()=>document.removeEventListener("keydown",handler);},[]);
  useEffect(()=>setLimit(12),[deferred,journalId,topic,view,readFilter,sort,enabled]);
  const translate=useCallback((a:Article,kind:"title"|"abstract"):Promise<void>=>{
    const key=`${a.id}:${kind}:${textFingerprint(kind==="title"?a.title:a.abstract)}`;if(inflight.current.has(key))return inflight.current.get(key)!;
    const job=schedule(async()=>{
      const input=kind==="title"?a.title:a.abstract;let value:string;
      try{value=await translateInBrowser(input);}catch{
        const response=await fetch("/api/translate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({text:input})});
        const data=await response.json() as {text?:string;error?:string};if(!response.ok||!data.text)throw new Error(data.error||"翻译暂不可用");value=data.text;
      }
      // Re-inserting the entry keeps the newest translations at the end for keepNewest().
      setTranslated(prev=>{const {[a.id]:previous,...rest}=prev;return keepNewest({...rest,[a.id]:{...previous,[kind==="title"?"titleZh":"abstractZh"]:value,[kind==="title"?"titleFingerprint":"abstractFingerprint"]:textFingerprint(input)}},MAX_TRANSLATIONS);});
    });
    inflight.current.set(key,job);void job.finally(()=>inflight.current.delete(key)).catch(()=>{});return job;
  },[]);
  const readSet=useMemo(()=>new Set(reads),[reads]);
  const articles=useMemo(()=>{
    const list=view==="saved"?Object.values(saved):feed.articles;
    const selectedTopic=topics.find(t=>t.id===topic)!;const q=deferred.trim().toLowerCase();
    const selected=new Set(enabled),times=new Map<string,number|null>();
    const timeOf=(a:Article)=>{if(!times.has(a.id))times.set(a.id,knownTime(a.publishedAt));return times.get(a.id)!;};
    // Papers without a usable date go last in both date orders instead of showing as 1970.
    const byDate=(a:Article,b:Article)=>{const x=timeOf(a),y=timeOf(b);if(x===null||y===null)return x===null?(y===null?0:1):-1;return sort==="oldest"?x-y:y-x;};
    return list.map(a=>withTranslation(a,translated[a.id])).filter(a=>(view==="saved"||selected.has(a.journalId))&&(journalId==="all"||a.journalId===journalId)&&selectedTopic.pattern.test(a.title+" "+a.abstract)&&(readFilter==="all"||(readFilter==="read"?readSet.has(a.id):!readSet.has(a.id)))&&(!q||[a.title,a.titleZh,a.abstract,a.abstractZh,a.authors,a.doi,a.journalAbbr].join(" ").toLowerCase().includes(q))).sort((a,b)=>sort==="journal"?a.journalAbbr.localeCompare(b.journalAbbr):byDate(a,b));
  },[feed.articles,saved,translated,view,enabled,journalId,topic,readFilter,readSet,deferred,sort]);
  const counts=useMemo(()=>{const result:Record<string,number>={};for(const a of feed.articles)result[a.journalId]=(result[a.journalId]||0)+1;return result;},[feed.articles]);
  const enabledCount=useMemo(()=>[...new Set(enabled)].reduce((total,id)=>total+(counts[id]||0),0),[enabled,counts]);
  const clearFilters=()=>{setQuery("");setJournalId("all");setTopic("all");setReadFilter("all");};
  const toggleSave=(a:Article)=>{
    const value=saved[a.id]?null:coerceArticle(withTranslation(a,translated[a.id]));
    if(!saved[a.id]&&!value){showToast("这篇文献缺少标题或原文链接，暂时无法收藏");return;}
    setSaved(prev=>{const next={...prev};if(value)next[a.id]=value;else delete next[a.id];return next;});personalSync.enqueue("favorite",a.id,value);showToast(value?(personalSync.state.username?"已加入收藏 · 将自动同步":"已加入收藏 · 可在阅读设置开启跨设备同步"):"已取消收藏");
  };
  const markRead=(id:string)=>{if(readSet.has(id))return;setReads(prev=>prev.includes(id)?prev:[...prev,id]);personalSync.enqueue("read",id,true);};
  const currentTopic=topics.find(t=>t.id===topic)!;
  const hasFilters=!!query||journalId!=="all"||topic!=="all"||readFilter!=="all";
  return <><header className="site-header"><div className="header-inner"><a href="/" className="brand" aria-label="ChemScope 化学速览首页"><img src="/favicon.svg" alt=""/><div><span className="brand-name">ChemScope<span className="brand-cn">化学速览</span></span><span className="brand-tagline">A LITTLE CLOSER TO DISCOVERY</span></div></a><nav className="main-nav" aria-label="主导航"><button className={view==="feed"?"active":""} onClick={()=>{setView("feed");clearFilters();}}><BookOpen size={16}/>文献动态</button><button className={view==="saved"?"active":""} onClick={()=>{setView("saved");clearFilters();}}><Bookmark size={16}/>我的收藏{Object.keys(saved).length>0&&<span>{Object.keys(saved).length}</span>}</button></nav><div className="header-actions"><button className="icon-button settings-button" aria-label="阅读设置" onClick={()=>setDialog("settings")}><SlidersHorizontal size={19}/></button><button className="refresh-button" disabled={loading} onClick={()=>void refresh(true)}><RefreshCw size={15} className={loading?"spin":""}/><span>{loading?"同步中":"刷新文献"}</span></button></div></div></header>
    <main className="page-shell"><section className="intro"><div><div className="eyebrow"><span/> THE CHEMISTRY BRIEF</div><h1>{view==="saved"?"值得留存的每一次发现。":"化学新进展，双语即刻读。"}</h1><p>{view==="saved"?"Your next idea might be waiting in your reading list.":"Fresh research. Two languages. A clearer perspective."}</p><button className="personal-sync-entry" onClick={()=>setDialog("settings")}><Cloud size={13}/><span>{personalSync.state.username?`同步：${personalSync.state.username}`:"开启跨设备同步"}</span>{personalSync.state.username&&<i className={personalSync.state.phase==="offline"?"offline":""}/>}</button></div><div className="intro-status"><div className="sync-label"><span className={loading?"status-dot loading":"status-dot"}/>{loading?"正在同步来源站":feed.source==="upstream"?"来源站数据已同步":feed.source==="loading"||feed.source==="unavailable"?"文献尚未加载":"最近保存的文献"}</div><span>更新于 {formatDayTime(feed.updatedAt)} <small>UTC+8</small></span></div></section>
      <section className="discovery-bar" aria-label="搜索和期刊筛选"><div className="search-row"><div className="search-input"><Search size={19}/><input ref={searchRef} type="search" placeholder="搜索标题、作者、DOI 或关键词…" aria-label="搜索文献" value={query} onChange={e=>setQuery(e.target.value)}/>{query?<button aria-label="清除搜索" onClick={()=>setQuery("")}><X size={15}/></button>:<kbd>/</kbd>}</div><button className="journal-manage" onClick={()=>{setDraft(enabled);setJournalSearch("");setDialog("journals");}}><SlidersHorizontal size={16}/>期刊管理<span>{enabled.length}</span></button><button className="mobile-filter-button icon-button" aria-label="展开研究主题筛选" onClick={()=>setMobileFilters(!mobileFilters)}><Menu size={20}/></button></div><div className="journal-strip" role="tablist" aria-label="按期刊筛选"><button role="tab" aria-selected={journalId==="all"} className={journalId==="all"?"journal-chip selected":"journal-chip"} onClick={()=>setJournalId("all")}>全部期刊<span>{enabledCount}</span></button>{feed.journals.filter(j=>enabled.includes(j.id)).map(j=><button key={j.id} role="tab" aria-selected={journalId===j.id} className={`journal-chip ${journalId===j.id?"selected":""}`} onClick={()=>setJournalId(j.id)}><i style={{background:j.color}}/>{j.abbr}<span>{counts[j.id]||0}</span></button>)}</div></section>
      <div className="reader-layout"><aside className={`sidebar ${mobileFilters?"mobile-open":""}`}><div className="sidebar-title">研究主题 <span>RESEARCH TOPICS</span></div><div className="topic-list">{topics.map(t=><button key={t.id} className={topic===t.id?"active":""} onClick={()=>{setTopic(t.id);setMobileFilters(false);}}><t.icon size={17} strokeWidth={1.65}/><span>{t.label}</span>{topic===t.id&&<ChevronRight size={14}/>}</button>)}</div><div className="sidebar-divider"/><div className="sidebar-title">阅读状态 <span>READING STATUS</span></div><div className="status-filters">{[{id:"all",name:"全部文献",icon:BookOpen},{id:"unread",name:"尚未阅读",icon:BookOpen},{id:"read",name:"已经读过",icon:CheckCheck}].map(s=><button key={s.id} className={readFilter===s.id?"active":""} onClick={()=>{setReadFilter(s.id);setMobileFilters(false);}}><s.icon size={16}/>{s.name}{readFilter===s.id&&<span/>}</button>)}</div><button className="mobile-settings" onClick={()=>setDialog("settings")}><SlidersHorizontal size={15}/>阅读设置<ChevronRight size={13}/></button><div className="reading-note"><Languages size={25} strokeWidth={1.4}/><h3>让好研究，更好读。</h3><p>中英标题，双语摘要。<br/>从看见新文献，到读懂新发现。</p><button onClick={()=>setDialog("settings")}>调整阅读偏好 <ArrowRight size={13}/></button></div><div className="sidebar-foot"><span className="tiny-dot"/>{feed.journals.length} 本可选期刊 <span>·</span> 双语阅读</div></aside>
        <section className="feed-section" aria-label="文献列表"><div className="feed-toolbar"><div className="feed-title"><h2>{view==="saved"?"我的收藏":journalId!=="all"?feed.journals.find(j=>j.id===journalId)?.abbr:topic!=="all"?currentTopic.label:"最新文献"}</h2><span>{articles.length.toLocaleString()} 篇</span>{hasFilters&&<button className="clear-filters" onClick={clearFilters}>清除筛选 <X size={11}/></button>}</div><div className="view-controls"><div className="language-switch" aria-label="标题显示语言"><button aria-pressed={mode==="bilingual"} className={mode==="bilingual"?"active":""} onClick={()=>changeMode("bilingual")}><Languages size={13}/>双语</button><button aria-pressed={mode==="english"} className={mode==="english"?"active":""} onClick={()=>changeMode("english")}>EN</button></div><label className="sort-control"><ArrowDownWideNarrow size={14}/><select aria-label="文献排序" value={sort} onChange={e=>changeSort(e.target.value as SyncSettings["sort"])}><option value="newest">最新优先</option><option value="oldest">最早优先</option><option value="journal">按期刊排序</option></select><ChevronDown size={12}/></label></div></div>
          {view==="saved"&&<p className="saved-note">{personalSync.state.username?`收藏与阅读状态同步至「${personalSync.state.username}」。`:"收藏保存在本机；在阅读设置中输入同步名，即可跨设备同步。"}</p>}
          <div className="papers">{articles.slice(0,limit).map((a,i)=><PaperCard key={a.id} article={a} index={i} journal={feed.journals.find(j=>j.id===a.journalId)} mode={mode} saved={!!saved[a.id]} read={readSet.has(a.id)} autoTranslate={autoTranslate&&ready} onSave={()=>toggleSave(a)} onRead={()=>markRead(a.id)} translate={translate} onZoom={()=>setZoom(a)} onToast={showToast}/>)}</div>
          {!articles.length&&(view==="feed"&&!feed.articles.length&&(loading||feed.source==="loading")?<div className="empty-state loading-state" role="status"><LoaderCircle size={34} strokeWidth={1.4} className="spin"/><h3>正在加载最新文献…</h3><p>首次打开需要从服务器取回文献列表。</p></div>:view==="feed"&&!feed.articles.length&&feed.source==="unavailable"?<div className="empty-state"><Search size={38} strokeWidth={1.2}/><h3>暂时无法连接服务器</h3><p>网络恢复后点击重试；收藏和已读记录保存在本机，不会丢失。</p><button className="primary-button" onClick={()=>void refresh()}>重试 <RefreshCw size={14}/></button></div>:<div className="empty-state">{view==="saved"?<Bookmark size={38} strokeWidth={1.2}/>:<Search size={38} strokeWidth={1.2}/>}<h3>{view==="saved"&&!Object.keys(saved).length?"把下一次灵感，留在这里。":"暂时没有匹配的文献"}</h3><p>{view==="saved"&&!Object.keys(saved).length?"点击论文右上角的书签，即可加入收藏。":"试试其他关键词，或清除期刊与主题筛选。"}</p><button className="primary-button" onClick={()=>{clearFilters();if(view==="saved"&&!Object.keys(saved).length)setView("feed");}}>浏览文献 <ArrowRight size={14}/></button></div>)}
          {articles.length>limit&&<button className="load-more" onClick={()=>setLimit(prev=>prev+12)}>继续阅读 <span>还有 {articles.length-limit} 篇</span><ChevronDown size={16}/></button>}
          {articles.length>0&&<div className="feed-end"><span/> KEEP YOUR CURIOSITY ALIVE <span/></div>}
        </section></div>
      <footer className="site-footer"><div><span className="footer-brand">ChemScope <b>化学速览</b></span><span>为每一次化学发现，打开另一种语言。</span></div><div><span>文献来源：ChemASAP（api.baranlab.org）</span><span>独立双语阅读页 · 版权归原作者及出版社所有</span></div></footer>
    </main>
    {dialog==="journals"&&<Modal title="选择你关注的期刊" subtitle="可选期刊与原站动态同步；默认选择与原站一致。" onClose={closeDialog}><div className="modal-search"><Search size={16}/><input aria-label="搜索期刊" placeholder="搜索期刊名称…" value={journalSearch} onChange={e=>setJournalSearch(e.target.value)}/></div><div className="selection-tools"><span>已选择 {draft.length} / {feed.journals.length} 本</span><button onClick={()=>setDraft(feed.journals.map(j=>j.id))}>全选</button><button onClick={()=>setDraft(defaultJournalIds(feed.journals))}>恢复默认</button><button onClick={()=>setDraft([])}>清空</button></div><div className="journal-list">{feed.journals.filter(j=>(j.name+" "+j.abbr).toLowerCase().includes(journalSearch.toLowerCase())).map(j=><label key={j.id} className="journal-option"><input type="checkbox" checked={draft.includes(j.id)} onChange={e=>setDraft(prev=>e.target.checked?[...prev,j.id]:prev.filter(x=>x!==j.id))}/><i style={{background:j.color}}/><span><strong>{j.abbr}</strong><small>{j.name}{j.defaultOn===false?" · 可选":""}</small></span><b>{counts[j.id]||0}</b>{feed.sources?.[j.id]&&<small className={`source-status ${feed.sources[j.id].status}`} title={feed.sources[j.id].message||""}>{({live:"来源站数据",cached:"来源站缓存",error:"暂不可用",refreshing:"更新中"} as Record<string,string>)[feed.sources[j.id].status]}</small>}</label>)}</div><div className="modal-bottom"><button className="secondary-button" onClick={closeDialog}>取消</button><button className="primary-button" onClick={()=>{changeJournals(draft);if(!draft.includes(journalId))setJournalId("all");closeDialog();showToast("期刊偏好已保存");}}>保存选择 <Check size={15}/></button></div></Modal>}
    {dialog==="settings"&&<Modal title="你的阅读偏好" subtitle="更少干扰，更专注于发现。" onClose={closeDialog}><div className="settings-body"><SyncSettingsPanel sync={personalSync} localFavorites={Object.keys(saved).length} localReads={reads.length}/><h3>标题显示</h3><div className="mode-options"><button className={mode==="bilingual"?"selected":""} onClick={()=>changeMode("bilingual")}><Languages size={23}/><strong>中英双语</strong><span>中文标题 + 英文原题</span>{mode==="bilingual"&&<CheckCircle2 size={17}/>}</button><button className={mode==="english"?"selected":""} onClick={()=>changeMode("english")}><BookOpen size={23}/><strong>英文原文</strong><span>保持原始阅读体验</span>{mode==="english"&&<CheckCircle2 size={17}/>}</button></div><label className="setting-toggle"><div><strong>自动翻译新标题</strong><p>进入视野的文献按需翻译，已有译文优先复用。</p></div><input type="checkbox" checked={autoTranslate} onChange={e=>changeAutoTranslate(e.target.checked)}/></label><div className="setting-info"><Languages size={17}/><p>摘要可按需翻译，并支持中英对照。在线翻译使用公共翻译服务，免费服务有使用额度；译文会保存在当前浏览器中。</p></div></div><div className="modal-bottom"><span className="auto-saved"><Check size={13}/>{personalSync.state.username?"偏好已保存在本机并自动同步":"偏好自动保存到本设备"}</span><button className="primary-button" onClick={closeDialog}>完成 <Check size={15}/></button></div></Modal>}
    {zoom&&<Modal wide title="图文摘要" subtitle={zoom.titleZh||zoom.title} onClose={closeZoom}><div className="zoom-image"><img src={zoom.imageUrl||""} referrerPolicy="no-referrer" alt={zoom.title}/></div><div className="modal-bottom"><span>{zoom.journalAbbr}</span><a href={zoom.link} target="_blank" rel="noopener noreferrer" className="primary-button" onClick={()=>markRead(zoom.id)}>阅读原文 <ArrowUpRight size={15}/></a></div></Modal>}
    {toast&&<div className="toast" role="status"><CheckCircle2 size={17}/>{toast}</div>}
  </>;
}
