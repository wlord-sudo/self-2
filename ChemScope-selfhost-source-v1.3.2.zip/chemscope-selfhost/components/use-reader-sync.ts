import {useCallback,useEffect,useRef,useState} from "react";
import {SyncClient,localSyncState} from "../lib/sync-client";
import type {SyncData,SyncOperation} from "../lib/sync-protocol";

export function useReaderSync(ready:boolean,local:SyncData,onData:(data:SyncData)=>void){
  const [state,setState]=useState(localSyncState);const client=useRef<SyncClient|null>(null);
  const localRef=useRef(local),applyRef=useRef(onData);localRef.current=local;applyRef.current=onData;
  useEffect(()=>{
    if(!ready)return;
    // Access to localStorage itself can throw in restrictive browser modes.
    let storage:Storage;try{storage=window.localStorage;}catch{return;}
    const instance=new SyncClient({storage,onData:data=>applyRef.current(data),onState:setState});client.current=instance;
    if(instance.rememberedName)void instance.connect(instance.rememberedName,localRef.current,false);
    const tick=()=>{if(document.visibilityState!=="hidden")void instance.sync();};
    const timer=setInterval(tick,15000);window.addEventListener("focus",tick);window.addEventListener("online",tick);document.addEventListener("visibilitychange",tick);
    return()=>{clearInterval(timer);window.removeEventListener("focus",tick);window.removeEventListener("online",tick);document.removeEventListener("visibilitychange",tick);instance.dispose();client.current=null;};
  },[ready]);
  const connect=useCallback(async(name:string,mergeLocal=true)=>{if(!client.current)throw new Error("浏览器存储不可用，请允许此网站保存本地数据");await client.current.connect(name,localRef.current,mergeLocal);},[]);
  const enqueue=useCallback((kind:SyncOperation["kind"],key:string,value:unknown)=>client.current?.enqueue(kind,key,value),[]);
  const sync=useCallback(()=>client.current?.sync(),[]);
  const disconnect=useCallback(()=>client.current?.disconnect(),[]);
  return {state,connect,enqueue,sync,disconnect};
}
