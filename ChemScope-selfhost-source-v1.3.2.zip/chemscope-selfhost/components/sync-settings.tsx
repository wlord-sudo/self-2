import {useState} from "react";
import {Cloud,CloudOff,RefreshCw,CheckCircle2,LogOut,Dices} from "lucide-react";
import type {useReaderSync} from "./use-reader-sync";

// No 0/o/1/l/i so a generated name survives being read aloud or copied by hand.
const ALPHABET="abcdefghjkmnpqrstuvwxyz23456789";
export function randomSyncName(){
  const bytes=new Uint8Array(12);crypto.getRandomValues(bytes);
  const chars=Array.from(bytes,b=>ALPHABET[b%ALPHABET.length]).join("");
  return `chem-${chars.slice(0,4)}-${chars.slice(4,8)}-${chars.slice(8)}`;
}

export function SyncSettings({sync,localFavorites=0,localReads=0}:{sync:ReturnType<typeof useReaderSync>;localFavorites?:number;localReads?:number}){
  const {state}=sync;const [name,setName]=useState("");const [merge,setMerge]=useState(true);const [error,setError]=useState("");
  const active=!!state.username,busy=state.phase==="connecting"||state.phase==="syncing";
  const connect=async()=>{setError("");try{await sync.connect(name,merge);}catch(e){setError(e instanceof Error?e.message:"连接失败，请重试");}};
  const generate=()=>{try{setName(randomSyncName());setError("");}catch{setError("浏览器不支持安全随机数，请手动输入较长的同步名");}};
  return <section className="personal-sync-card" aria-label="跨设备同步">
    <div className="personal-sync-heading"><Cloud size={20}/><div><h3>跨设备同步</h3><p>收藏、已读、期刊选择和阅读偏好，随你一起切换设备。</p></div></div>
    {active?<>
      <div className="sync-identity"><span>同步名</span><strong>{state.username}</strong><button type="button" onClick={()=>sync.disconnect()}><LogOut size={13}/>断开</button></div>
      <div className={`personal-sync-state ${state.phase==="offline"?"offline":""}`} role="status">
        {busy?<RefreshCw size={14} className="spin"/>:state.phase==="offline"?<CloudOff size={14}/>:<CheckCircle2 size={14}/>}
        <span>{busy?"正在同步…":state.phase==="offline"?"连接中断，更改已留在本机":"已同步"}{state.pending>0?` · ${state.pending} 项待上传`:state.lastSynced?` · ${new Date(state.lastSynced).toLocaleTimeString("zh-CN",{hour:"2-digit",minute:"2-digit",hour12:false})}`:""}</span>
        <button type="button" disabled={busy} onClick={()=>void sync.sync()}>{state.phase==="offline"?"重试":"立即同步"}</button>
      </div>
      {state.error&&<p className="personal-sync-error">{state.error}</p>}
      {state.notice&&state.notice!==state.error&&<p className="personal-sync-error">{state.notice}</p>}
      <p className="personal-sync-help">在其他设备打开同一个网站，输入以上同步名即可。断开后，本机保留断开时的收藏与已读，之后的更改不再同步。</p>
    </>:<>
      <form className="sync-name-form" onSubmit={e=>{e.preventDefault();void connect();}}><label htmlFor="sync-name">同步名</label><div><input id="sync-name" name="sync-name" autoComplete="off" autoCapitalize="none" spellCheck={false} maxLength={64} placeholder="新空间至少 8 个字符，建议随机生成" value={name} onChange={e=>setName(e.target.value)}/><button type="button" className="secondary-button sync-random" onClick={generate}><Dices size={14}/>随机生成</button><button type="submit" className="primary-button" disabled={!name.trim()}>连接同步 <Cloud size={14}/></button></div></form>
      <label className="sync-merge-option"><input type="checkbox" checked={merge} onChange={e=>setMerge(e.target.checked)}/>合并本机已有的收藏与已读记录</label>
      {!merge&&(localFavorites>0||localReads>0)&&<p className="personal-sync-warning" role="note">不合并时，本机现有的 {localFavorites} 篇收藏和 {localReads} 条已读记录不会上传，连接后会被同步空间中的内容替换。</p>}
      {error&&<p className="personal-sync-error" role="alert">{error}</p>}
      <p className="personal-sync-help">首次输入会自动创建空间；已有空间优先沿用服务器设置。中文可用，英文字母不区分大小写。随机生成的名称请保存好，在其他设备输入同一名称即可。</p>
    </>}
    <p className="sync-access-note">同步名就是访问凭据，知道名称的人也能访问或修改该空间。请用不容易猜到的名称。</p>
  </section>;
}
