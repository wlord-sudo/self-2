import test from "node:test";
import assert from "node:assert/strict";
import {mkdtemp,readFile,rm} from "node:fs/promises";
import {join} from "node:path";
import {tmpdir} from "node:os";
import {normalizeCatalog,normalizeArticle,upstreamImage,UPSTREAM} from "../lib/upstream-normalize";
import {defaultJournalIds,reconcileJournals} from "../lib/journal-selection";
import {withTranslation,textFingerprint} from "../lib/translation-cache";
import type {Article} from "../lib/types";

const catalog=[{id:"jacs",name:"JACS",abbr:"JACS",publisher:"ACS",color:"#123456",defaultOn:true},{id:"rsc-sc",name:"Chemical Science",abbr:"Chem. Sci.",publisher:"RSC",color:"#123456",defaultOn:false},{id:"new-default",name:"New default",abbr:"New",publisher:"Publisher",color:"#123456",defaultOn:true}];
const journals=normalizeCatalog(catalog);
const article=(id:string,journalId="jacs")=>({id,title:`Paper ${id}`,authors:"A. Author",publishedAt:"2026-11-08T00:00:00Z",abstract:"The study describes a reaction in water with visible light.",imageUrl:null,link:`https://journals.example/articles/${id}`,doi:`10.99999/${id}`,journalId,journalName:journalId,journalAbbr:journalId,oa:false});

test("All upstream journals are retained, including default-off options and their order",()=>{assert.deepEqual(journals.map(j=>j.id),catalog.map(j=>j.id));assert.equal(journals[1].defaultOn,false);assert.deepEqual(defaultJournalIds(journals),["jacs","new-default"]);});
test("New optional journals stay off; new upstream default journals turn on",()=>{assert.deepEqual(reconcileJournals(["jacs"],["jacs"],["jacs"],journals),["jacs","new-default"]);});
test("An existing manually disabled default journal stays disabled",()=>{assert.deepEqual(reconcileJournals(["rsc-sc"],journals.map(j=>j.id),defaultJournalIds(journals),journals),["rsc-sc"]);});
test("A promoted default is enabled and removed journal IDs disappear",()=>{const changed=normalizeCatalog(catalog.map(j=>j.id==="rsc-sc"?{...j,defaultOn:true}:j));assert.deepEqual(reconcileJournals(["missing"],journals.map(j=>j.id),defaultJournalIds(journals),changed),["rsc-sc"]);});
test("Clearing the selection is respected when the catalog has not changed",()=>{assert.deepEqual(reconcileJournals([],journals.map(j=>j.id),defaultJournalIds(journals),journals),[]);});
test("Remote publisher images use the upstream image proxy",()=>{const value=upstreamImage("https://publisher.example/a.svg")!;const url=new URL(value);assert.equal(url.origin,UPSTREAM);assert.equal(url.pathname,"/api/img");assert.equal(url.searchParams.get("url"),"https://publisher.example/a.svg");assert.equal(upstreamImage(value),value);});
test("Relative ChemRxiv thumbnails are resolved against the original site",()=>{assert.equal(upstreamImage("/static/thumbs/a.png"),UPSTREAM+"/static/thumbs/a.png");assert.equal(upstreamImage("javascript:alert(1)"),null);});
test("HTML-only abstracts retain chemical numbers and exclude scripts",()=>{const value=normalizeArticle({...article("html"),abstract:null,abstractHtml:'<p><sup>13</sup>C and CO<sub>2</sub> form products.</p><script>bad()</script>',dateEstimated:true})!;assert(value.abstract.includes("13C"));assert(value.abstract.includes("CO2"));assert(!value.abstract.includes("bad()"));assert.equal(value.dateEstimated,true);});
test("Invalid records and invalid catalogs are rejected",()=>{assert.equal(normalizeArticle({...article("bad"),link:"javascript:alert(1)"}),null);assert.throws(()=>normalizeCatalog([]));});
test("A translation is invalidated when the upstream English abstract changes",()=>{const a=normalizeArticle(article("translated"))!;const cached={abstractZh:"译文",abstractFingerprint:textFingerprint(a.abstract)};assert.equal(withTranslation(a,cached).abstractZh,"译文");assert.equal(withTranslation({...a,abstract:a.abstract+" Updated."},cached).abstractZh,undefined);});
test("The backend requests every catalog journal, follows pagination and never caps a journal at 250",async()=>{
  const cache=await mkdtemp(join(tmpdir(),"chemscope-api-test-"));process.env.CACHE_DIR=cache;process.env.FEED_FORCE_MIN_SECONDS="0";const originalFetch=globalThis.fetch;
  let currentCatalog=[...catalog],fail=false,badDate=false;const requested:string[]=[];
  globalThis.fetch=async(input)=>{
    const url=new URL(String(input));requested.push(url.href);assert.equal(url.origin,UPSTREAM);assert(["/api/journals","/api/feed"].includes(url.pathname));
    await new Promise(resolve=>setTimeout(resolve,3));if(fail)return new Response("Unavailable",{status:503});
    if(url.pathname==="/api/journals")return Response.json(currentCatalog);
    assert.deepEqual(url.searchParams.get("journals")?.split(","),currentCatalog.map(j=>j.id));assert.equal(url.searchParams.get("limit"),"0");
    const page=url.searchParams.get("offset");const updatedAt=badDate?"not a date":"2026-11-08T01:00:00Z";
    return page?Response.json({articles:[article("optional","rsc-sc")],total:601,hasMore:false,updatedAt,sources:{"rsc-sc":{status:"live"}}}):Response.json({articles:Array.from({length:600},(_,i)=>article("p"+i)),total:601,hasMore:true,nextOffset:600,updatedAt,sources:{jacs:{status:"live"},"new-default":{status:"live"}}});
  };
  try{
    const module=await import("../lib/feed");const first=await module.getFeed();assert.equal(first.refreshing,true);await module.waitForRefresh();let feed=await module.getFeed();
    assert.equal(feed.articles.length,601);assert.equal(feed.articles.filter(a=>a.journalId==="jacs").length,600);assert.equal(feed.journals.length,3);assert.equal(feed.catalogSynced,true);assert.equal(feed.source,"upstream");assert(feed.articles.some(a=>a.journalId==="rsc-sc"));assert.equal(feed.sources!["new-default"].status,"live");
    const before=requested.length;await module.getArticleAbstract(feed.articles[0].id);assert.equal(requested.length,before);
    currentCatalog.push({id:"future",name:"Future journal",abbr:"Future",publisher:"Publisher",color:"#123456",defaultOn:false});badDate=true;await module.getFeed(true);await module.waitForRefresh();feed=await module.getFeed();assert.equal(feed.journals.length,4);
    // An unparseable upstream timestamp is ignored instead of reaching the page (it used to blank it).
    assert.equal(feed.updatedAt,"2026-11-08T01:00:00Z");badDate=false;
    // Visitor-triggered refreshes respect a minimum gap.
    process.env.FEED_FORCE_MIN_SECONDS="60";const beforeForce=requested.length;assert.equal((await module.getFeed(true)).refreshing,false);assert.equal(requested.length,beforeForce);process.env.FEED_FORCE_MIN_SECONDS="0";
    fail=true;await module.getFeed(true);await module.waitForRefresh();feed=await module.getFeed();assert.equal(feed.source,"cache");assert.equal(feed.articles.length,601);const attempts=requested.length;await module.getFeed(true);assert.equal(requested.length,attempts);
    await new Promise(resolve=>setTimeout(resolve,300));assert.equal(JSON.parse(await readFile(join(cache,"api-feed-v3.json"),"utf8")).schemaVersion,3);
  }finally{globalThis.fetch=originalFetch;delete process.env.FEED_FORCE_MIN_SECONDS;await rm(cache,{recursive:true,force:true});}
});
