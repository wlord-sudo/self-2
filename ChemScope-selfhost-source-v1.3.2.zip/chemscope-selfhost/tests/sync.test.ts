import test from "node:test";
import assert from "node:assert/strict";
import {mkdtemp,readdir,rm} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {SyncStore,type SyncStoreOptions} from "../lib/sync-store";
import {SyncClient,type SyncState} from "../lib/sync-client";
import {normalizeSyncName,overlayOperations,SYNC_HEADER,type SyncData,type SyncOperation} from "../lib/sync-protocol";
import type {Article} from "../lib/types";

const article=(id:string):Article=>({id,title:`Paper ${id}`,authors:"A. Author",publishedAt:"2026-11-08T00:00:00Z",abstract:"A visible-light reaction in water.",imageUrl:null,link:`https://example.org/${id}`,doi:`10.99999/${id}`,journalId:"jacs",journalName:"JACS",journalAbbr:"JACS",oa:false});
const initial=():SyncData=>({favorites:{},reads:[],settings:{mode:"bilingual",autoTranslate:true,sort:"newest",journalPreferences:{enabled:["jacs"],knownJournalIds:["jacs","nature"],defaultJournalIds:["jacs"]}}});
let sequence=0;
const op=(kind:SyncOperation["kind"],key:string,value:unknown,timestamp=Date.now(),deviceId="device-a",ifAbsent=false):SyncOperation=>({id:`operation-${++sequence}`,kind,key,value,timestamp,deviceId,ifAbsent});
// Most tests use short readable names, so the new-space length rule is relaxed here and tested separately.
const storeAt=(path:string,options:SyncStoreOptions={})=>new SyncStore(path,{minNewNameLength:1,maxSpaces:0,...options});
async function fixture(fn:(store:SyncStore,path:string)=>Promise<void>,options:SyncStoreOptions={}){const path=await mkdtemp(join(tmpdir(),"chemscope-sync-"));try{await fn(storeAt(path,options),path);}finally{await rm(path,{recursive:true,force:true});}}
class MemoryStorage{values=new Map<string,string>();getItem(key:string){return this.values.get(key)||null;}setItem(key:string,value:string){this.values.set(key,value);}removeItem(key:string){this.values.delete(key);}}
function transport(store:SyncStore){
  const control={offline:false,calls:[] as string[]};
  const fetcher:typeof fetch=async(input,init)=>{
    const path=String(input);control.calls.push(path);if(control.offline)throw new TypeError("Network offline");
    const headers=new Headers(init?.headers),body=init?.body?JSON.parse(String(init.body)):{};
    const name=decodeURIComponent(headers.get(SYNC_HEADER)||"");
    if(path.endsWith("/connect"))return Response.json(await store.connect(body.username));
    if(init?.method==="POST")return Response.json(await store.apply(name,body.operations));
    const snapshot=await store.get(name),etag=`"sync-${snapshot.revision}"`;
    return headers.get("if-none-match")===etag?new Response(null,{status:304}):Response.json(snapshot,{headers:{ETag:etag}});
  };
  return {control,fetcher};
}
function browser(fetcher:typeof fetch,storage=new MemoryStorage()){
  let data=initial(),state:SyncState|null=null;
  const client=new SyncClient({storage,fetcher,onData:value=>{data=value;},onState:value=>{state=value;}});
  return {client,storage,get data(){return data;},get state(){return state!;}};
}

test("Browser-style fetch keeps its global receiver for default and injected transports",async()=>fixture(async(store)=>{
  const original=globalThis.fetch,{fetcher}=transport(store);
  // Unlike Node fetch and arrow-function mocks, browser fetch checks its receiver.
  const browserFetch:typeof fetch=function(this:unknown,...args:Parameters<typeof fetch>){
    if(this!==globalThis)throw new TypeError("Failed to execute 'fetch' on 'Window': Illegal invocation");
    return fetcher(...args);
  };
  globalThis.fetch=browserFetch;
  const client=new SyncClient({storage:new MemoryStorage(),onData:()=>{},onState:()=>{}});
  let injected:ReturnType<typeof browser>|null=null;
  try{
    await client.connect("browser-fetch",initial());
    assert.equal(client.current.phase,"synced",client.current.error);
    client.enqueue("favorite","a",article("a"));await client.sync();
    assert((await store.get("browser-fetch")).favorites.a);
    injected=browser(browserFetch);await injected.client.connect("browser-fetch",initial(),false);
    assert.equal(injected.state.phase,"synced",injected.state.error);assert(injected.data.favorites.a);
  }finally{client.dispose();injected?.client.dispose();globalThis.fetch=original;}
}));

test("Unicode sync names normalize consistently and cannot become filesystem paths",async()=>fixture(async(store,path)=>{
  assert.equal(normalizeSyncName("  Ｃｈｅｍ研究_7 "),"chem研究_7");
  await store.connect("Ｃｈｅｍ研究_7");await store.connect("chem研究_7");
  const names=await readdir(path);assert.equal(names.length,1);assert.match(names[0],/^[a-f0-9]{64}\.json$/);
  for(const name of ["../secret","a/b","","a\nname","a".repeat(65)])assert.throws(()=>normalizeSyncName(name));
}));
test("Concurrent devices merge independent favorites and persist across a restart",async()=>fixture(async(store,path)=>{
  await store.connect("same-name");
  await Promise.all([store.apply("same-name",[op("favorite","a",article("a"))]),store.apply("same-name",[op("favorite","b",article("b"),Date.now(),"device-b")])]);
  const profile=await storeAt(path).get("same-name");assert.deepEqual(Object.keys(profile.favorites).sort(),["a","b"]);
  assert.deepEqual((await store.connect("another-name")).favorites,{});
}));
test("Deletion tombstones defeat stale uploads and first-connect imports",async()=>fixture(async(store)=>{
  await store.connect("name");const time=Date.now();
  await store.apply("name",[op("favorite","a",article("a"),time)]);
  await store.apply("name",[op("favorite","a",null,time+10)]);
  await store.apply("name",[op("favorite","a",article("a"),time+5,"device-b"),op("favorite","a",article("a"),time+20,"device-c",true)]);
  assert.deepEqual((await store.get("name")).favorites,{});
  await store.apply("name",[op("favorite","a",article("a"),time+30,"device-b")]);
  assert((await store.get("name")).favorites.a);
}));
test("Settings merge by field, preserve empty journal selections and ignore replayed changes",async()=>fixture(async(store)=>{
  await store.connect("name");const time=Date.now(),first=op("setting","mode","english",time);
  await store.apply("name",[first]);const revision=(await store.get("name")).revision;
  await store.apply("name",[first]);assert.equal((await store.get("name")).revision,revision);
  await store.apply("name",[op("setting","autoTranslate",false,time+1,"device-b"),op("setting","journalPreferences",{enabled:[],knownJournalIds:["jacs"],defaultJournalIds:["jacs"]},time+2)]);
  const settings=(await store.get("name")).settings;assert.equal(settings.mode,"english");assert.equal(settings.autoTranslate,false);assert.deepEqual(settings.journalPreferences?.enabled,[]);
}));
test("Invalid operations are rejected one by one; script links and prototype keys are never stored",async()=>fixture(async(store)=>{
  await store.connect("name");
  const good=op("read","a",true),script=op("favorite","b",{...article("b"),link:"javascript:alert(1)"}),proto=op("read","__proto__",true),unknown=op("setting","unknown",true);
  const result=await store.apply("name",[good,script,proto,unknown]);
  assert.deepEqual(result.rejected.map(item=>item.id).sort(),[script.id,proto.id,unknown.id].sort());
  // Rejected ids are acknowledged as well, so even v1.3.1 clients stop resending them.
  assert.deepEqual(new Set(result.acknowledged),new Set([good.id,script.id,proto.id,unknown.id]));
  const snapshot=await store.get("name");assert.deepEqual(snapshot.reads,["a"]);assert.deepEqual(snapshot.favorites,{});assert.equal(Object.hasOwn(snapshot.settings,"unknown"),false);
  await assert.rejects(store.apply("name",[]));await assert.rejects(store.apply("name","not-a-list"));
}));
test("A second browser receives favorites, reads and journal preferences without overwriting remote settings",async()=>fixture(async(store)=>{
  const {fetcher}=transport(store),a=browser(fetcher),b=browser(fetcher);
  try{
    await a.client.connect("same",initial());a.client.enqueue("favorite","a",article("a"));a.client.enqueue("read","a",true);a.client.enqueue("setting","mode","english");a.client.enqueue("setting","journalPreferences",{enabled:["nature"],knownJournalIds:["jacs","nature"],defaultJournalIds:["jacs"]});await a.client.sync();
    const local=initial();local.favorites.b=article("b");await b.client.connect("same",local);
    assert.deepEqual(Object.keys(b.data.favorites).sort(),["a","b"]);assert.deepEqual(b.data.reads,["a"]);assert.equal(b.data.settings.mode,"english");assert.deepEqual(b.data.settings.journalPreferences?.enabled,["nature"]);
    await a.client.sync();assert(a.data.favorites.b);assert.equal(a.state.phase,"synced");
  }finally{a.client.dispose();b.client.dispose();}
}));
test("Offline changes survive browser recreation and retry, including favorite removal",async()=>fixture(async(store)=>{
  const {fetcher,control}=transport(store),a=browser(fetcher);let recreated:ReturnType<typeof browser>|null=null;
  try{
    await a.client.connect("offline-name",initial());a.client.enqueue("favorite","a",article("a"));await a.client.sync();
    control.offline=true;a.client.enqueue("favorite","a",null);a.client.enqueue("setting","sort","oldest");await a.client.sync();assert.equal(a.state.phase,"offline");assert.equal(a.state.pending,2);a.client.dispose();
    recreated=browser(fetcher,a.storage);assert.equal(recreated.client.rememberedName,"offline-name");control.offline=false;
    await recreated.client.connect("offline-name",a.data,false);assert.deepEqual(recreated.data.favorites,{});assert.equal(recreated.data.settings.sort,"oldest");assert.equal(recreated.state.pending,0);
  }finally{a.client.dispose();recreated?.client.dispose();}
}));
test("A newer edit made during an upload is not removed by the older acknowledgement",async()=>fixture(async(store)=>{
  const base=transport(store);let release:(()=>void)|null=null,started:(()=>void)|null=null,block=false;
  const began=new Promise<void>(resolve=>{started=resolve;});
  const fetcher:typeof fetch=async(input,init)=>{if(block&&init?.method==="POST"&&String(input)==="/api/sync"){block=false;started!();await new Promise<void>(resolve=>{release=resolve;});}return base.fetcher(input,init);};
  const a=browser(fetcher);
  try{await a.client.connect("name",initial());block=true;a.client.enqueue("favorite","a",article("a"));const pending=a.client.sync();await began;a.client.enqueue("favorite","a",null);release!();await pending;assert.deepEqual((await store.get("name")).favorites,{});assert.equal(a.state.pending,0);}finally{a.client.dispose();}
}));
test("Pending explicit edits overlay remote snapshots; migration imports never resurrect records",()=>{
  const local=initial();local.favorites.a=article("a");
  const merged=overlayOperations(local,[op("favorite","a",null),op("favorite","b",article("b"),Date.now(),"other",true),op("setting","autoTranslate",false)]);
  assert.deepEqual(merged.favorites,{});assert.equal(merged.settings.autoTranslate,false);
});

test("Snapshot papers with null oa or publishedAt can be favorited and synced",async()=>fixture(async(store)=>{
  const {initialFeed}=await import("../lib/initial-feed");
  const tricky=initialFeed.articles.filter(a=>a.journalId==="ccr").slice(0,3);assert(tricky.length>0);
  await store.connect("snapshot");
  const result=await store.apply("snapshot",tricky.map(a=>op("favorite",a.id,a)));
  assert.deepEqual(result.rejected,[]);assert.equal(Object.keys((await store.get("snapshot")).favorites).length,tricky.length);
  // Raw objects as older clients stored them (null fields) are accepted and normalized by the server.
  const legacy={...article("legacy"),oa:null,publishedAt:null,doi:null,authors:undefined};
  const stored=await store.apply("snapshot",[op("favorite","legacy",legacy)]);assert.deepEqual(stored.rejected,[]);
  const saved=(await store.get("snapshot")).favorites.legacy;assert.equal(saved.oa,false);assert.equal(saved.doi,"");assert(Number.isFinite(Date.parse(saved.publishedAt)));
}));
test("One rejected change no longer blocks the rest of the queue",async()=>fixture(async(store)=>{
  const {fetcher}=transport(store),a=browser(fetcher);
  try{
    await a.client.connect("queue",initial());
    a.client.enqueue("favorite","huge",{...article("huge"),title:"x".repeat(5000)});
    a.client.enqueue("favorite","fine",article("fine"));a.client.enqueue("read","fine",true);
    await a.client.sync();
    assert.equal(a.state.phase,"synced",a.state.error);assert.equal(a.state.pending,0);assert.match(a.state.notice,/1 项更改未被服务器接受/);
    const snapshot=await store.get("queue");assert.deepEqual(Object.keys(snapshot.favorites),["fine"]);assert.deepEqual(snapshot.reads,["fine"]);
  }finally{a.client.dispose();}
}));
test("A queue stuck in v1.3.1 (favorite with oa: null) is repaired and delivered after the upgrade",async()=>fixture(async(store)=>{
  const {fetcher}=transport(store),storage=new MemoryStorage();
  const stuck={id:"old-op",kind:"favorite",key:"ccr-paper",value:{...article("ccr-paper"),oa:null,publishedAt:null},timestamp:Date.now(),deviceId:"old-device",ifAbsent:false};
  storage.setItem("chemscope-sync-outbox:upgraded",JSON.stringify([stuck,op("read","ccr-paper",true)]));storage.setItem("chemscope-sync-name",JSON.stringify("upgraded"));
  const b=browser(fetcher,storage);
  try{await b.client.connect(b.client.rememberedName,initial(),false);assert.equal(b.state.phase,"synced",b.state.error);assert.equal(b.state.pending,0);
    const snapshot=await store.get("upgraded");assert(snapshot.favorites["ccr-paper"]);assert.equal(snapshot.favorites["ccr-paper"].oa,false);assert.deepEqual(snapshot.reads,["ccr-paper"]);
  }finally{b.client.dispose();}
}));
test("Read history beyond the record limit drops the oldest entries instead of blocking sync",async()=>fixture(async(store)=>{
  await store.connect("reader");const base=Date.now();
  for(let i=0;i<8;i++){const result=await store.apply("reader",[op("read","p"+i,true,base+i)]);assert.deepEqual(result.rejected,[]);}
  assert.deepEqual((await store.get("reader")).reads.sort(),["p3","p4","p5","p6","p7"]);
  // Deletion markers are pruned too; live favorites over the limit are refused individually.
  for(let i=0;i<5;i++)await store.apply("reader",[op("favorite","f"+i,article("f"+i),base+20+i)]);
  const over=await store.apply("reader",[op("favorite","f5",article("f5"),base+30)]);assert.equal(over.rejected.length,1);
  await store.apply("reader",[op("favorite","f0",null,base+40)]);
  assert.deepEqual((await store.apply("reader",[op("favorite","f5",article("f5"),base+50)])).rejected,[]);
},{maxRecords:5}));
test("A full space refuses only new favorites; removals and reads still go through",async()=>fixture(async(store)=>{
  await store.connect("full");const base=Date.now();
  await store.apply("full",[op("favorite","a",{...article("a"),abstract:"x".repeat(2500)},base)]);
  const result=await store.apply("full",[op("favorite","b",{...article("b"),abstract:"y".repeat(2500)},base+1),op("read","a",true,base+2)]);
  assert.equal(result.rejected.length,1);assert.equal(result.rejected[0].id.startsWith("operation-"),true);
  let snapshot=await store.get("full");assert.deepEqual(Object.keys(snapshot.favorites),["a"]);assert.deepEqual(snapshot.reads,["a"]);
  assert.deepEqual((await store.apply("full",[op("favorite","a",null,base+3)])).rejected,[]);
  snapshot=await store.get("full");assert.deepEqual(snapshot.favorites,{});
},{maxBytes:4000}));
test("New spaces need a minimum name length and pass the creation guard; existing short names still work",async()=>{
  const path=await mkdtemp(join(tmpdir(),"chemscope-sync-"));
  try{
    await storeAt(path).connect("jim");
    const strict=new SyncStore(path,{minNewNameLength:8,maxSpaces:2});
    await assert.rejects(strict.connect("short"),/至少需要 8 个字符/);
    assert.equal((await strict.connect("jim")).username,"jim");
    await assert.rejects(strict.connect("chem-guard-test",{allowCreate:()=>false}),(error:{status:number})=>error.status===429);
    await strict.connect("chem-room-0001");
    await assert.rejects(strict.connect("chem-room-0002"),(error:{status:number})=>error.status===507);
    assert.equal((await strict.connect("chem-room-0001")).username,"chem-room-0001");
  }finally{await rm(path,{recursive:true,force:true});}
});
test("Two tabs of one browser keep each other's offline changes",async()=>fixture(async(store)=>{
  const control=transport(store),storage=new MemoryStorage();
  const tabA=browser(control.fetcher,storage),tabB=browser(control.fetcher,storage);
  try{
    await tabA.client.connect("tabs",initial());await tabB.client.connect("tabs",initial(),false);
    control.control.offline=true;
    tabA.client.enqueue("read","from-a",true);tabB.client.enqueue("read","from-b",true);
    tabA.client.dispose();tabB.client.dispose();
    const outbox=JSON.parse(storage.getItem("chemscope-sync-outbox:tabs")!) as SyncOperation[];
    assert.deepEqual(outbox.map(item=>item.key).sort(),["from-a","from-b"]);
    control.control.offline=false;
    const reopened=browser(control.fetcher,storage);
    try{await reopened.client.connect("tabs",initial(),false);assert.deepEqual((await store.get("tabs")).reads.sort(),["from-a","from-b"]);assert.equal(reopened.state.pending,0);}
    finally{reopened.client.dispose();}
  }finally{tabA.client.dispose();tabB.client.dispose();}
}));
test("A tab picks up changes another tab queued and sends them itself",async()=>fixture(async(store)=>{
  const control=transport(store),storage=new MemoryStorage();
  const tabA=browser(control.fetcher,storage),tabB=browser(control.fetcher,storage);
  try{
    await tabA.client.connect("relay",initial());await tabB.client.connect("relay",initial(),false);
    control.control.offline=true;tabB.client.enqueue("favorite","b",article("b"));tabB.client.dispose();
    control.control.offline=false;await tabA.client.sync();
    assert((await store.get("relay")).favorites.b);assert.equal(tabA.state.pending,0);assert(tabA.data.favorites.b);
  }finally{tabA.client.dispose();tabB.client.dispose();}
}));
test("Favorites that cannot be opened are kept local instead of entering the queue",async()=>fixture(async(store)=>{
  const {fetcher}=transport(store),a=browser(fetcher);
  try{await a.client.connect("local-only",initial());a.client.enqueue("favorite","x",{...article("x"),link:"javascript:alert(1)"});assert.equal(a.state.pending,0);assert.match(a.state.notice,/只保存在本机/);}
  finally{a.client.dispose();}
}));
