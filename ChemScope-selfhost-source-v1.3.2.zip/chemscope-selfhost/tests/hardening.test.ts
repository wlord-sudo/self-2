import test from "node:test";
import assert from "node:assert/strict";
import {mkdtemp,rm} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {coerceArticle,knownTime,UNKNOWN_DATE} from "../lib/article-shape";
import {formatDay,formatDayTime} from "../lib/format-date";
import {decodeEntities} from "../lib/html-entities";
import {sameSelection} from "../lib/journal-selection";
import {RateLimiter} from "../lib/rate-limit";
import {initialFeed} from "../lib/initial-feed";
import {initialCatalogFeed} from "../lib/initial-catalog";
import {SYNC_HEADER} from "../lib/sync-protocol";

test("Every bundled snapshot paper has the shape the sync server accepts",()=>{
  assert(initialFeed.articles.length>2000);
  for(const a of initialFeed.articles){
    assert.equal(typeof a.oa,"boolean",a.id);assert(Number.isFinite(Date.parse(a.publishedAt)),a.id);
    for(const field of ["authors","abstract","doi","journalId","journalName","journalAbbr"] as const)assert.equal(typeof a[field],"string",`${a.id}.${field}`);
  }
  // CCR records have no publication date upstream; they are marked unknown, not shown as 1970.
  const ccr=initialFeed.articles.find(a=>a.journalId==="ccr")!;assert.equal(knownTime(ccr.publishedAt),null);assert.equal(formatDay(ccr.publishedAt),"日期未知");
});
test("The browser starts from the journal catalog only, without the 4 MB snapshot",()=>{assert.equal(initialCatalogFeed.articles.length,0);assert(initialCatalogFeed.journals.length>=40);});
test("Articles from older storage are repaired; unusable ones are refused",()=>{
  const repaired=coerceArticle({id:"x",title:"T",link:"https://pubs.acs.org/doi/10.1021/jacs.0c00001",oa:null,publishedAt:null,journalId:"jacs"})!;
  assert.equal(repaired.oa,false);assert.equal(repaired.publishedAt,UNKNOWN_DATE);assert.equal(repaired.doi,"10.1021/jacs.0c00001");assert.equal(repaired.authors,"");assert.equal(repaired.imageUrl,null);
  assert.equal(coerceArticle({id:"x",title:"T",link:"javascript:alert(1)"}),null);assert.equal(coerceArticle({id:"x",title:" ",link:"https://e.org"}),null);assert.equal(coerceArticle(null),null);
  // Already-normalized records serialize identically, so cross-tab storage events cannot ping-pong.
  const once=coerceArticle(repaired)!;assert.equal(JSON.stringify(once),JSON.stringify(repaired));
});
test("Invalid dates render as placeholders instead of throwing",()=>{
  assert.throws(()=>new Intl.DateTimeFormat("zh-CN").format(new Date("not a date")));
  assert.equal(formatDay("not a date"),"日期未知");assert.equal(formatDayTime(""),"—");assert.equal(formatDayTime(undefined),"—");
  assert.equal(formatDay("2026-11-08T16:06:44Z"),"11/09");
});
test("Translation entities are decoded once, including < and >",()=>{
  assert.equal(decodeEntities("p &lt; 0.05, ee &gt; 99% &amp; &#39;ok&#39; &#x2013; &quot;q&quot;"),"p < 0.05, ee > 99% & 'ok' – \"q\"");
  assert.equal(decodeEntities("&amp;lt;"),"&lt;");assert.equal(decodeEntities("&unknown; &#0;"),"&unknown; &#0;");
});
test("Journal selections compare by content, not array identity or order",()=>{
  const a=["jacs","ol"];assert(sameSelection(a,a));assert(sameSelection(a,["ol","jacs"]));assert(!sameSelection(a,["jacs"]));assert(!sameSelection(a,["jacs","joc"]));
});
test("Rate limiter counts per key and window",()=>{
  let now=0;const limiter=new RateLimiter(()=>now);
  assert.equal(limiter.hit("a",2,1000),0);assert.equal(limiter.hit("a",2,1000),0);assert.equal(limiter.hit("a",2,1000),1000);
  assert.equal(limiter.hit("b",2,1000),0);assert.equal(limiter.blocked("a",2),1000);
  now=1000;assert.equal(limiter.hit("a",2,1000),0);assert.equal(limiter.hit("x",0,1000),0);
});
test("Sync routes: strict JSON type, no cross-site access and per-client limits",async()=>{
  const dir=await mkdtemp(join(tmpdir(),"chemscope-route-"));process.env.SYNC_DIR=dir;process.env.SYNC_CREATE_PER_HOUR="2";process.env.SYNC_MISSES_PER_10_MINUTES="3";
  try{
    const route=await import("../app/api/sync/route");
    const connect=(username:string,ip:string,type="application/json",extra:Record<string,string>={})=>route.connectSyncResponse(new Request("http://localhost/api/sync/connect",{method:"POST",headers:{"Content-Type":type,...extra},body:JSON.stringify({username})}),{ip});
    // "text/plain; application/json" is CORS-safelisted, so a cross-site page could send it without a preflight.
    assert.equal((await connect("chem-type-check","10.0.0.1","text/plain; application/json")).status,415);
    assert.equal((await connect("chem-cross-site","10.0.0.1","application/json",{"Sec-Fetch-Site":"cross-site"})).status,403);
    assert.equal((await connect("short","10.0.0.1")).status,400);
    assert.equal((await connect("chem-space-0001","10.0.0.1")).status,200);
    assert.equal((await connect("chem-space-0002","10.0.0.1")).status,200);
    const limited=await connect("chem-space-0003","10.0.0.1");assert.equal(limited.status,429);assert(Number(limited.headers.get("retry-after"))>0);
    assert.equal((await connect("chem-space-0001","10.0.0.1")).status,200,"existing spaces stay reachable");
    assert.equal((await connect("chem-space-0003","10.0.0.2")).status,200,"other clients are unaffected");
    const get=(name:string,ip:string)=>route.getSyncResponse(new Request("http://localhost/api/sync",{headers:{[SYNC_HEADER]:encodeURIComponent(name)}}),{ip});
    for(let i=0;i<3;i++)assert.equal((await get(`chem-guess-${i}`,"10.0.0.9")).status,404);
    assert.equal((await get("chem-space-0001","10.0.0.9")).status,429,"guessing names gets throttled");
    assert.equal((await get("chem-space-0001","10.0.0.1")).status,200);
  }finally{delete process.env.SYNC_DIR;delete process.env.SYNC_CREATE_PER_HOUR;delete process.env.SYNC_MISSES_PER_10_MINUTES;await rm(dir,{recursive:true,force:true});}
});
test("Translation route rejects cross-site use and limits uncached requests per client",async()=>{
  process.env.TRANSLATE_RATE_PER_MINUTE="1";const original=globalThis.fetch;let calls=0;
  globalThis.fetch=(async()=>{calls++;return Response.json([[["译文",""]]]);}) as typeof fetch;
  try{
    const {POST}=await import("../app/api/translate/route");
    const post=(text:string,ip:string,extra:Record<string,string>={})=>POST(new Request("http://localhost/api/translate",{method:"POST",headers:{"Content-Type":"application/json",...extra},body:JSON.stringify({text})}),{ip});
    assert.equal((await post("Hello.","10.1.0.1",{"Sec-Fetch-Site":"cross-site"})).status,403);
    assert.equal((await post("Hello.","10.1.0.1")).status,200);
    assert.equal((await post("Hello.","10.1.0.1")).status,200,"cached text does not count");
    assert.equal((await post("Another sentence.","10.1.0.1")).status,429);
    assert.equal(calls,1);
  }finally{globalThis.fetch=original;delete process.env.TRANSLATE_RATE_PER_MINUTE;}
});
