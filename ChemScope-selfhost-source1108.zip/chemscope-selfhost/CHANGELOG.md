# v1.1

- 文献源改为各期刊 RSS 直连；图片直接读取出版社地址。
- 支持 RSS 2.0、Nature RSS 1.0/RDF、Atom、命名空间与 CDATA。
- 最多 6 路并发更新，先显示缓存；新增磁盘缓存、ETag / Last-Modified 条件请求和按源失败退避。
- 新增轻量进度接口，仅在文献内容变化时重取完整列表。
- Nature 摘要按公开文章页正文、结构化元数据、Crossref、Europe PMC 补全，区分完整摘要与简介。
- 补齐从 Nature 文章链接识别 DOI；保留旧文献 ID，并按 DOI 和链接去重。
- 摘要补全后不再复用旧简介对应的中文译文。
- Docker Compose 增加缓存持久卷，部署说明补充 RSS 与 Nature 参数。
- 预构建文件已重新生成；15 项回归测试通过。
