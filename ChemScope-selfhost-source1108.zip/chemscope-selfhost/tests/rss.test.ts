import test from "node:test";
import assert from "node:assert/strict";
import {mkdtemp,readFile,rm} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {parseFeed,htmlToText} from "../lib/rss-parser";
import {parseNaturePage,resolveNatureAbstract} from "../lib/nature-abstract";
import {withTranslation,textFingerprint} from "../lib/translation-cache";
import {initialFeed} from "../lib/initial-feed";
import {doiFromArticleLink} from "../lib/article-utils";
import type {Article,Journal} from "../lib/types";

const journal:Journal={id:"fixture",name:"Fixture journal",abbr:"Fixture",publisher:"Publisher",color:"#000000",discipline:"General",url:"https://journals.example/feed"};
const abstract="A visible-light reaction selectively functionalizes the substrate in water. The method preserves the isotope labels 13C and the molecular formula CO2 while providing products under mild reaction conditions.";
const xmlEscape=(s:string)=>s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const paper={...initialFeed.articles[0],id:"test",doi:"10.1038/test",link:"https://www.nature.com/articles/test",abstract:"",abstractZh:undefined} as Article;

test("RSS 2.0 retains CDATA, authors, DOI, chemical numerals and TOC images",()=>{
  const xml=`<rss xmlns:dc="urn:dc" xmlns:content="urn:content" xmlns:prism="urn:prism"><channel><item><title><![CDATA[Visible-light C(sp<sup>3</sup>)–H functionalization]]></title><link>https://journals.example/articles/test</link><dc:creator>A One</dc:creator><dc:creator>B Two</dc:creator><prism:doi>10.1234/test</prism:doi><pubDate>Sun, 08 Nov 2026 12:00:00 GMT</pubDate><content:encoded><![CDATA[<h3>Abstract</h3><p>${abstract}</p><img src="/toc.png"/>]]></content:encoded></item></channel></rss>`;
  const [a]=parseFeed(xml,journal);assert.equal(a.title,"Visible-light C(sp3)–H functionalization");assert.equal(a.authors,"A One, B Two");assert.equal(a.doi,"10.1234/test");assert(a.abstract.includes("13C"));assert(a.abstract.includes("CO2"));assert.equal(a.imageUrl,"https://journals.example/toc.png");assert(!a.abstract.includes("<![CDATA["));
});
test("Nature RSS 1.0/RDF parses namespace fields and removes publication boilerplate",()=>{
  const xml=`<rdf:RDF xmlns:rdf="urn:rdf" xmlns:dc="urn:dc" xmlns:content="urn:content"><channel><title>Nature</title></channel><item rdf:about="https://www.nature.com/articles/test"><title>DNA recognition</title><dc:title>DNA recognition</dc:title><link>https://www.nature.com/articles/test</link><dc:identifier>doi:10.1038/test</dc:identifier><dc:creator>A One</dc:creator><dc:date>2026-11-05</dc:date><content:encoded><![CDATA[<p>Nature Chemistry, Published online: 05 November 2026; doi:10.1038/test</p>${abstract}]]></content:encoded></item></rdf:RDF>`;
  const [a]=parseFeed(xml,{...journal,nature:true});assert.equal(a.title,"DNA recognition");assert.equal(a.abstract,abstract);assert.equal(a.abstractStatus,"summary");assert.equal(a.publishedAt,"2026-11-05T00:00:00.000Z");assert.equal(a.doi,"10.1038/test");
});
test("Atom chooses alternate link and decodes escaped HTML content",()=>{
  const xml=`<feed xmlns="http://www.w3.org/2005/Atom"><entry><title>Atom paper</title><link rel="self" href="https://journals.example/feed/item"/><link rel="alternate" href="https://journals.example/articles/test"/><author><name>A One</name></author><published>2026-11-05T12:00:00Z</published><content type="html">&lt;p&gt;${abstract}&lt;/p&gt;</content></entry></feed>`;
  const [a]=parseFeed(xml,journal);assert.equal(a.link,"https://journals.example/articles/test");assert.equal(a.abstract,abstract);assert.equal(a.authors,"A One");
});
test("HTML cleaning does not truncate titles beginning with Abstracting",()=>{assert.equal(htmlToText("Abstracting hydrogen atoms"),"Abstracting hydrogen atoms");});
test("External document declarations and HTML challenge pages are rejected",()=>{assert.throws(()=>parseFeed('<!DOCTYPE rss [<!ENTITY x "x">]><rss/>',journal));assert.throws(()=>parseFeed('<html><title>Client Challenge</title></html>',journal));});
test("Nature selects full abstract before shorter sharing descriptions, excluding figures",()=>{
  const html=`<html><head><title>Test</title><meta name="citation_doi" content="10.1038/test"><meta property="og:description" content="Short sharing description"><link rel="canonical" href="https://www.nature.com/articles/test"></head><body><div id="Abs1-content"><p>${abstract}</p><div class="c-article-section__figure">Figure caption. Full size image.</div></div></body></html>`;
  const value=parseNaturePage(html,paper);assert.equal(value?.abstract,abstract);assert.equal(value?.abstractSource,"publisher");assert.equal(value?.abstractStatus,"available");
});
test("Nature dc.description is recovered when the abstract section is absent",()=>{const value=parseNaturePage(`<html><head><meta name="citation_doi" content="10.1038/test"><meta name="dc.description" content="${abstract}"><meta property="og:description" content="Short sharing text"></head></html>`,paper);assert.equal(value?.abstract,abstract);});
test("Metadata from a different DOI is rejected",()=>{assert.throws(()=>parseNaturePage(`<html><head><meta name="citation_doi" content="10.1038/other"><meta name="dc.description" content="${abstract}"></head></html>`,paper));});
test("An exact publisher DOI match takes priority over a differing canonical alias",()=>{const value=parseNaturePage(`<html><head><meta name="citation_doi" content="10.1038/test"><link rel="canonical" href="https://www.nature.com/articles/alias"><meta name="dc.description" content="${abstract}"></head></html>`,paper);assert.equal(value?.abstract,abstract);});
test("Crossref can supply the abstract when the public publisher page is unavailable",async()=>{
  const fetcher=async(url:string)=>url.startsWith("https://api.crossref.org/")?Response.json({message:{DOI:paper.doi,abstract:`<jats:p>${abstract}</jats:p>`}}):new Response("Unavailable",{status:403});
  const value=await resolveNatureAbstract(paper,fetcher);assert.equal(value?.abstractSource,"crossref");assert.equal(value?.abstract,abstract);
});
test("Europe PMC fallback matches the DOI before accepting its abstract",async()=>{
  const fetcher=async(url:string)=>url.startsWith("https://www.ebi.ac.uk/")?Response.json({resultList:{result:[{doi:paper.doi,abstractText:abstract}]}}):new Response("Unavailable",{status:404});
  const value=await resolveNatureAbstract(paper,fetcher);assert.equal(value?.abstractSource,"europepmc");assert.equal(value?.abstract,abstract);
  const wrong=await resolveNatureAbstract(paper,async(url:string)=>url.startsWith("https://www.ebi.ac.uk/")?Response.json({resultList:{result:[{doi:"10.1038/wrong",abstractText:abstract}]}}):new Response("Unavailable",{status:404}));assert.equal(wrong,null);
});
test("An old translation is not reused after the English abstract changes",()=>{
  const a={...paper,abstract};const cached={abstractZh:"已有译文",abstractFingerprint:textFingerprint(abstract)};assert.equal(withTranslation(a,cached).abstractZh,"已有译文");assert.equal(withTranslation({...a,abstract:abstract+" New finding."},cached).abstractZh,undefined);
});
test("A Nature DOI is recovered from its canonical article URL",()=>{assert.equal(doiFromArticleLink("https://www.nature.com/articles/s41467-026-79060-0?utm_source=feed"),"10.1038/s41467-026-79060-0");});
test("A short Nature sharing description is not labelled a full abstract",()=>{const value=parseNaturePage(`<html><head><meta name="citation_doi" content="10.1038/test"><meta name="dc.description" content="${abstract}"><meta property="og:description" content="${abstract}"></head></html>`,paper);assert.equal(value?.abstractStatus,"summary");});
test("RSS caching returns immediately, preserves IDs, uses ETags and backs off on 429",async()=>{
  const directory=await mkdtemp(join(tmpdir(),"chemscope-rss-test-"));process.env.CACHE_DIR=directory;process.env.NATURE_BACKGROUND_LIMIT="0";
  const originalFetch=globalThis.fetch;const calls=new Map<string,number>();let rejectJacs=false;
  const originalJoc=initialFeed.articles.find(a=>a.journalId==="joc")!;
  globalThis.fetch=async(input,init)=>{
    await new Promise(resolve=>setTimeout(resolve,5));const url=String(input);calls.set(url,(calls.get(url)||0)+1);const j=initialFeed.journals.find(j=>j.url===url)!;assert(j);
    if(j.id==="jacs"&&rejectJacs)return new Response("Rate limit",{status:429,headers:{"Retry-After":"1200"}});
    if((init?.headers as Record<string,string>)?.["If-None-Match"])return new Response(null,{status:304});
    const doi=j.id==="joc"?originalJoc.doi:`10.99999/rss-${j.id}`;const title=j.id==="joc"?originalJoc.title:`Test ${j.id}`;
    return new Response(`<rss xmlns:dc="urn:dc"><channel><item><title>${xmlEscape(title)}</title><link>https://doi.org/${doi}</link><dc:identifier>doi:${doi}</dc:identifier><pubDate>Sun, 08 Nov 2026 12:00:00 GMT</pubDate><description>${j.id==="joc"?"":abstract}</description></item></channel></rss>`,{headers:{ETag:`"fixture-${j.id}"`}});
  };
  try{
    const feedModule=await import("../lib/feed");const first=await feedModule.getFeed();assert.equal(first.refreshing,true);await feedModule.waitForRefresh();
    const fresh=await feedModule.getFeed();assert.equal(Object.values(fresh.sources!).filter(x=>x.status==="live").length,23);
    const joc=fresh.articles.find(a=>a.doi===originalJoc.doi)!;assert.equal(joc.id,originalJoc.id);assert.equal(joc.abstract,originalJoc.abstract);
    rejectJacs=true;await feedModule.getFeed(true);await feedModule.waitForRefresh();const partial=await feedModule.getFeed();assert.equal(partial.sources!.jacs.status,"cached");assert(partial.sources!.jacs.retryAfter!>Date.now());
    const url=initialFeed.journals.find(j=>j.id==="jacs")!.url!;const previous=calls.get(url);await feedModule.getFeed(true);await feedModule.waitForRefresh();assert.equal(calls.get(url),previous);
    await new Promise(resolve=>setTimeout(resolve,350));const saved=JSON.parse(await readFile(join(directory,"rss-feed-v2.json"),"utf8"));assert.equal(saved.schemaVersion,2);assert(saved.feed.articles.length>=initialFeed.articles.length);
  }finally{globalThis.fetch=originalFetch;await rm(directory,{recursive:true,force:true});}
});
