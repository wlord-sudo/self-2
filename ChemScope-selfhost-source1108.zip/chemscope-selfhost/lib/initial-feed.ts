import initial from "./initial-data.json";
import journals from "./journals.json";
import {translations} from "./translations";
import type {Article,Feed} from "./types";
import {doiFromArticleLink} from "./article-utils";
export function enrich(article:Article):Article{return {...article,...(translations[article.id]||{})};}
export const initialFeed:Feed={articles:initial.articles.map(a=>enrich({...a,doi:a.doi||doiFromArticleLink(a.link),abstractSource:"snapshot"} as Article)),journals,updatedAt:initial.updatedAt,total:initial.articles.length,source:"snapshot"};
