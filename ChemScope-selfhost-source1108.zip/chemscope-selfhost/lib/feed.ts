import {readFile,writeFile,mkdir,rename} from "node:fs/promises";
import {resolve,dirname} from "node:path";
import {initialFeed,enrich} from "./initial-feed";
import {parseFeed,normalDoi,usefulAbstract} from "./rss-parser";
import {fetchText,UpstreamError} from "./rss-http";
import {isNatureArticle,resolveNatureAbstract} from "./nature-abstract";
import {doiFromArticleLink,normalizedArticleLink} from "./article-utils";
import type {Article,Feed,SourceState} from "./types";
export {initialFeed} from "./initial-feed";

const minutes=Number(process.env.RSS_CACHE_MINUTES||5);
const ttl=Number.isFinite(minutes)&&minutes>=1?minutes*60000:300000;
const file=resolve(process.env.CACHE_DIR||".cache","rss-feed-v2.json");
const journals=initialFeed.journals;
let state:Feed={...initialFeed,sources:{},abstractJobsPending:0};
let initialized:Promise<void>|null=null,refreshing:Promise<void>|null=null;
let lastRefresh=0,saveTimer:ReturnType<typeof setTimeout>|undefined;
let saveChain=Promise.resolve();let revision=0;
const abstractInFlight=new Map<string,Promise<Article>>();
const queue:Array<()=>void>=[];let activeAbstracts=0;
function runLimited<T>(job:()=>Promise<T>,priority=false):Promise<T>{return new Promise((accept,reject)=>{
  const run=()=>{activeAbstracts++;void job().then(accept,reject).finally(()=>{activeAbstracts--;queue.shift()?.();});};
  if(activeAbstracts<2)run();else if(priority)queue.unshift(run);else queue.push(run);
});}
async function initialize(){
  if(!initialized)initialized=(async()=>{
    try{
      const contents=await readFile(file,"utf8");if(contents.length>18000000)return;const value=JSON.parse(contents);
      if(value.schemaVersion===2&&Array.isArray(value.feed?.articles)&&value.feed.articles.length&&value.feed.sources){
        state={...value.feed,journals,refreshing:false,abstractJobsPending:0};lastRefresh=Number(value.lastRefresh)||0;
      }
    }catch{/* A first run starts from the bundled, timestamped snapshot. */}
    state.articles=state.articles.filter(a=>a.id&&a.title&&/^https:\/\//i.test(a.link)).map(a=>({...a,doi:a.doi||doiFromArticleLink(a.link)}));
  })();return initialized;
}
function persist(){
  if(saveTimer)clearTimeout(saveTimer);
  saveTimer=setTimeout(()=>{const json=JSON.stringify({schemaVersion:2,lastRefresh,feed:{...state,refreshing:false,abstractJobsPending:0}});
    saveChain=saveChain.then(async()=>{await mkdir(dirname(file),{recursive:true});const temp=file+".tmp";await writeFile(temp,json);await rename(temp,file);}).catch(error=>console.warn("RSS cache write skipped:",error instanceof Error?error.message:"unavailable"));
  },200);saveTimer.unref?.();
}
function key(article:Article){return article.doi?"doi:"+normalDoi(article.doi):"url:"+article.link;}
function mergeArticles(incoming:Article[]){
  const byKey=new Map(state.articles.map(article=>[key(article),article]));
  const byUrl=new Map(state.articles.map(article=>[normalizedArticleLink(article.link),article]));
  for(const article of incoming){
    const previous=byKey.get(key(article))||byUrl.get(normalizedArticleLink(article.link));
    let merged=previous?{...previous,...article,id:previous.id}:enrich(article);
    if(previous?.abstractStatus==="available"&&previous.abstractSource&&!["rss","snapshot"].includes(previous.abstractSource))merged={...merged,abstract:previous.abstract,abstractSource:previous.abstractSource,abstractStatus:previous.abstractStatus,abstractCheckedAt:previous.abstractCheckedAt,abstractZh:previous.abstractZh};
    else if(previous&&usefulAbstract(previous.abstract)&&!usefulAbstract(article.abstract))merged={...merged,abstract:previous.abstract,abstractSource:previous.abstractSource||"snapshot",abstractStatus:previous.abstractStatus||"available",abstractZh:previous.abstractZh,abstractCheckedAt:previous.abstractCheckedAt};
    else if(previous?.abstractCheckedAt)merged.abstractCheckedAt=previous.abstractCheckedAt;
    if(previous?.abstract!==merged.abstract&&merged.abstractZh)delete merged.abstractZh;
    if(previous?.title!==merged.title&&merged.titleZh)delete merged.titleZh;
    if(previous&&key(previous)!==key(merged))byKey.delete(key(previous));
    byKey.set(key(merged),merged);byUrl.set(normalizedArticleLink(merged.link),merged);
  }
  const count=new Map<string,number>();
  state.articles=[...byKey.values()].sort((a,b)=>Date.parse(b.publishedAt)-Date.parse(a.publishedAt)).filter(article=>{const n=(count.get(article.journalId)||0)+1;count.set(article.journalId,n);return n<=250;});
  state.total=state.articles.length;revision++;persist();
}
async function refreshJournal(journal:typeof journals[number]){
  const before=state.sources?.[journal.id];
  if(before?.retryAfter&&before.retryAfter>Date.now())return;
  state.sources![journal.id]={...before,status:"refreshing",count:state.articles.filter(a=>a.journalId===journal.id).length};
  try{
    const headers:Record<string,string>={};if(before?.etag)headers["If-None-Match"]=before.etag;if(before?.lastModified)headers["If-Modified-Since"]=before.lastModified;
    const response=await fetchText(journal.url!,{headers,timeout:7000});
    if(response.status!==304){mergeArticles(parseFeed(response.text,journal));state.updatedAt=new Date().toISOString();}
    state.sources![journal.id]={status:"live",count:state.articles.filter(a=>a.journalId===journal.id).length,updatedAt:new Date().toISOString(),etag:response.etag||before?.etag,lastModified:response.lastModified||before?.lastModified,failures:0};state.source="rss";
  }catch(error){
    const count=state.articles.filter(a=>a.journalId===journal.id).length,failures=(before?.failures||0)+1;
    const backoff=Math.min(3600000,ttl*2**Math.min(failures-1,4));
    state.sources![journal.id]={...before,status:count?"cached":"error",count,failures,retryAfter:Math.max(Date.now()+backoff,error instanceof UpstreamError?error.retryAfter:0),message:error instanceof UpstreamError?error.message:"暂未取得有效 RSS，已保留缓存"};
  }
  persist();
}
function recentAbstractCheck(article:Article){return !!article.abstractCheckedAt&&Date.now()-Date.parse(article.abstractCheckedAt)<6*3600000;}
export async function getArticleAbstract(id:string,priority=true):Promise<Article|undefined>{
  await initialize();const article=state.articles.find(a=>a.id===id);if(!article||!isNatureArticle(article))return article;
  if(article.abstractStatus==="available"&&article.abstractSource&&!["rss","snapshot"].includes(article.abstractSource)||recentAbstractCheck(article))return article;
  if(abstractInFlight.has(id))return abstractInFlight.get(id)!;
  state.abstractJobsPending=(state.abstractJobsPending||0)+1;
  const job=runLimited(async()=>{
    const result=await resolveNatureAbstract(article);
    const current=state.articles.find(a=>a.id===id)||article;
    let updated:Article={...current,abstractCheckedAt:new Date().toISOString()};
    if(result&&(result.abstractStatus==="available"||!usefulAbstract(current.abstract)&&result.abstract.length>current.abstract.length)){
      updated={...updated,...result};if(updated.abstract!==current.abstract)delete updated.abstractZh;
    }else if(!usefulAbstract(current.abstract))updated.abstractStatus=current.abstract?"summary":"unavailable";
    state.articles=state.articles.map(a=>a.id===id?updated:a);revision++;persist();return updated;
  },priority).finally(()=>{abstractInFlight.delete(id);state.abstractJobsPending=Math.max(0,(state.abstractJobsPending||0)-1);persist();});
  abstractInFlight.set(id,job);return job;
}
async function refreshAll(){
  let cursor=0;
  await Promise.all(Array.from({length:6},async()=>{while(cursor<journals.length){const journal=journals[cursor++];if(journal.url)await refreshJournal(journal);}}));
  lastRefresh=Date.now();persist();
  const count=Math.min(12,Math.max(0,Number(process.env.NATURE_BACKGROUND_LIMIT||4)));
  const missing=state.articles.filter(a=>isNatureArticle(a)&&!(a.abstractStatus==="available"&&a.abstractSource&&!["rss","snapshot"].includes(a.abstractSource))&&!recentAbstractCheck(a));
  for(const article of missing.slice(0,count))void getArticleAbstract(article.id,false).catch(()=>{});
}
export async function getFeed(force=false):Promise<Feed>{
  await initialize();
  if(!refreshing&&(force||Date.now()-lastRefresh>ttl)){
    refreshing=refreshAll().catch(error=>console.warn("RSS refresh failed",String(error))).finally(()=>{refreshing=null;});
  }
  return {...state,refreshing:!!refreshing,total:state.articles.length,revision};
}
export async function waitForRefresh(){await initialize();if(refreshing)await refreshing;}
export async function sourceHealth(){await initialize();return {revision,refreshing:!!refreshing,sources:state.sources,abstractJobsPending:state.abstractJobsPending||0};}
