import {parseHTML} from "linkedom";
import {fetchText,type FetchLike} from "./rss-http";
import {htmlToText,normalDoi,usefulAbstract} from "./rss-parser";
import type {Article} from "./types";

export type AbstractResult={abstract:string;abstractSource:NonNullable<Article["abstractSource"]>;abstractStatus:"available"|"summary"};
export function isNatureArticle(article:Article){try{const url=new URL(article.link);return url.hostname==="www.nature.com"&&/^\/articles\/[a-zA-Z0-9-]+\/?$/.test(url.pathname);}catch{return false;}}
function candidate(value:string){const clean=htmlToText(value);return usefulAbstract(clean)&&clean.length<20000?clean:null;}
function jsonLdAbstract(value:unknown):string|null{
  if(Array.isArray(value)){for(const entry of value){const found=jsonLdAbstract(entry);if(found)return found;}return null;}
  if(!value||typeof value!=="object")return null;
  const record=value as Record<string,unknown>;
  if(record.abstract){const raw=typeof record.abstract==="string"?record.abstract:(record.abstract as any)?.text;if(typeof raw==="string"){const result=candidate(raw);if(result)return result;}}
  return record["@graph"]?jsonLdAbstract(record["@graph"]):null;
}
export function parseNaturePage(html:string,article:Pick<Article,"doi"|"link">):AbstractResult|null{
  const {document}=parseHTML(html);
  if(/client challenge|checking your browser|just a moment|verify you are human|access denied/i.test(document.title||""))throw new Error("出版社公开页面暂不可用");
  const meta=(key:string)=>Array.from(document.querySelectorAll("meta")).find(n=>(n.getAttribute("name")||n.getAttribute("property")||"").toLowerCase()===key)?.getAttribute("content")||"";
  const pageDoi=meta("citation_doi")||meta("dc.identifier");
  if(pageDoi&&article.doi&&normalDoi(pageDoi)!==normalDoi(article.doi))throw new Error("摘要元数据与论文 DOI 不一致");
  const doiVerified=!!pageDoi&&!!article.doi&&normalDoi(pageDoi)===normalDoi(article.doi);
  const canonical=document.querySelector('link[rel="canonical"]')?.getAttribute("href");
  if(canonical&&!doiVerified){try{if(new URL(canonical,article.link).pathname.replace(/\/$/,"")!==new URL(article.link).pathname.replace(/\/$/,""))throw new Error("出版社返回的文章不匹配");}catch(error){if(error instanceof Error&&error.message.includes("不匹配"))throw error;}}
  const section=document.querySelector('#Abs1-content,section[aria-labelledby="Abs1"] .c-article-section__content,[data-test="article-abstract"]');
  if(section){
    const {document:fragment}=parseHTML(`<html><body>${section.innerHTML}</body></html>`);
    for(const node of fragment.querySelectorAll("figure,.c-article-section__figure,button,nav,script,style"))node.remove();
    const value=candidate(fragment.body.innerHTML);if(value)return {abstract:value,abstractSource:"publisher",abstractStatus:"available"};
  }
  for(const script of document.querySelectorAll('script[type="application/ld+json"]')){try{const value=jsonLdAbstract(JSON.parse(script.textContent||"null"));if(value)return {abstract:value,abstractSource:"publisher",abstractStatus:"available"};}catch{/* Some pages contain unrelated or invalid JSON-LD. */}}
  for(const key of ["citation_abstract","dcterms.abstract"]){const value=candidate(meta(key));if(value)return {abstract:value,abstractSource:"publisher",abstractStatus:"available"};}
  const dc=candidate(meta("dc.description"));
  if(dc){const sharing=candidate(meta("og:description"));const kind=meta("dc.type")+" "+meta("citation_article_type");return {abstract:dc,abstractSource:"publisher",abstractStatus:/news|editorial|comment|correction|review of a book/i.test(kind)||dc===sharing?"summary":"available"};}
  const value=candidate(meta("description")||meta("og:description"));
  return value?{abstract:value,abstractSource:"publisher",abstractStatus:"summary"}:null;
}
export async function resolveNatureAbstract(article:Article,fetcher:FetchLike=fetch):Promise<AbstractResult|null>{
  if(!isNatureArticle(article))return null;
  let summary:AbstractResult|null=null;
  try{
    const configured=Number(process.env.NATURE_PAGE_TIMEOUT_MS||18000);
    const timeout=Number.isFinite(configured)?Math.max(5000,Math.min(30000,configured)):18000;
    const response=await fetchText(article.link,{timeout,maxBytes:2500000,fetcher,headers:{Accept:"text/html,application/xhtml+xml;q=0.9"}});
    const final=new URL(response.url);if(final.hostname!=="www.nature.com"||!final.pathname.startsWith("/articles/"))throw new Error("出版社返回登录或验证页面");
    const parsed=parseNaturePage(response.text,article);if(parsed?.abstractStatus==="available")return parsed;summary=parsed;
  }catch{/* Keep the RSS text and try separately available bibliographic metadata. */}
  if(article.doi){
    try{
      const response=await fetchText(`https://api.crossref.org/works/${encodeURIComponent(article.doi)}`,{timeout:4500,maxBytes:800000,fetcher,headers:{Accept:"application/json"}});
      const data=JSON.parse(response.text);const record=data.message;
      if(record?.DOI&&normalDoi(record.DOI)===normalDoi(article.doi)&&typeof record.abstract==="string"){
        const value=candidate(record.abstract);if(value)return {abstract:value,abstractSource:"crossref",abstractStatus:"available"};
      }
    }catch{/* Not every publisher deposits an abstract with Crossref. */}
    try{
      const url=new URL("https://www.ebi.ac.uk/europepmc/webservices/rest/search");
      for(const [key,value] of Object.entries({query:`DOI:"${article.doi}"`,format:"json",resultType:"core",pageSize:"1"}))url.searchParams.set(key,value);
      const response=await fetchText(url.href,{timeout:4500,maxBytes:800000,fetcher,headers:{Accept:"application/json"}});const data=JSON.parse(response.text);
      const record=data.resultList?.result?.find((value:any)=>typeof value.doi==="string"&&normalDoi(value.doi)===normalDoi(article.doi));
      if(typeof record?.abstractText==="string"){const value=candidate(record.abstractText);if(value)return {abstract:value,abstractSource:"europepmc",abstractStatus:"available"};}
    }catch{/* Europe PMC only covers a subset of these journals. */}
  }
  return summary;
}
