export type FetchLike=(url:string,init?:RequestInit)=>Promise<Response>;
export class UpstreamError extends Error{
  constructor(message:string,public status=0,public retryAfter=0){super(message);}
}
export async function fetchText(url:string,{timeout=7000,headers={},maxBytes=4000000,fetcher=fetch}:{timeout?:number;headers?:Record<string,string>;maxBytes?:number;fetcher?:FetchLike}={}){
  const response=await fetcher(url,{headers:{Accept:"application/rss+xml, application/atom+xml, application/xml, text/xml, text/html, application/json;q=0.9",...headers},signal:AbortSignal.timeout(timeout)});
  const seconds=response.headers.get("retry-after");
  const retryAfter=seconds?(/^\d+$/.test(seconds)?Date.now()+Number(seconds)*1000:Date.parse(seconds)):0;
  if(response.status===304)return {status:304,text:"",url:response.url||url,etag:response.headers.get("etag")||undefined,lastModified:response.headers.get("last-modified")||undefined};
  if(!response.ok)throw new UpstreamError(`上游 HTTP ${response.status}`,response.status,Number.isFinite(retryAfter)?retryAfter:0);
  if(Number(response.headers.get("content-length")||0)>maxBytes)throw new UpstreamError("源文件超过大小限制");
  const reader=response.body?.getReader();let length=0;const chunks:Uint8Array[]=[];
  if(reader){try{while(true){const {done,value}=await reader.read();if(done)break;length+=value.byteLength;if(length>maxBytes){await reader.cancel();throw new UpstreamError("源文件超过大小限制");}chunks.push(value);}}finally{reader.releaseLock();}}
  const bytes=new Uint8Array(length);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
  return {status:response.status,text:new TextDecoder().decode(bytes),url:response.url||url,etag:response.headers.get("etag")||undefined,lastModified:response.headers.get("last-modified")||undefined};
}
