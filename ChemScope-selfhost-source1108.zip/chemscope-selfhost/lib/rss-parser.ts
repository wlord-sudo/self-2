import {XMLParser} from "fast-xml-parser";
import {parseHTML} from "linkedom";
import type {Article,Journal} from "./types";
import {doiFromArticleLink} from "./article-utils";

type NodeValue=unknown;
const array=(v:NodeValue):unknown[]=>v==null?[]:Array.isArray(v)?v:[v];
export function field(node:unknown,name:string):any{
  if(!node||typeof node!=="object")return undefined;
  const record=node as Record<string,unknown>;
  if(record[name]!=null)return record[name];
  const key=Object.keys(record).find(k=>!k.startsWith("@_")&&k.split(":").pop()===name);return key?record[key]:undefined;
}
export function text(node:unknown):string{
  if(node==null)return "";if(typeof node==="string"||typeof node==="number")return String(node);
  if(Array.isArray(node))return node.map(text).filter(Boolean).join(" ");
  if(typeof node==="object")return text((node as Record<string,unknown>)["#text"]??(node as Record<string,unknown>)["#cdata"]??Object.entries(node).filter(([k])=>!k.startsWith("@_")).map(([,v])=>v));
  return "";
}
function unpackHtml(markup:string){
  let result=markup.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,"$1").trim();
  if(/&lt;\/?[a-z]/i.test(result)){const {document}=parseHTML(`<html><body>${result}</body></html>`);result=document.body.textContent||result;}
  return result;
}
export function htmlToText(markup:string):string{
  markup=unpackHtml(markup);
  const {document}=parseHTML(`<html><body>${markup}</body></html>`);
  for(const node of document.querySelectorAll("script,style,noscript,svg"))node.remove();
  for(const node of document.querySelectorAll("h1,h2,h3,h4,h5,h6"))if(/^abstract$/i.test((node.textContent||"").trim()))node.remove();
  for(const node of document.querySelectorAll("p")){
    if(/^(?:Nature[^,]{0,50},?\s*Published online:|Publication Date|Authors?:|Graphical Abstract\s*$)/i.test((node.textContent||"").trim()))node.remove();
    else node.appendChild(document.createTextNode("\n"));
  }
  return (document.body.textContent||"").replace(/\u00a0/g," ").replace(/[ \t]+/g," ").replace(/\s*\n\s*/g,"\n").replace(/\n{3,}/g,"\n\n").trim();
}
export function usefulAbstract(value:string):boolean{
  return value.trim().length>=60&&!/^(?:Nature[^,]{0,70},?\s*Published online:|No abstract|Abstract not available|Sign in|Access this article|Client Challenge|Checking your browser|Just a moment)/i.test(value.trim());
}
export function safeUrl(value:string,base:string):string|null{
  try{const url=new URL(value.trim(),base);if(url.protocol==="http:")url.protocol="https:";return url.protocol==="https:"?url.href:null;}catch{return null;}
}
export function normalDoi(value:string):string{return value.replace(/^(?:https?:\/\/(?:dx\.)?doi\.org\/|doi\s*:\s*)/i,"").trim().toLowerCase();}
export function extractDoi(...values:string[]):string{
  for(const value of values){const match=value.match(/10\.\d{4,9}\/[^\s<>"?#]+/i);if(match)return normalDoi(match[0].replace(/[;,]+$/,""));}return "";
}
function itemLink(node:unknown,base:string):string|null{
  const links=array(field(node,"link"));
  for(const v of [...links.filter(v=>typeof v==="object"&&(v as any)?.["@_rel"]==="alternate"),...links]){
    const value=typeof v==="object"?(v as any)?.["@_href"]||text(v):text(v);if(value){const url=safeUrl(value,base);if(url)return url;}
  }
  return safeUrl(text(field(node,"url"))||text(field(node,"guid"))||text((node as any)?.["@_rdf:about"]),base);
}
function imageUrl(item:unknown,html:string,base:string):string|null{
  for(const key of ["thumbnail","enclosure","group","content"]){
    for(const entry of array(field(item,key))){
      const v=entry as any;
      if(v&&typeof v==="object"){
        const url=v["@_url"]||v["@_href"];const type=String(v["@_type"]||v["@_medium"]||"");
        if(url&&(!type||/image|\.(?:png|jpe?g|webp|svg)/i.test(type+url))){const result=safeUrl(String(url),base);if(result)return result;}
        const child=field(v,"content")||field(v,"thumbnail");if(child){const result=imageUrl({thumbnail:child},"",base);if(result)return result;}
      }
    }
  }
  const {document}=parseHTML(`<html><body>${unpackHtml(html)}</body></html>`);const src=document.querySelector("img")?.getAttribute("src");return src?safeUrl(src,base):null;
}
export function parseFeed(xml:string,journal:Journal):Article[]{
  if(/<!DOCTYPE/i.test(xml))throw new Error("RSS 不支持外部文档声明");
  if(/<(?:html|!doctype\s+html)\b/i.test(xml.slice(0,1000)))throw new Error("期刊返回网页，未取得 RSS");
  const parser=new XMLParser({ignoreAttributes:false,parseTagValue:false,parseAttributeValue:false,trimValues:true,processEntities:true,ignoreDeclaration:true,stopNodes:["*.title","*.dc:title","*.atom:title","*.description","*.content:encoded","*.summary","*.content","*.atom:content","*.dcterms:abstract"]});
  const document=parser.parse(xml);const rss=field(document,"rss"),rdf=field(document,"RDF"),atom=field(document,"feed");
  const channel=field(rss,"channel")||rdf||atom;
  const entries=array(field(channel,"item")||field(channel,"entry"));
  if(!channel||!entries.length)throw new Error("RSS 没有可用文献条目");
  const result:Article[]=[];
  for(const item of entries.slice(0,250)){
    const title=htmlToText(text(field(item,"title")));const link=itemLink(item,journal.url||"https://doi.org/");if(!title||!link)continue;
    const doi=extractDoi(text(field(item,"doi")),text(field(item,"identifier")),text(field(item,"guid")),text(field(item,"id")))||doiFromArticleLink(link);
    const candidates=[field(item,"abstract"),field(item,"encoded"),field(item,"description"),field(item,"summary"),field(item,"content")].map(text).filter(Boolean);
    const cleaned=candidates.map(htmlToText).filter(value=>value&&value!==title).sort((a,b)=>b.length-a.length);
    const abstract=cleaned.find(usefulAbstract)||cleaned.find(value=>value.length>30)||"";
    const authorNodes=array(field(item,"creator")||field(item,"author"));
    const authors=authorNodes.map(author=>htmlToText(text(field(author,"name")||author))).filter(Boolean).join(", ");
    const rawDate=text(field(item,"pubDate")||field(item,"publicationDate")||field(item,"published")||field(item,"date")||field(item,"updated")||field(channel,"lastBuildDate"));
    const parsed=Date.parse(rawDate);const publishedAt=Number.isFinite(parsed)?new Date(parsed).toISOString():new Date().toISOString();
    const rights=text(field(item,"rights")||field(item,"license"));
    result.push({id:doi?`doi:${doi}`:`url:${link}`,title,authors,publishedAt,abstract,imageUrl:imageUrl(item,candidates.join("\n"),link),link,doi,journalId:journal.id,journalName:journal.name,journalAbbr:journal.abbr,oa:/creativecommons|open.access/i.test(rights),abstractSource:"rss",abstractStatus:!abstract?"missing":journal.nature?"summary":"available"});
  }
  if(!result.length)throw new Error("RSS 条目缺少标题或链接");return result;
}
