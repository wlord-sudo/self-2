# ChemScope 化学速览 · 自部署源码 v1.1（直接 RSS）

这是前面双语文献网页的独立部署版本，保留相同页面和阅读功能，使用 React + TypeScript + Vite，以及 Node.js 内置 HTTP 服务。无需 ChatGPT 账号、Cloudflare 账号或数据库。

压缩包包含完整源码、锁定依赖的 `package-lock.json`、Docker 配置、中文部署说明，以及已经构建好的 `dist/`。直接运行预构建版本不需要执行 npm 安装。

## 快速启动：Docker

解压后进入项目目录，执行：

```bash
docker compose up -d --build
```

浏览器打开 `http://你的服务器IP:3000`。默认配置使用随包附带的构建产物，只需获取 Node.js 基础镜像。

查看日志：

```bash
docker compose logs -f
```

修改代码后，使用源码构建镜像：

```bash
docker build -t chemscope:local -f Dockerfile .
docker run -d --name chemscope-source --restart unless-stopped -p 3001:3000 chemscope:local
```

这里使用主机端口 3001，避免与默认 Compose 服务占用的 3000 端口冲突。也可以修改 `compose.yml` 中的 `dockerfile` 为 `Dockerfile`，然后重新执行 `docker compose up -d --build`。

## 快速启动：Node.js

要求 Node.js 22.13 或更新版本，建议使用 Node.js 24。

```bash
node server.mjs
```

打开 `http://你的服务器IP:3000`。终端关闭后进程会结束；长期运行可使用 Docker 或部署说明中的 systemd。

从源码重建：

```bash
npm ci
npm run build
npm start
```

详细操作见 [DEPLOY_zh-CN.md](DEPLOY_zh-CN.md)。

## 功能

- 23 本期刊的化学文献聚合；中文和英文标题同时展示。
- 中文摘要、英文原文与中英对照；新标题自动翻译，摘要按需翻译。
- 期刊与研究主题筛选、关键词搜索、收藏、阅读状态、排序。
- 图文摘要大图、DOI 复制与出版社原文跳转。
- 手机和桌面布局；收藏、译文与偏好保存在当前浏览器。

## 数据源和翻译

文献由服务器直接读取各出版社的 RSS，不再通过聚合站中转。23 本期刊的地址在 `lib/journals.json` 中配置，支持 RSS 2.0、Nature 常用的 RSS 1.0/RDF 和 Atom。图文摘要直接加载出版社提供的图片地址。

列表先返回磁盘缓存或随包快照，后台最多并发抓取 6 家期刊；默认缓存 5 分钟，利用 ETag / Last-Modified 进行条件请求。单家期刊不可用时保留该刊缓存，并显示状态。界面通过小型状态接口检查更新，仅在文献变化时重新取列表。

Nature 系列会解析命名空间、CDATA 和 DOI，并优先从公开文章页的摘要正文区获取摘要，补充 JSON-LD、DC 元数据；必要时再查询 Crossref 和 Europe PMC 中与 DOI 精确匹配的摘要。完整摘要、RSS 简介和不可用状态分别标注。后台默认补全 4 篇，打开 Nature 摘要时也会按需补抓。公开站点或元数据都不可用时，保留已有简介，不保证每篇都能取得完整摘要。

缓存默认保存在 `.cache/rss-feed-v2.json`；Docker Compose 使用命名卷持久保存，重启后可复用。包内附带时间戳明确的真实文献快照。

在线翻译优先从浏览器调用 MyMemory 的公开 CORS 接口，以避免所有读者共用服务器出口的免费额度；失败时尝试服务端 Google / MyMemory 接口。免费服务有调用额度，也可能受网络影响。部分首屏标题和摘要已有整理过的中文译文。专业术语、缩写和数据请与英文原文核对。

自部署版本默认没有 ChatGPT 登录门槛；访问权限由你自己的服务器或反向代理管理。收藏和阅读状态按浏览器保存，不跨设备同步。

## 主要文件

| 文件 | 用途 |
| --- | --- |
| `components/reader.tsx` | 阅读页面、筛选、收藏及摘要交互 |
| `app/globals.css` | 全部页面样式与手机适配 |
| `lib/feed.ts` | RSS 并发更新、落盘缓存和摘要补全调度 |
| `lib/journals.json` | 23 本期刊的 RSS 地址 |
| `lib/rss-parser.ts` | RSS 2.0 / RDF / Atom、CDATA 和图文摘要解析 |
| `lib/nature-abstract.ts` | Nature 公开摘要和 DOI 元数据补抓 |
| `lib/initial-feed.ts` | 首屏快照和缺失 DOI 识别 |
| `lib/translation-cache.ts` | 摘要变化后的译文缓存校验 |
| `lib/initial-data.json` | 随包附带的文献快照 |
| `lib/translations.ts` | 已整理的初始中文译文 |
| `lib/translate-client.ts` | 浏览器在线翻译 |
| `app/api/translate/route.ts` | 服务端后备翻译 |
| `server.mjs` | Node.js HTTP 服务、静态资源及接口路由 |
| `vite.config.ts` | 前端构建、别名与开发代理 |
| `Dockerfile` | 从源码构建镜像 |
| `Dockerfile.prebuilt` | 使用随包构建产物的镜像 |
| `compose.yml` | Docker Compose 启动配置 |

运行 `npm test` 可执行 RSS、Nature 摘要和缓存的回归测试。更新源码时应重新构建，压缩包中的预构建文件已包含本版本修改。

React、Vite、Lucide、fast-xml-parser 和 LinkeDOM 等依赖遵循各自许可证；论文元数据、摘要及图文摘要的版权归原作者和出版社。本站为独立阅读页，与 Baran Lab 无隶属关系。
