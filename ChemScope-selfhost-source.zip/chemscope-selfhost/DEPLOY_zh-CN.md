# 中文部署说明

## 1. 上传与解压

将 `ChemScope-selfhost-source.zip` 上传到服务器，解压后进入 `chemscope-selfhost` 目录。后续命令均在这个目录内执行。

```bash
unzip ChemScope-selfhost-source.zip
cd chemscope-selfhost
```

## 2. Docker Compose 部署

服务器安装 Docker 和 Compose 插件后执行：

```bash
docker compose up -d --build
docker compose ps
```

访问 `http://服务器IP:3000`。

默认 `compose.yml` 选择 `Dockerfile.prebuilt`，使用压缩包内已构建好的 `dist/`，不需要下载 npm 依赖。构建时仍需要能够获取 `node:24-alpine` 基础镜像。

如需改用 8080 端口，在项目目录新建 `.env`：

```dotenv
PORT=8080
```

然后执行：

```bash
docker compose up -d --build
```

此时访问 `http://服务器IP:8080`。容器内部仍使用 3000 端口。

常用命令：

```bash
docker compose logs -f
docker compose restart
docker compose down
```

修改源码后，在 `compose.yml` 中把 `dockerfile: Dockerfile.prebuilt` 改为 `dockerfile: Dockerfile`，再执行 `docker compose up -d --build`，即可在镜像构建阶段重新安装依赖并编译。之后每次改源码都应重新构建，单纯 restart 不会重新编译。

## 3. 不使用 Docker

检查 Node.js 版本：

```bash
node --version
```

最低要求 22.13，建议使用 24 系列。包内有构建产物，可以直接启动：

```bash
node server.mjs
```

自定义监听地址和端口：

```bash
HOST=127.0.0.1 PORT=8080 node server.mjs
```

只有 `npm start` 和 `npm run dev:api` 会自动加载项目目录的 `.env`。直接执行 `node server.mjs` 时使用 shell 环境变量；也可以运行 `node --env-file-if-exists=.env server.mjs`。

### systemd 后台运行

将整个项目放到 `/opt/chemscope`，用 `command -v node` 确认 Node 路径，将下面的 `/usr/bin/node` 替换为实际路径。创建 `/etc/systemd/system/chemscope.service`：

```ini
[Unit]
Description=ChemScope bilingual chemistry reader
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/opt/chemscope
ExecStart=/usr/bin/node /opt/chemscope/server.mjs
Environment=NODE_ENV=production
Environment=HOST=0.0.0.0
Environment=PORT=3000
Restart=on-failure
RestartSec=5
DynamicUser=yes
NoNewPrivileges=yes

[Install]
WantedBy=multi-user.target
```

应用目录和文件需要对服务用户可读，然后执行：

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now chemscope
sudo systemctl status chemscope
```

查看日志：

```bash
sudo journalctl -u chemscope -f
```

## 4. 使用域名和反向代理

将域名解析到服务器，使用现有 Nginx 或其他反向代理转发到 3000 端口即可。例如，Nginx 的站点配置可以使用：

```nginx
server {
    listen 80;
    server_name papers.example.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

将 `papers.example.com` 换成自己的域名；HTTPS 可以由已有面板或反向代理管理。DOI 复制功能在 HTTPS 或 localhost 环境下兼容性更好。

## 5. 修改页面与开发

```bash
npm ci
npm run build
```

前端开发与 API 分别在两个终端启动：

```bash
npm run dev:api
```

```bash
npm run dev
```

Vite 默认使用 5173 端口，并将 `/api` 请求代理至本机 3000 端口。页面文件修改后自动刷新；修改后端 TS 文件后需要再次 `npm run build` 并重启 API 服务。

常用修改位置：

- 网站标题：`index.html`；页面品牌文字：`components/reader.tsx`。
- 配色与尺寸：`app/globals.css`；Logo：`public/favicon.svg`。
- 文献源：`lib/feed.ts`；初始快照：`lib/initial-data.json`。
- 翻译逻辑：`lib/translate-client.ts` 和 `app/api/translate/route.ts`。

## 6. 常见情况

**页面能打开，但显示“最近保存的文献”**：应用正在使用随包快照。检查服务器是否能够访问原站公开文献接口；当前版本会在接口失败时继续显示快照。

**标题或摘要无法翻译**：浏览器或服务器连接不到翻译服务，或免费额度已用尽。已有译文和英文原文仍可阅读，稍后可重试。

**外网打不开，本机健康检查正常**：检查你实际使用的监听地址、Docker 端口映射，以及服务器的防火墙或安全组是否允许所选端口。

**改了源码但页面没变**：先重新构建，再重新启动。默认 Docker 配置读取预构建的 `dist/`，修改源码后应改用 `Dockerfile` 从源码构建。

健康检查：

```bash
curl http://127.0.0.1:3000/healthz
```

正常返回含 `"status":"ok"` 的 JSON。
