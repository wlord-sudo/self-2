import test from "node:test";
import assert from "node:assert/strict";
import {mkdtemp,readdir,rm} from "node:fs/promises";
import {tmpdir} from "node:os";
import {join} from "node:path";
import {SyncStore} from "../lib/sync-store";
import {SyncClient,type SyncState} from "../lib/sync-client";
import {normalizeSyncName,overlayOperations,SYNC_HEADER,type SyncData,type SyncOperation} from "../lib/sync-protocol";
import type {Article} from "../lib/types";

const article=(id:string):Article=>({id,title:`Paper ${id}`,authors:"A. Author",publishedAt:"2026-11-08T00:00:00Z",abstract:"A visible-light reaction in water.",imageUrl:null,link:`https://example.org/${id}`,doi:`10.99999/${id}`,journalId:"jacs",journalName:"JACS",journalAbbr:"JACS",oa:false});
const initial=():SyncData=>({favorites:{},reads:[],settings:{mode:"bilingual",autoTranslate:true,sort:"newest",journalPreferences:{enabled:["jacs"],knownJournalIds:["jacs","nature"],defaultJournalIds:["jacs"]}}});
let sequence=0;
const op=(kind:SyncOperation["kind"],key:string,value:unknown,timestamp=Date.now(),deviceId="device-a",ifAbsent=false):SyncOperation=>({id:`operation-${++sequence}`,kind,key,value,timestamp,deviceId,ifAbsent});
async function fixture(fn:(store:SyncStore,path:string)=>Promise<void>){const path=await mkdtemp(join(tmpdir(),"chemscope-sync-"));try{await fn(new SyncStore(path),path);}finally{await rm(path,{recursive:true,force:true});}}
class MemoryStorage{values=new Map<string,string>();getItem(key:string){return this.values.get(key)||null;}setItem(key:string,value:string){this.values.set(key,value);}removeItem(key:string){this.values.delete(key);}}
function transport(store:SyncStore){
  const control={offline:false,calls:[] as string[]};
  const fetcher:typeof fetch=async(input,init)=>{
    const path=String(input);control.calls.push(path);if(control.offline)throw new TypeError("Network offline");
    const headers=new Headers(init?.headers),body=init?.body?JSON.parse(String(init.body)):{};
    const name=decodeURIComponent(headers.get(SYNC_HEADER)||"");
    if(path.endsWith("/connect"))return Response.json(await store.connect(body.username));
    if(init?.method==="POST")return Response.json(await store.apply(name,body.operations));
    const snapshot=await store.get(name),etag=`"sync-${snapshot.revision}"`;
    return headers.get("if-none-match")===etag?new Response(null,{status:304}):Response.json(snapshot,{headers:{ETag:etag}});
  };
  return {control,fetcher};
}
function browser(fetcher:typeof fetch,storage=new MemoryStorage()){
  let data=initial(),state:SyncState|null=null;
  const client=new SyncClient({storage,fetcher,onData:value=>{data=value;},onState:value=>{state=value;}});
  return {client,storage,get data(){return data;},get state(){return state!;}};
}

test("Browser-style fetch keeps its global receiver for default and injected transports",async()=>fixture(async(store)=>{
  const original=globalThis.fetch,{fetcher}=transport(store);
  // Unlike Node fetch and arrow-function mocks, browser fetch checks its receiver.
  const browserFetch:typeof fetch=function(this:unknown,...args:Parameters<typeof fetch>){
    if(this!==globalThis)throw new TypeError("Failed to execute 'fetch' on 'Window': Illegal invocation");
    return fetcher(...args);
  };
  globalThis.fetch=browserFetch;
  const client=new SyncClient({storage:new MemoryStorage(),onData:()=>{},onState:()=>{}});
  let injected:ReturnType<typeof browser>|null=null;
  try{
    await client.connect("browser-fetch",initial());
    assert.equal(client.current.phase,"synced",client.current.error);
    client.enqueue("favorite","a",article("a"));await client.sync();
    assert((await store.get("browser-fetch")).favorites.a);
    injected=browser(browserFetch);await injected.client.connect("browser-fetch",initial(),false);
    assert.equal(injected.state.phase,"synced",injected.state.error);assert(injected.data.favorites.a);
  }finally{client.dispose();injected?.client.dispose();globalThis.fetch=original;}
}));

test("Unicode sync names normalize consistently and cannot become filesystem paths",async()=>fixture(async(store,path)=>{
  assert.equal(normalizeSyncName("  Ｃｈｅｍ研究_7 "),"chem研究_7");
  await store.connect("Ｃｈｅｍ研究_7");await store.connect("chem研究_7");
  const names=await readdir(path);assert.equal(names.length,1);assert.match(names[0],/^[a-f0-9]{64}\.json$/);
  for(const name of ["../secret","a/b","","a\nname","a".repeat(65)])assert.throws(()=>normalizeSyncName(name));
}));
test("Concurrent devices merge independent favorites and persist across a restart",async()=>fixture(async(store,path)=>{
  await store.connect("same-name");
  await Promise.all([store.apply("same-name",[op("favorite","a",article("a"))]),store.apply("same-name",[op("favorite","b",article("b"),Date.now(),"device-b")])]);
  const profile=await new SyncStore(path).get("same-name");assert.deepEqual(Object.keys(profile.favorites).sort(),["a","b"]);
  assert.deepEqual((await store.connect("another-name")).favorites,{});
}));
test("Deletion tombstones defeat stale uploads and first-connect imports",async()=>fixture(async(store)=>{
  await store.connect("name");const time=Date.now();
  await store.apply("name",[op("favorite","a",article("a"),time)]);
  await store.apply("name",[op("favorite","a",null,time+10)]);
  await store.apply("name",[op("favorite","a",article("a"),time+5,"device-b"),op("favorite","a",article("a"),time+20,"device-c",true)]);
  assert.deepEqual((await store.get("name")).favorites,{});
  await store.apply("name",[op("favorite","a",article("a"),time+30,"device-b")]);
  assert((await store.get("name")).favorites.a);
}));
test("Settings merge by field, preserve empty journal selections and ignore replayed changes",async()=>fixture(async(store)=>{
  await store.connect("name");const time=Date.now(),first=op("setting","mode","english",time);
  await store.apply("name",[first]);const revision=(await store.get("name")).revision;
  await store.apply("name",[first]);assert.equal((await store.get("name")).revision,revision);
  await store.apply("name",[op("setting","autoTranslate",false,time+1,"device-b"),op("setting","journalPreferences",{enabled:[],knownJournalIds:["jacs"],defaultJournalIds:["jacs"]},time+2)]);
  const settings=(await store.get("name")).settings;assert.equal(settings.mode,"english");assert.equal(settings.autoTranslate,false);assert.deepEqual(settings.journalPreferences?.enabled,[]);
}));
test("Invalid batches are rejected atomically, including script links and prototype keys",async()=>fixture(async(store)=>{
  await store.connect("name");
  await assert.rejects(store.apply("name",[op("read","a",true),op("favorite","b",{...article("b"),link:"javascript:alert(1)"})]));
  assert.deepEqual((await store.get("name")).reads,[]);
  await assert.rejects(store.apply("name",[op("read","__proto__",true)]));
  await assert.rejects(store.apply("name",[op("setting","unknown",true)]));
}));
test("A second browser receives favorites, reads and journal preferences without overwriting remote settings",async()=>fixture(async(store)=>{
  const {fetcher}=transport(store),a=browser(fetcher),b=browser(fetcher);
  try{
    await a.client.connect("same",initial());a.client.enqueue("favorite","a",article("a"));a.client.enqueue("read","a",true);a.client.enqueue("setting","mode","english");a.client.enqueue("setting","journalPreferences",{enabled:["nature"],knownJournalIds:["jacs","nature"],defaultJournalIds:["jacs"]});await a.client.sync();
    const local=initial();local.favorites.b=article("b");await b.client.connect("same",local);
    assert.deepEqual(Object.keys(b.data.favorites).sort(),["a","b"]);assert.deepEqual(b.data.reads,["a"]);assert.equal(b.data.settings.mode,"english");assert.deepEqual(b.data.settings.journalPreferences?.enabled,["nature"]);
    await a.client.sync();assert(a.data.favorites.b);assert.equal(a.state.phase,"synced");
  }finally{a.client.dispose();b.client.dispose();}
}));
test("Offline changes survive browser recreation and retry, including favorite removal",async()=>fixture(async(store)=>{
  const {fetcher,control}=transport(store),a=browser(fetcher);let recreated:ReturnType<typeof browser>|null=null;
  try{
    await a.client.connect("offline-name",initial());a.client.enqueue("favorite","a",article("a"));await a.client.sync();
    control.offline=true;a.client.enqueue("favorite","a",null);a.client.enqueue("setting","sort","oldest");await a.client.sync();assert.equal(a.state.phase,"offline");assert.equal(a.state.pending,2);a.client.dispose();
    recreated=browser(fetcher,a.storage);assert.equal(recreated.client.rememberedName,"offline-name");control.offline=false;
    await recreated.client.connect("offline-name",a.data,false);assert.deepEqual(recreated.data.favorites,{});assert.equal(recreated.data.settings.sort,"oldest");assert.equal(recreated.state.pending,0);
  }finally{a.client.dispose();recreated?.client.dispose();}
}));
test("A newer edit made during an upload is not removed by the older acknowledgement",async()=>fixture(async(store)=>{
  const base=transport(store);let release:(()=>void)|null=null,started:(()=>void)|null=null,block=false;
  const began=new Promise<void>(resolve=>{started=resolve;});
  const fetcher:typeof fetch=async(input,init)=>{if(block&&init?.method==="POST"&&String(input)==="/api/sync"){block=false;started!();await new Promise<void>(resolve=>{release=resolve;});}return base.fetcher(input,init);};
  const a=browser(fetcher);
  try{await a.client.connect("name",initial());block=true;a.client.enqueue("favorite","a",article("a"));const pending=a.client.sync();await began;a.client.enqueue("favorite","a",null);release!();await pending;assert.deepEqual((await store.get("name")).favorites,{});assert.equal(a.state.pending,0);}finally{a.client.dispose();}
}));
test("Pending explicit edits overlay remote snapshots; migration imports never resurrect records",()=>{
  const local=initial();local.favorites.a=article("a");
  const merged=overlayOperations(local,[op("favorite","a",null),op("favorite","b",article("b"),Date.now(),"other",true),op("setting","autoTranslate",false)]);
  assert.deepEqual(merged.favorites,{});assert.equal(merged.settings.autoTranslate,false);
});
