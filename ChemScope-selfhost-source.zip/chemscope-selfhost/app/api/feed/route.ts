import {getFeed,initialFeed} from "@/lib/feed";
export async function GET(){
  try{return Response.json(await getFeed(),{headers:{"Cache-Control":"private, max-age=120"}});}
  catch(error){console.error("Feed upstream unavailable",error);return Response.json({...initialFeed,source:"snapshot",message:"实时源暂不可用，正在显示最近保存的文献。"});}
}
