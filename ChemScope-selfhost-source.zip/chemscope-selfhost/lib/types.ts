export type Article = {
  id: string; title: string; authors: string; publishedAt: string;
  abstract: string; imageUrl: string | null; link: string; doi: string;
  journalId: string; journalName: string; journalAbbr: string; oa: boolean;
  titleZh?: string; abstractZh?: string; translationSource?: string;
};
export type Journal = {id: string; name: string; abbr: string; publisher: string; color: string; discipline: string};
export type Feed = {articles: Article[]; journals: Journal[]; updatedAt: string; total: number; source?: string};
