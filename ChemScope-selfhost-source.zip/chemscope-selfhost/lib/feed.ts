import initial from "./initial-data.json";
import { translations } from "./translations";
import type {Article, Feed} from "./types";
export function enrich(article: Article): Article {return {...article, ...(translations[article.id] || {})};}
export const initialFeed = {articles:initial.articles.map(a=>enrich(a as Article)),journals:initial.journals,updatedAt:initial.updatedAt,total:initial.total,source:"snapshot"} as Feed;
let feedCache: {data:Feed;expires:number}|null=null;
export async function getFeed():Promise<Feed> {
  if(feedCache && feedCache.expires>Date.now()) return feedCache.data;
  const response=await fetch("https://api.baranlab.org/api/feed?limit=0",{signal:AbortSignal.timeout(25000)});
  if(!response.ok) throw new Error("期刊源暂时无法连接");
  const data=await response.json() as {articles:Article[];updatedAt:string;total:number};
  if(!Array.isArray(data.articles)||!data.articles.length) throw new Error("期刊源未返回文献");
  const clean=data.articles.filter(a=>a.id&&a.title&&/^https:\/\//i.test(a.link)).map(a=>enrich({
    id:a.id,title:a.title,authors:a.authors||"",publishedAt:a.publishedAt,abstract:a.abstract||"",imageUrl:a.imageUrl,
    link:a.link,doi:a.doi||"",journalId:a.journalId,journalName:a.journalName,journalAbbr:a.journalAbbr,oa:!!a.oa
  }));
  const result={articles:clean,journals:initialFeed.journals,updatedAt:data.updatedAt,total:clean.length,source:"live"};
  feedCache={data:result,expires:Date.now()+5*60*1000};return result;
}
