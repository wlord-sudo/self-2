import {normalizeSyncName,overlayOperations,settingKeys,syncRecordKey,SYNC_HEADER,type SyncData,type SyncOperation,type SyncSettings,type SyncSnapshot} from "./sync-protocol";

export type SyncState={username:string;phase:"local"|"connecting"|"syncing"|"synced"|"offline";pending:number;lastSynced:number|null;error:string};
export const localSyncState:SyncState={username:"",phase:"local",pending:0,lastSynced:null,error:""};
type StorageLike=Pick<Storage,"getItem"|"setItem"|"removeItem">;
type Options={storage:StorageLike;fetcher?:typeof fetch;onData:(data:SyncData)=>void;onState:(state:SyncState)=>void};
const ACTIVE="chemscope-sync-name",DEVICE="chemscope-sync-device";
const outboxKey=(name:string)=>`chemscope-sync-outbox:${name}`;
function identifier(){
  const bytes=new Uint8Array(12);
  if(typeof globalThis.crypto!=="undefined"&&typeof globalThis.crypto.getRandomValues==="function"){crypto.getRandomValues(bytes);return Array.from(bytes,b=>b.toString(16).padStart(2,"0")).join("");}
  return Date.now().toString(36)+Math.random().toString(36).slice(2);
}
function fromStorage<T>(storage:StorageLike,key:string,fallback:T):T{try{return JSON.parse(storage.getItem(key)||"null")??fallback;}catch{return fallback;}}

export class SyncClient{
  private storage:StorageLike;private fetcher:typeof fetch;private deviceId:string;
  private state:SyncState={...localSyncState};private pending:SyncOperation[]=[];
  private generation=0;private busy:Promise<void>|null=null;private clock=0;private offset=0;private etag="";private needsConnect=false;
  private timer:ReturnType<typeof setTimeout>|null=null;private disposed=false;private controller:AbortController|null=null;
  constructor(private options:Options){
    this.storage=options.storage;
    // Browser fetch requires the Window/global receiver even when stored on a class.
    this.fetcher=(options.fetcher||globalThis.fetch).bind(globalThis);
    const device=fromStorage(this.storage,DEVICE,"")||identifier();this.write(DEVICE,device);
    // Distinct tab sessions also need distinct tie-breakers when clocks match.
    this.deviceId=device+":"+identifier();
  }
  get current(){return {...this.state};}
  get rememberedName(){return fromStorage<string>(this.storage,ACTIVE,"");}
  private write(key:string,value:unknown){try{this.storage.setItem(key,JSON.stringify(value));return true;}catch{return false;}}
  private emit(change:Partial<SyncState>={}){this.state={...this.state,...change,pending:this.pending.length};if(!this.disposed)this.options.onState(this.current);}
  private persist(){if(this.state.username)this.write(outboxKey(this.state.username),this.pending);}
  private tick(){this.clock=Math.max(this.clock+1,Date.now()+this.offset);return this.clock;}
  private acceptClock(data:{serverTime:number;maxTimestamp?:number}){this.offset=data.serverTime-Date.now();this.clock=Math.max(this.clock,data.maxTimestamp||0);}
  private make(kind:SyncOperation["kind"],key:string,value:unknown,ifAbsent=false):SyncOperation{return {id:identifier(),kind,key,value,ifAbsent,timestamp:this.tick(),deviceId:this.deviceId};}
  private add(op:SyncOperation){
    const key=syncRecordKey(op),current=this.pending.find(item=>syncRecordKey(item)===key);
    if(op.ifAbsent&&current)return;
    this.pending=this.pending.filter(item=>syncRecordKey(item)!==key);this.pending.push(op);
  }
  private async request(path:string,init:RequestInit={},generation=this.generation){
    const controller=new AbortController();this.controller=controller;const timeout=setTimeout(()=>controller.abort(),15000);
    try{
      const response=await this.fetcher(path,{...init,cache:"no-store",signal:controller.signal});
      if(generation!==this.generation||this.disposed)throw new Error("连接已切换");
      if(!response.ok&&response.status!==304){let message="网络暂不可用，将自动重试";try{message=(await response.json()).error||message;}catch{/* Keep a useful message for non-JSON proxy errors. */}throw new Error(message);}
      return response;
    }finally{clearTimeout(timeout);if(this.controller===controller)this.controller=null;}
  }
  async connect(input:string,local:SyncData,mergeLocal=true){
    const name=normalizeSyncName(input);this.reset();const generation=this.generation;
    this.pending=fromStorage<SyncOperation[]>(this.storage,outboxKey(name),[]);
    if(!Array.isArray(this.pending))this.pending=[];
    this.pending=this.pending.filter(op=>op&&typeof op.id==="string"&&typeof op.timestamp==="number"&&["favorite","read","setting"].includes(op.kind));
    this.clock=Math.max(0,...this.pending.map(op=>op.timestamp));this.etag="";this.needsConnect=true;
    this.emit({username:name,phase:"connecting",error:"",lastSynced:null});this.write(ACTIVE,name);
    // Import only previously unknown entries. Server-side tombstones prevent stale resurrection.
    if(mergeLocal){for(const [key,value] of Object.entries(local.favorites))this.add(this.make("favorite",key,value,true));for(const key of local.reads)this.add(this.make("read",key,true,true));}
    for(const key of settingKeys){if(local.settings[key]!==undefined)this.add(this.make("setting",key,local.settings[key],true));}
    this.persist();await this.sync(generation);
  }
  enqueue(kind:SyncOperation["kind"],key:string,value:unknown){
    if(!this.state.username||this.disposed)return;
    this.add(this.make(kind,key,value));this.persist();this.emit({phase:this.state.phase==="offline"?"offline":"syncing"});
    if(this.timer)clearTimeout(this.timer);this.timer=setTimeout(()=>{this.timer=null;void this.sync();},650);
  }
  private apply(snapshot:SyncSnapshot){
    this.acceptClock(snapshot);this.etag=`"sync-${snapshot.revision}"`;
    this.options.onData(overlayOperations(snapshot,this.pending));
  }
  async sync(generation=this.generation):Promise<void>{
    if(!this.state.username||this.disposed||generation!==this.generation)return;
    if(this.busy)return this.busy;
    const task=this.run(generation);this.busy=task;
    try{await task;}finally{if(this.busy===task)this.busy=null;}
  }
  private async run(generation:number){
    const name=this.state.username,headers={[SYNC_HEADER]:encodeURIComponent(name)};
    this.emit({phase:this.needsConnect?"connecting":"syncing",error:""});
    try{
      if(this.needsConnect){
        const response=await this.request("/api/sync/connect",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:name})},generation);
        const snapshot=await response.json() as SyncSnapshot;if(generation!==this.generation)return;
        this.acceptClock(snapshot);this.needsConnect=false;
        // Imported values must not be newer than subsequent explicit actions.
        for(const op of this.pending)if(op.ifAbsent)op.timestamp=this.tick();
        this.persist();
      }
      let pushed=false;
      // Bound each turn so a long offline queue cannot keep a request loop alive forever.
      for(let batchIndex=0;this.pending.length&&batchIndex<50;batchIndex++){
        const batch:SyncOperation[]=[];let bytes=0;
        for(const op of this.pending){const size=new TextEncoder().encode(JSON.stringify(op)).length;if(batch.length&&(batch.length>=100||bytes+size>500000))break;batch.push(op);bytes+=size;}
        const response=await this.request("/api/sync",{method:"POST",headers:{...headers,"Content-Type":"application/json"},body:JSON.stringify({operations:batch})},generation);
        const data=await response.json() as {acknowledged:string[];serverTime:number};if(generation!==this.generation)return;
        this.acceptClock(data);const ids=new Set(data.acknowledged);this.pending=this.pending.filter(op=>!ids.has(op.id));this.persist();pushed=true;
      }
      const response=await this.request("/api/sync",{headers:{...headers,...(!pushed&&this.etag?{"If-None-Match":this.etag}:{})}},generation);
      if(response.status!==304){const snapshot=await response.json() as SyncSnapshot;if(generation!==this.generation)return;this.apply(snapshot);}
      if(generation!==this.generation)return;
      this.emit({phase:this.pending.length?"syncing":"synced",lastSynced:Date.now(),error:""});
    }catch(error){if(generation===this.generation&&!this.disposed)this.emit({phase:"offline",error:error instanceof Error?error.message:"网络暂不可用，将自动重试"});}
    if(generation===this.generation&&this.pending.length&&this.state.phase!=="offline"&&!this.disposed){if(this.timer)clearTimeout(this.timer);this.timer=setTimeout(()=>{this.timer=null;void this.sync();},700);}
  }
  private reset(){this.generation++;this.controller?.abort();this.controller=null;if(this.timer)clearTimeout(this.timer);this.timer=null;this.busy=null;}
  disconnect(){this.persist();this.reset();this.pending=[];try{this.storage.removeItem(ACTIVE);}catch{/* Browser storage may be unavailable. */}this.emit({...localSyncState});}
  dispose(){this.persist();this.disposed=true;this.reset();}
}
