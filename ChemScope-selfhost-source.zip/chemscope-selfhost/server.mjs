import {createServer} from "node:http";
import {createReadStream} from "node:fs";
import {stat} from "node:fs/promises";
import {dirname,extname,resolve,sep} from "node:path";
import {fileURLToPath} from "node:url";
import {createGzip,gzipSync} from "node:zlib";
import {getFeedResponse,getTranslationResponse} from "./dist/server/api.mjs";

const root=resolve(dirname(fileURLToPath(import.meta.url)),"dist/client");
const port=Number(process.env.PORT||3000);
const host=process.env.HOST||"0.0.0.0";
const mime={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".svg":"image/svg+xml",".png":"image/png",".jpg":"image/jpeg",".ico":"image/x-icon",".json":"application/json; charset=utf-8",".woff2":"font/woff2"};

async function sendResponse(req,res,response){
  res.statusCode=response.status;
  response.headers.forEach((value,key)=>res.setHeader(key,value));
  let body=Buffer.from(await response.arrayBuffer());
  if(body.length>1024&&/\bgzip\b/.test(req.headers["accept-encoding"]||"")){
    body=gzipSync(body);res.setHeader("Content-Encoding","gzip");res.setHeader("Vary","Accept-Encoding");
  }
  res.setHeader("Content-Length",body.length);
  res.end(req.method==="HEAD"?undefined:body);
}

async function readBody(req){
  const chunks=[];let length=0;
  for await(const chunk of req){length+=chunk.length;if(length>24000){const error=new Error("请求内容过长");error.status=413;throw error;}chunks.push(chunk);}
  return Buffer.concat(chunks);
}

const server=createServer(async(req,res)=>{
  res.setHeader("X-Content-Type-Options","nosniff");
  res.setHeader("Referrer-Policy","strict-origin-when-cross-origin");
  try{
    const url=new URL(req.url||"/","http://localhost");
    if(url.pathname==="/healthz")return sendResponse(req,res,Response.json({status:"ok",application:"ChemScope"}));
    if(url.pathname==="/api/feed"){
      if(req.method!=="GET")return sendResponse(req,res,new Response(null,{status:405,headers:{Allow:"GET"}}));
      return sendResponse(req,res,await getFeedResponse());
    }
    if(url.pathname==="/api/translate"){
      if(req.method!=="POST")return sendResponse(req,res,new Response(null,{status:405,headers:{Allow:"POST"}}));
      const body=await readBody(req);
      try{JSON.parse(body.toString());}catch{return sendResponse(req,res,Response.json({error:"请求必须为有效 JSON"},{status:400}));}
      const request=new Request("http://localhost/api/translate",{method:"POST",headers:{"Content-Type":"application/json","Content-Length":String(body.length)},body});
      return sendResponse(req,res,await getTranslationResponse(request));
    }
    if(url.pathname.startsWith("/api/"))return sendResponse(req,res,Response.json({error:"接口不存在"},{status:404}));
    if(req.method!=="GET"&&req.method!=="HEAD")return sendResponse(req,res,new Response(null,{status:405,headers:{Allow:"GET, HEAD"}}));
    let pathname;try{pathname=decodeURIComponent(url.pathname);}catch{return sendResponse(req,res,new Response("Bad request",{status:400}));}
    if(pathname.includes("\0"))return sendResponse(req,res,new Response("Bad request",{status:400}));
    const file=resolve(root,"."+(pathname==="/"?"/index.html":pathname));
    if(file!==root&&!file.startsWith(root+sep))return sendResponse(req,res,new Response("Forbidden",{status:403}));
    let info;try{info=await stat(file);}catch{return sendResponse(req,res,new Response("Not found",{status:404}));}
    if(!info.isFile())return sendResponse(req,res,new Response("Not found",{status:404}));
    res.setHeader("Content-Type",mime[extname(file)]||"application/octet-stream");
    res.setHeader("Cache-Control",pathname.startsWith("/assets/")?"public, max-age=31536000, immutable":"no-cache");
    if(req.method==="HEAD"){res.setHeader("Content-Length",info.size);return res.end();}
    const stream=createReadStream(file);stream.on("error",()=>res.destroy());
    if(info.size>1024&&/\bgzip\b/.test(req.headers["accept-encoding"]||"")&&/\.(html|js|css|json|svg)$/.test(file)){
      res.setHeader("Content-Encoding","gzip");res.setHeader("Vary","Accept-Encoding");stream.pipe(createGzip()).pipe(res);
    }else{res.setHeader("Content-Length",info.size);stream.pipe(res);}
  }catch(error){
    console.error(error instanceof Error?error.message:"Request failed");
    if(!res.headersSent)await sendResponse(req,res,Response.json({error:error.status===413?"请求内容过长":"服务暂时不可用"},{status:error.status===413?413:500}));
    else res.destroy();
  }
});

server.requestTimeout=65000;
server.headersTimeout=15000;
server.listen(port,host,()=>console.log(`ChemScope is running at http://${host}:${port}`));
for(const signal of ["SIGINT","SIGTERM"])process.on(signal,()=>{server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),10000).unref();});
