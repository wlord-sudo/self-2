export {GET as getFeedResponse} from "../app/api/feed/route";
export {POST as getTranslationResponse} from "../app/api/translate/route";
